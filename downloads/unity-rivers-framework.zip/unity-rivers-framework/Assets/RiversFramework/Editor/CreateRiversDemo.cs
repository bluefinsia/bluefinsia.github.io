#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace RiversInTheSky.Editor
{
    /// <summary>
    /// Editor-only convenience. A single menu action creates an EMPTY scene with
    /// the bootstrap component. Runtime generation does not dirty authored scenes.
    /// This file must stay inside an Editor folder so player builds exclude it.
    /// </summary>
    public static class CreateRiversDemo
    {
        [MenuItem("Tools/Rivers in the Sky/Create Demo Scene")]
        public static void CreateScene()
        {
            // Protect unsaved scene work before replacing the current scene.
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            GameObject systems = new GameObject("GameSystems");
            systems.AddComponent<OpenWorldGenerator>();
            systems.AddComponent<ArtifactQuest>();
            systems.AddComponent<GameBootstrap>();
            // Unity can strip native primitive mesh/collider support from player
            // builds if no saved scene references those component types. Retain
            // a disabled reference set; it never renders or runs physics.
            GameObject references = new GameObject("Primitive Build References (keep inactive)");
            references.transform.SetParent(systems.transform, false);
            references.SetActive(false);
            foreach (PrimitiveType type in new[] { PrimitiveType.Capsule, PrimitiveType.Sphere,
                PrimitiveType.Cube, PrimitiveType.Cylinder, PrimitiveType.Plane })
            {
                GameObject reference = GameObject.CreatePrimitive(type);
                reference.name = type + " reference";
                reference.transform.SetParent(references.transform, false);
            }
            Selection.activeGameObject = systems;
            EditorSceneManager.MarkSceneDirty(scene);
            Debug.Log("Rivers demo created. Save the scene, then press Play. Use the Built-in Render Pipeline and Input Manager (Old).");
        }
    }
}
#endif
