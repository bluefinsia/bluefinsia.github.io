using System.Collections.Generic;
using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>
    /// A no-prefab, no-asset demo assembler. Attach to one GameSystems object in
    /// an empty scene, then Play. All generated objects are runtime-only children.
    /// This is the composition root: the independent gameplay scripts do not
    /// search for or instantiate one another.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class GameBootstrap : MonoBehaviour
    {
        private OpenWorldGenerator world;
        private ArtifactQuest quest;
        private PlayerController player;
        private SmoothFollowCamera followCamera;
        private GameUI ui;
        private Light moon;
        private readonly List<Material> runtimeMaterials = new List<Material>();
        private Vector3 spawn;
        private CursorLockMode previousCursorLock;
        private bool previousCursorVisible;
        private bool cursorSaved;
        private bool initialFog;
        private Color initialFogColor;
        private float initialFogDensity;
        private FogMode initialFogMode;
        private Color initialAmbient;
        private bool renderSettingsSaved;

        private void Start()
        {
            // Start after scene Awake so UI and world dependencies have initialized.
            // AddComponent is safe here; World.Generate is called exactly once.
            world = GetComponent<OpenWorldGenerator>();
            if (world == null) world = gameObject.AddComponent<OpenWorldGenerator>();
            quest = GetComponent<ArtifactQuest>();
            if (quest == null) quest = gameObject.AddComponent<ArtifactQuest>();
            world.Generate();
            quest.Initialize();
            spawn = world.PlayerSpawnPosition + Vector3.up * 0.15f;
            BuildAtmosphere();
            CreatePlayerAndCamera();

            GameObject uiObject = new GameObject("GameUI");
            uiObject.transform.SetParent(transform, false);
            ui = uiObject.AddComponent<GameUI>();
            ui.Initialize();
            ui.ChoiceVisibilityChanged += SetDialogueMode;
            quest.ProgressChanged += RefreshUI;
            quest.ArtifactResolved += RespondToChoice;
            quest.JourneyFinished += Finish;

            for (int index = 0; index < ArtifactQuest.RequiredArtifacts; index++)
                CreateArtifact(index);
            CreateHiddenSanctuary();
            PlayerInteractor interactor = player.gameObject.AddComponent<PlayerInteractor>();
            interactor.SetObstructionMask(~(1 << player.gameObject.layer));
            interactor.Initialize(quest, ui);
            RefreshUI();
            ui.ShowMessage("WASD move · Space jump twice · RMB orbit · E interact · R replay song · Home return to start");
        }

        private void CreatePlayerAndCamera()
        {
            // Layer 2 is Unity's built-in Ignore Raycast layer. This makes the demo
            // work without editing TagManager. For a larger project create a
            // dedicated Player layer and exclude it from both masks instead.
            GameObject root = new GameObject("Player");
            root.transform.SetParent(transform, false);
            root.layer = 2;
            CharacterController controller = root.AddComponent<CharacterController>();
            controller.height = 1.8f;
            controller.radius = 0.35f;
            controller.center = new Vector3(0f, 0.9f, 0f);
            controller.stepOffset = 0.3f;
            controller.slopeLimit = 50f;
            controller.skinWidth = 0.04f;
            controller.minMoveDistance = 0f;
            player = root.AddComponent<PlayerController>();
            player.Teleport(spawn);

            GameObject body = CreatePrimitive("Researcher capsule", PrimitiveType.Capsule,
                root.transform, new Vector3(0f, 0.9f, 0f), new Vector3(0.65f, 0.9f, 0.65f),
                CreateMaterial(new Color(0.76f, 0.83f, 0.81f)), false);
            body.layer = root.layer;
            // A bright visor makes forward orientation visible without a model.
            GameObject visor = CreatePrimitive("Visor", PrimitiveType.Sphere, root.transform,
                new Vector3(0f, 1.45f, 0.28f), new Vector3(0.38f, 0.18f, 0.12f),
                CreateMaterial(new Color(0.1f, 0.9f, 1f), true), false);
            visor.layer = root.layer;

            Camera camera = Camera.main;
            if (camera == null)
            {
                GameObject cameraRoot = new GameObject("Main Camera");
                cameraRoot.transform.SetParent(transform, false);
                cameraRoot.tag = "MainCamera";
                camera = cameraRoot.AddComponent<Camera>();
            }
            camera.nearClipPlane = 0.1f;
            camera.farClipPlane = 600f;
            camera.fieldOfView = 65f;
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(0.12f, 0.22f, 0.28f);
            // In the supplied empty scene this creates exactly one listener.
            // Reusing another scene's camera is supported; check listener count
            // if that scene also has additional audio cameras.
            if (FindObjectOfType<AudioListener>() == null) camera.gameObject.AddComponent<AudioListener>();
            followCamera = camera.GetComponent<SmoothFollowCamera>();
            if (followCamera == null) followCamera = camera.gameObject.AddComponent<SmoothFollowCamera>();
            followCamera.Target = root.transform;
            followCamera.ObstructionMask = ~(1 << root.layer);
            player.MovementCamera = camera.transform;
            followCamera.SnapToTarget();
        }

        private void CreateArtifact(int index)
        {
            GameObject root = new GameObject(quest.GetDefinition(index).displayName);
            root.transform.SetParent(transform, false);
            root.transform.position = world.GetArtifactPosition(index);
            Material stone = CreateMaterial(new Color(0.32f, 0.42f, 0.42f));
            Material glow = CreateMaterial(Color.Lerp(new Color(0.1f, 0.75f, 0.95f),
                new Color(0.55f, 0.25f, 1f), index / 4f), true);
            // A low pedestal is physical but never reaches the interaction ray
            // (which is cast at torso height). The floating relic has no collider.
            CreatePrimitive("Pedestal", PrimitiveType.Cylinder, root.transform,
                Vector3.up * 0.22f, new Vector3(1.2f, 0.22f, 1.2f), stone, true);
            PrimitiveType shape = index == 0 ? PrimitiveType.Cylinder :
                index == 1 ? PrimitiveType.Sphere : index == 2 ? PrimitiveType.Cube :
                index == 3 ? PrimitiveType.Capsule : PrimitiveType.Sphere;
            GameObject visual = CreatePrimitive("Visual", shape, root.transform,
                Vector3.up * 1.25f, new Vector3(0.55f, 0.55f, 0.55f), glow, false);
            Light glowLight = visual.AddComponent<Light>();
            glowLight.type = LightType.Point;
            glowLight.color = glow.color;
            glowLight.range = 6f;
            glowLight.intensity = 1.4f;
            glowLight.shadows = LightShadows.None;
            root.AddComponent<ArtifactCollectible>().Initialize(quest, index, visual.transform);

            if (index == 4)
            {
                // Four stones echo the GDD's highlighted image of companions.
                for (int i = 0; i < 4; i++)
                {
                    float angle = i * Mathf.PI * 0.5f;
                    Vector3 offset = new Vector3(Mathf.Sin(angle) * 3f, 0.9f, Mathf.Cos(angle) * 3f);
                    CreatePrimitive("Companion stone " + (i + 1), PrimitiveType.Cube,
                        root.transform, offset, new Vector3(0.6f, 1.8f, 0.6f), stone, true);
                }
            }
        }

        private void CreateHiddenSanctuary()
        {
            GameObject root = new GameObject("HiddenSanctuary");
            root.transform.SetParent(transform, false);
            root.transform.position = world.FinalLocationPosition;
            GameObject revealed = new GameObject("Revealed sanctuary");
            revealed.transform.SetParent(root.transform, false);
            Material glow = CreateMaterial(new Color(0.35f, 1f, 0.8f), true);
            // The doorway is walkable: two pillars and a lintel, never a solid
            // collider across its centre. It becomes visible only after step 5.
            CreatePrimitive("Left pillar", PrimitiveType.Cube, revealed.transform,
                new Vector3(-2.2f, 2.5f, 0f), new Vector3(0.7f, 5f, 0.7f), glow, true);
            CreatePrimitive("Right pillar", PrimitiveType.Cube, revealed.transform,
                new Vector3(2.2f, 2.5f, 0f), new Vector3(0.7f, 5f, 0.7f), glow, true);
            CreatePrimitive("Moonlit lintel", PrimitiveType.Cube, revealed.transform,
                new Vector3(0f, 5f, 0f), new Vector3(5.1f, 0.6f, 0.7f), glow, true);
            CreatePrimitive("Threshold", PrimitiveType.Cylinder, revealed.transform,
                new Vector3(0f, 0.04f, 0f), new Vector3(5f, 0.04f, 5f), glow, false);
            root.AddComponent<HiddenLocation>().Initialize(quest, player.transform, revealed);
        }

        private void RefreshUI()
        {
            ArtifactDefinition clue = quest.CurrentClue;
            ui.SetProgress(quest.CollectedCount, ArtifactQuest.RequiredArtifacts,
                clue != null ? clue.songLine : quest.FinalLyric,
                clue != null ? clue.explorationHint : quest.FinalHint);
        }

        private void RespondToChoice(ArtifactCollectible artifact, int choice)
        {
            // Choice 0 preserves a green living relic; choice 1 retunes it gold.
            // Both advance the trail, but retuning also warms the entire valley.
            float warmth = quest.RetunedCount / (float)ArtifactQuest.RequiredArtifacts;
            moon.color = Color.Lerp(new Color(0.65f, 0.83f, 1f), new Color(1f, 0.8f, 0.55f), warmth);
            RenderSettings.fogColor = Color.Lerp(new Color(0.12f, 0.22f, 0.28f),
                new Color(0.24f, 0.28f, 0.25f), warmth);
            ui.ShowMessage((choice == 0 ? "Preserved: " : "Retuned: ") +
                artifact.Definition.displayName + (quest.AllCollected ?
                ". The hidden sanctuary has awakened." : ". A new song clue is revealed."));
        }

        private void Finish() => ui.ShowCompletion();

        private void SetDialogueMode(bool open)
        {
            player.ControlsEnabled = !open;
            followCamera.ControlsEnabled = !open;
            if (open)
            {
                previousCursorLock = Cursor.lockState;
                previousCursorVisible = Cursor.visible;
                cursorSaved = true;
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
            }
            else if (cursorSaved)
            {
                Cursor.lockState = previousCursorLock;
                Cursor.visible = previousCursorVisible;
                cursorSaved = false;
            }
        }

        private void Update()
        {
            if (player == null) return;
            // A land-only prototype: swimming is deliberately not simulated.
            // If a jump carries the researcher into deep water/out of bounds,
            // return safely to the starting pad. Home is an explicit rescue key.
            Vector3 surface = world.SurfacePosition(player.transform.position);
            bool underTerrain = player.transform.position.y < surface.y - 4f;
            if (player.transform.position.y < world.WaterSurfaceY - 0.3f || underTerrain ||
                (player.ControlsEnabled && Input.GetKeyDown(KeyCode.Home)))
            {
                ui.HideChoices();
                player.Teleport(spawn);
                followCamera.SnapToTarget();
                ui.ShowMessage("Returned to the starting overlook. Your discoveries are kept.");
            }
        }

        private void BuildAtmosphere()
        {
            initialFog = RenderSettings.fog;
            initialFogColor = RenderSettings.fogColor;
            initialFogDensity = RenderSettings.fogDensity;
            initialFogMode = RenderSettings.fogMode;
            initialAmbient = RenderSettings.ambientLight;
            renderSettingsSaved = true;
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.ExponentialSquared;
            RenderSettings.fogDensity = 0.007f;
            RenderSettings.fogColor = new Color(0.12f, 0.22f, 0.28f);
            RenderSettings.ambientLight = new Color(0.32f, 0.42f, 0.46f);
            GameObject lightObject = new GameObject("Moon light");
            lightObject.transform.SetParent(transform, false);
            lightObject.transform.rotation = Quaternion.Euler(45f, -35f, 0f);
            moon = lightObject.AddComponent<Light>();
            moon.type = LightType.Directional;
            moon.color = new Color(0.65f, 0.83f, 1f);
            moon.intensity = 1.1f;
            moon.shadows = LightShadows.Soft;
        }

        private Material CreateMaterial(Color color, bool emissive = false)
        {
            // This starter targets the Built-in Render Pipeline. Shader.Find uses
            // Built-in shaders; see README for build stripping and URP migration.
            Material material = new Material(Shader.Find("Standard"));
            material.color = color;
            material.SetFloat("_Glossiness", 0.25f);
            if (emissive)
            {
                material.EnableKeyword("_EMISSION");
                material.SetColor("_EmissionColor", color * 1.5f);
            }
            runtimeMaterials.Add(material);
            return material;
        }

        private static GameObject CreatePrimitive(string name, PrimitiveType type,
            Transform parent, Vector3 localPosition, Vector3 localScale, Material material, bool collider)
        {
            GameObject obj = GameObject.CreatePrimitive(type);
            obj.name = name;
            obj.transform.SetParent(parent, false);
            obj.transform.localPosition = localPosition;
            obj.transform.localScale = localScale;
            obj.GetComponent<Renderer>().sharedMaterial = material;
            Collider physics = obj.GetComponent<Collider>();
            if (!collider && physics != null)
            {
                // Destroy is deferred until end of frame, so disable immediately.
                physics.enabled = false;
                Object.Destroy(physics);
            }
            return obj;
        }

        private void OnDestroy()
        {
            if (ui != null) ui.ChoiceVisibilityChanged -= SetDialogueMode;
            if (quest != null)
            {
                quest.ProgressChanged -= RefreshUI;
                quest.ArtifactResolved -= RespondToChoice;
                quest.JourneyFinished -= Finish;
            }
            if (cursorSaved)
            {
                Cursor.lockState = previousCursorLock;
                Cursor.visible = previousCursorVisible;
            }
            if (renderSettingsSaved)
            {
                RenderSettings.fog = initialFog;
                RenderSettings.fogColor = initialFogColor;
                RenderSettings.fogDensity = initialFogDensity;
                RenderSettings.fogMode = initialFogMode;
                RenderSettings.ambientLight = initialAmbient;
            }
            foreach (Material material in runtimeMaterials)
                if (material != null) Destroy(material);
        }
    }
}
