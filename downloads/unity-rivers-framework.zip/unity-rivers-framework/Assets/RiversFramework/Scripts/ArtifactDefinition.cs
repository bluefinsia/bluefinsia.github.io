using System;
using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>
    /// Inspector-editable content for ONE step of the five-artifact trail.
    /// The lyric describes how to find this artifact, not the next one. After a
    /// discovery, the quest displays the following definition's clue.
    /// </summary>
    [Serializable]
    public sealed class ArtifactDefinition
    {
        public string displayName;
        [TextArea(2, 4)] public string songLine;
        [TextArea(2, 4)] public string explorationHint;
        [TextArea(3, 6)] public string description;
        public string preserveChoice = "Observe and preserve";
        public string retuneChoice = "Retune the ancient device";
        // Optional: assign a recording you have permission to use. Text clues
        // remain fully usable without audio; no audio assets are bundled.
        public AudioClip songClip;
    }
}
