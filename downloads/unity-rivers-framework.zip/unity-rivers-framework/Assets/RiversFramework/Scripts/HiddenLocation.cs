using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>
    /// Reveals a sanctuary after artifact five, then requires physical arrival.
    /// Attach to HiddenSanctuary root. A distance check avoids any dependency on
    /// Rigidbody/trigger configuration when using a CharacterController player.
    /// </summary>
    public sealed class HiddenLocation : MonoBehaviour
    {
        [SerializeField, Min(1f)] private float arrivalRadius = 3f;
        private ArtifactQuest quest;
        private Transform player;
        private GameObject visual;

        public void Initialize(ArtifactQuest owner, Transform explorer, GameObject revealVisual)
        {
            quest = owner;
            player = explorer;
            visual = revealVisual;
            visual.SetActive(quest.AllCollected);
            quest.AllArtifactsCollected += Reveal;
        }

        private void Reveal() => visual.SetActive(true);

        private void Update()
        {
            if (quest == null || player == null || !quest.AllCollected || quest.JourneyCompleted) return;
            Vector3 difference = player.position - transform.position;
            // Require proximity on both axes; jumping high above a portal should
            // not finish the journey before actually entering the sanctuary.
            float horizontal = new Vector2(difference.x, difference.z).sqrMagnitude;
            if (horizontal <= arrivalRadius * arrivalRadius && Mathf.Abs(difference.y) < 3f)
                quest.CompleteJourney();
        }

        private void OnDestroy()
        {
            if (quest != null) quest.AllArtifactsCollected -= Reveal;
        }
    }
}
