using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace RiversInTheSky
{
    /// <summary>
    /// Builds a small, playable prototype interface using Unity's built-in uGUI.
    /// Attach to a UI GameObject, or let GameBootstrap create it at runtime.
    /// The quest owns game state; this component only displays values and returns
    /// button choices, so replacing it with an authored Canvas later is straightforward.
    /// Requires the Unity UI package and the legacy Input Manager (or Active Input
    /// Handling = Both). It does not require TextMeshPro assets or a font download.
    /// </summary>
    public sealed class GameUI : MonoBehaviour
    {
        public bool IsChoiceOpen { get; private set; }

        /// <summary>
        /// A listener can suspend player movement/orbit and release the cursor while
        /// a modal is open. Cursor ownership stays outside the UI component.
        /// </summary>
        public event Action<bool> ChoiceVisibilityChanged;

        private Font font;
        private RectTransform canvasRoot;
        private Text countText;
        private Text lyricText;
        private Text hintText;
        private Text promptText;
        private Text messageText;
        private Text completionText;
        private GameObject modalRoot;
        private Text modalTitle;
        private Text modalDescription;
        private Text firstChoiceText;
        private Text secondChoiceText;
        private Button firstChoiceButton;
        private Button secondChoiceButton;
        private Button cancelButton;
        private Action<int> choiceCallback;
        private Action cancelCallback;
        private float messageExpiresAt;
        private bool initialized;

        private void Awake()
        {
            Initialize();
        }

        /// <summary>
        /// Idempotent: safe both from Awake and from bootstrap initialization.
        /// All generated objects belong to this GameObject and are removed with it.
        /// </summary>
        public void Initialize()
        {
            if (initialized) return;
            initialized = true;
            font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");

            GameObject canvasObject = new GameObject("Runtime Canvas", typeof(RectTransform),
                typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvasObject.transform.SetParent(transform, false);
            canvasRoot = canvasObject.GetComponent<RectTransform>();
            Canvas canvas = canvasObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 50;
            CanvasScaler scaler = canvasObject.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;

            // Reuse an existing EventSystem, including an inactive scene object.
            // Do not create duplicates when integrating into an authored scene.
            if (FindObjectsOfType<EventSystem>(true).Length == 0)
            {
                GameObject events = new GameObject("UI EventSystem", typeof(EventSystem),
                    typeof(StandaloneInputModule));
                events.transform.SetParent(transform, false);
            }

            RectTransform hud = CreatePanel("Artifact HUD", canvasRoot,
                new Color(0.025f, 0.075f, 0.1f, 0.9f));
            Place(hud, new Vector2(0f, 1f), new Vector2(0f, 1f),
                new Vector2(32f, -32f), new Vector2(690f, 290f));
            VerticalLayoutGroup hudLayout = hud.gameObject.AddComponent<VerticalLayoutGroup>();
            hudLayout.padding = new RectOffset(24, 24, 18, 18);
            hudLayout.spacing = 9f;
            hudLayout.childControlWidth = true;
            hudLayout.childControlHeight = true;
            hudLayout.childForceExpandWidth = true;
            hudLayout.childForceExpandHeight = false;
            countText = CreateText("Artifact count", hud, 30, FontStyle.Bold);
            SetLayout(countText.gameObject, 42f);
            lyricText = CreateText("Vietnamese song clue", hud, 26, FontStyle.Italic);
            lyricText.color = new Color(0.55f, 0.96f, 0.88f);
            SetLayout(lyricText.gameObject, 95f);
            hintText = CreateText("Next destination hint", hud, 23, FontStyle.Normal);
            SetLayout(hintText.gameObject, 98f);

            promptText = CreateText("Interaction prompt", canvasRoot, 28, FontStyle.Bold);
            promptText.alignment = TextAnchor.MiddleCenter;
            Place(promptText.rectTransform, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f),
                new Vector2(0f, 110f), new Vector2(1050f, 90f));

            messageText = CreateText("Status message", canvasRoot, 26, FontStyle.Normal);
            messageText.alignment = TextAnchor.MiddleCenter;
            messageText.color = new Color(0.7f, 1f, 0.87f);
            Place(messageText.rectTransform, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f),
                new Vector2(0f, 28f), new Vector2(1120f, 80f));
            messageText.gameObject.SetActive(false);

            completionText = CreateText("Journey completion", canvasRoot, 29, FontStyle.Bold);
            completionText.alignment = TextAnchor.UpperRight;
            completionText.color = new Color(0.65f, 1f, 0.88f);
            completionText.text = "HIDDEN SANCTUARY FOUND\nThe river remembers.\nYou may keep exploring.";
            Place(completionText.rectTransform, new Vector2(1f, 1f), new Vector2(1f, 1f),
                new Vector2(-32f, -32f), new Vector2(620f, 150f));
            completionText.gameObject.SetActive(false);

            BuildChoicePanel();
            SetProgress(0, 5, "", "Follow the song to the first artifact.");
            SetPrompt("");
        }

        private void BuildChoicePanel()
        {
            RectTransform shade = CreatePanel("Choice overlay", canvasRoot,
                new Color(0f, 0.025f, 0.04f, 0.87f));
            Stretch(shade);
            modalRoot = shade.gameObject;
            RectTransform panel = CreatePanel("Choice panel", shade,
                new Color(0.055f, 0.13f, 0.16f, 1f));
            Place(panel, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
                Vector2.zero, new Vector2(900f, 680f));
            VerticalLayoutGroup layout = panel.gameObject.AddComponent<VerticalLayoutGroup>();
            layout.padding = new RectOffset(34, 34, 30, 30);
            layout.spacing = 18f;
            layout.childControlWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = false;

            modalTitle = CreateText("Artifact title", panel, 36, FontStyle.Bold);
            SetLayout(modalTitle.gameObject, 70f);
            modalDescription = CreateText("Artifact description", panel, 27, FontStyle.Normal);
            SetLayout(modalDescription.gameObject, 225f);
            firstChoiceButton = CreateButton("First choice", panel, out firstChoiceText);
            secondChoiceButton = CreateButton("Second choice", panel, out secondChoiceText);
            cancelButton = CreateButton("Cancel", panel, out Text cancelText);
            cancelText.text = "Leave for now  [Esc]";
            SetLayout(firstChoiceButton.gameObject, 76f);
            SetLayout(secondChoiceButton.gameObject, 76f);
            SetLayout(cancelButton.gameObject, 66f);

            firstChoiceButton.onClick.AddListener(() => SubmitChoice(0));
            secondChoiceButton.onClick.AddListener(() => SubmitChoice(1));
            cancelButton.onClick.AddListener(CancelChoices);
            modalRoot.SetActive(false);
        }

        private void Update()
        {
            // Use unscaled time so messages and cancellation also work if a game
            // later pauses time while presenting a narrative choice.
            if (IsChoiceOpen && Input.GetKeyDown(KeyCode.Escape)) CancelChoices();
            if (messageText != null && messageText.gameObject.activeSelf &&
                Time.unscaledTime >= messageExpiresAt)
                messageText.gameObject.SetActive(false);
        }

        public void SetProgress(int collected, int total, string lyric, string hint)
        {
            Initialize();
            total = Mathf.Max(1, total);
            countText.text = "ARTIFACTS  " + Mathf.Clamp(collected, 0, total) + " / " + total;
            lyricText.text = lyric ?? "";
            hintText.text = hint ?? "";
        }

        public void SetPrompt(string text)
        {
            Initialize();
            promptText.text = text ?? "";
            promptText.gameObject.SetActive(!IsChoiceOpen && !string.IsNullOrEmpty(text));
        }

        /// <summary>
        /// Callback index is zero for the first choice and one for the second.
        /// Choice text should describe its actual effect, supplied by the quest.
        /// </summary>
        public void ShowChoices(string title, string description, string firstChoice,
            string secondChoice, Action<int> onChoice, Action onCancel)
        {
            Initialize();
            choiceCallback = onChoice;
            cancelCallback = onCancel;
            modalTitle.text = title ?? "Artifact";
            modalDescription.text = description ?? "";
            firstChoiceText.text = firstChoice ?? "Choice one";
            secondChoiceText.text = secondChoice ?? "Choice two";
            firstChoiceButton.interactable = true;
            secondChoiceButton.interactable = true;
            cancelButton.interactable = true;
            promptText.gameObject.SetActive(false);
            modalRoot.SetActive(true);
            bool wasOpen = IsChoiceOpen;
            IsChoiceOpen = true;
            if (!wasOpen) ChoiceVisibilityChanged?.Invoke(true);
            if (EventSystem.current != null)
                EventSystem.current.SetSelectedGameObject(firstChoiceButton.gameObject);
        }

        private void SubmitChoice(int index)
        {
            if (!IsChoiceOpen) return;
            // Close and clear callbacks before invoking gameplay code. This prevents
            // double collection if two input events reach the same frame, and lets
            // gameplay safely show another panel from within its callback.
            Action<int> callback = choiceCallback;
            HideChoices();
            callback?.Invoke(index);
        }

        private void CancelChoices()
        {
            if (!IsChoiceOpen) return;
            Action callback = cancelCallback;
            HideChoices();
            callback?.Invoke();
        }

        /// <summary>Programmatic close; it does not invoke either result callback.</summary>
        public void HideChoices()
        {
            if (!initialized || !IsChoiceOpen) return;
            IsChoiceOpen = false;
            choiceCallback = null;
            cancelCallback = null;
            modalRoot.SetActive(false);
            if (EventSystem.current != null)
                EventSystem.current.SetSelectedGameObject(null);
            ChoiceVisibilityChanged?.Invoke(false);
        }

        public void ShowMessage(string message)
        {
            Initialize();
            messageText.text = message ?? "";
            messageText.gameObject.SetActive(!string.IsNullOrEmpty(message));
            messageExpiresAt = Time.unscaledTime + 7f;
        }

        public void ShowCompletion()
        {
            Initialize();
            HideChoices();
            completionText.gameObject.SetActive(true);
            SetPrompt("");
            ShowMessage("Five memories reunited. You reached the hidden sanctuary.");
        }

        // These helpers keep all runtime uGUI construction in one place. Labels do
        // not intercept raycasts; panels/buttons do, so pointer clicks reach buttons.
        private RectTransform CreatePanel(string name, Transform parent, Color color)
        {
            GameObject obj = new GameObject(name, typeof(RectTransform), typeof(Image));
            obj.transform.SetParent(parent, false);
            obj.GetComponent<Image>().color = color;
            return obj.GetComponent<RectTransform>();
        }

        private Text CreateText(string name, Transform parent, int size, FontStyle style)
        {
            GameObject obj = new GameObject(name, typeof(RectTransform), typeof(Text));
            obj.transform.SetParent(parent, false);
            Text text = obj.GetComponent<Text>();
            text.font = font;
            text.fontSize = size;
            text.fontStyle = style;
            text.color = new Color(0.94f, 0.97f, 0.95f);
            text.supportRichText = false;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            text.raycastTarget = false;
            return text;
        }

        private Button CreateButton(string name, Transform parent, out Text label)
        {
            RectTransform rect = CreatePanel(name, parent, new Color(0.12f, 0.32f, 0.34f));
            Button button = rect.gameObject.AddComponent<Button>();
            button.targetGraphic = rect.GetComponent<Image>();
            ColorBlock colors = button.colors;
            colors.highlightedColor = new Color(0.7f, 1f, 0.92f);
            colors.selectedColor = colors.highlightedColor;
            colors.pressedColor = new Color(0.4f, 0.8f, 0.75f);
            button.colors = colors;
            label = CreateText("Label", rect, 25, FontStyle.Normal);
            label.alignment = TextAnchor.MiddleCenter;
            Stretch(label.rectTransform);
            label.rectTransform.offsetMin = new Vector2(16f, 5f);
            label.rectTransform.offsetMax = new Vector2(-16f, -5f);
            return button;
        }

        private static void SetLayout(GameObject obj, float preferredHeight)
        {
            LayoutElement element = obj.AddComponent<LayoutElement>();
            element.minHeight = preferredHeight;
            element.preferredHeight = preferredHeight;
            element.flexibleHeight = 0f;
        }

        private static void Place(RectTransform rect, Vector2 anchor, Vector2 pivot,
            Vector2 position, Vector2 size)
        {
            rect.anchorMin = rect.anchorMax = anchor;
            rect.pivot = pivot;
            rect.anchoredPosition = position;
            rect.sizeDelta = size;
        }

        private static void Stretch(RectTransform rect)
        {
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = rect.offsetMax = Vector2.zero;
        }
    }
}
