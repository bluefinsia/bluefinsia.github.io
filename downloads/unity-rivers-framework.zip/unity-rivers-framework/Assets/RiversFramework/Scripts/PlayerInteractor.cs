using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>
    /// Proximity-based interaction suitable for a third-person camera. Attach to
    /// Player. E opens a relic's two choices; R repeats the current audio clue.
    /// </summary>
    public sealed class PlayerInteractor : MonoBehaviour
    {
        [SerializeField, Min(0.5f)] private float interactionRadius = 3.4f;
        // Ignore the Player layer here. Default world geometry blocks interaction
        // through ruins; the unobstructed generated scene works with Default.
        [SerializeField] private LayerMask obstructionMask = ~0;
        private ArtifactQuest quest;
        private GameUI ui;
        private ArtifactCollectible candidate;

        public void Initialize(ArtifactQuest owner, GameUI gameUI)
        {
            quest = owner;
            ui = gameUI;
        }

        private void Update()
        {
            if (quest == null || ui == null) return;
            if (ui.IsChoiceOpen || quest.JourneyCompleted)
            {
                ui.SetPrompt("");
                return;
            }
            if (Input.GetKeyDown(KeyCode.R)) quest.ReplayClue();
            candidate = FindNearest();
            if (candidate == null) { ui.SetPrompt(""); return; }
            bool ready = quest.CanInteract(candidate);
            ui.SetPrompt(ready ? "[E] Examine " + candidate.Definition.displayName :
                "This relic is silent. Follow the current song clue first.");
            if (ready && Input.GetKeyDown(KeyCode.E)) OpenChoices(candidate);
        }

        private ArtifactCollectible FindNearest()
        {
            ArtifactCollectible nearest = null;
            float bestDistance = interactionRadius * interactionRadius;
            // Five registered objects: a direct scan is cheaper and clearer than
            // allocating physics overlap arrays every rendered frame.
            foreach (ArtifactCollectible artifact in quest.Artifacts)
            {
                if (artifact == null || artifact.IsCollected) continue;
                Vector3 delta = artifact.transform.position - transform.position;
                float distance = delta.sqrMagnitude;
                if (distance > bestDistance) continue;
                Vector3 origin = transform.position + Vector3.up * 1.3f;
                Vector3 target = artifact.transform.position + Vector3.up * 1.1f;
                // Root colliders are on Player and excluded by the bootstrap.
                // Relic meshes have no collider, so a hit represents world cover.
                if (Physics.Linecast(origin, target, obstructionMask, QueryTriggerInteraction.Ignore)) continue;
                bestDistance = distance;
                nearest = artifact;
            }
            return nearest;
        }

        private void OpenChoices(ArtifactCollectible artifact)
        {
            ArtifactDefinition data = artifact.Definition;
            ui.ShowChoices(data.displayName, data.description, data.preserveChoice,
                data.retuneChoice, choice =>
                {
                    // Validate range and quest state AGAIN after the menu closes;
                    // movement from other components must not allow remote pickup.
                    if ((artifact.transform.position - transform.position).sqrMagnitude >
                        interactionRadius * interactionRadius ||
                        Physics.Linecast(transform.position + Vector3.up * 1.3f,
                            artifact.transform.position + Vector3.up * 1.1f, obstructionMask,
                            QueryTriggerInteraction.Ignore) || !quest.TryResolve(artifact, choice))
                        ui.ShowMessage("Move closer and follow the current clue to interact.");
                }, () => ui.ShowMessage("Take your time. The song will wait."));
        }

        public void SetObstructionMask(LayerMask mask) => obstructionMask = mask;
    }
}
