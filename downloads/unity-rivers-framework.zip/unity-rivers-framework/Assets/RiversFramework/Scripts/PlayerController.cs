using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>
    /// Third-person locomotion for a CharacterController. Attach this to the
    /// Player root, whose origin is at its feet. No Rigidbody is required.
    /// Uses Unity's built-in Input Manager: Horizontal, Vertical, and Jump.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(CharacterController))]
    public sealed class PlayerController : MonoBehaviour
    {
        [Header("References")]
        [Tooltip("Usually the Main Camera. Movement follows its horizontal facing direction.")]
        [SerializeField] private Transform movementCamera;

        [Header("Movement")]
        [SerializeField, Min(0f)] private float walkSpeed = 5f;
        [SerializeField, Min(0f)] private float sprintSpeed = 8f;
        [SerializeField, Min(0f)] private float acceleration = 24f;
        [SerializeField, Min(0.01f)] private float rotationSmoothTime = 0.12f;

        [Header("Jump and gravity")]
        [SerializeField, Min(0.1f)] private float jumpHeight = 1.6f;
        [SerializeField, Min(0.1f)] private float doubleJumpHeight = 1.3f;
        [Tooltip("Must be negative; metres per second squared.")]
        [SerializeField] private float gravity = -25f;
        [SerializeField, Min(1f)] private float terminalFallSpeed = 40f;
        [Tooltip("A small downward speed keeps the controller touching slopes.")]
        [SerializeField, Min(0.1f)] private float groundedStickSpeed = 2f;

        private CharacterController controller;
        private Vector3 horizontalVelocity;
        private float verticalVelocity;
        private float turnVelocity;
        private int jumpsUsed;
        private bool controlsEnabled = true;

        /// <summary>
        /// Dialogue/UI can disable movement without disabling this component.
        /// Gravity keeps running, so opening a choice in mid-air cannot freeze
        /// the player. Jump presses while disabled are discarded, never queued.
        /// </summary>
        public bool ControlsEnabled
        {
            get { return controlsEnabled; }
            set
            {
                controlsEnabled = value;
                if (!value)
                {
                    horizontalVelocity = Vector3.zero;
                    turnVelocity = 0f;
                }
            }
        }

        /// <summary>Allows an optional bootstrap script to assign the camera.</summary>
        public Transform MovementCamera
        {
            get { return movementCamera; }
            set { movementCamera = value; }
        }

        public bool IsGrounded { get { return controller != null && controller.isGrounded; } }

        private void Awake()
        {
            controller = GetComponent<CharacterController>();
            if (movementCamera == null && Camera.main != null)
                movementCamera = Camera.main.transform;
        }

        private void Update()
        {
            if (!controller.enabled || Time.deltaTime <= 0f)
                return;

            float dt = Time.deltaTime;

            // isGrounded describes the preceding Move call. Only reset jumps
            // while descending; the contact reported on the takeoff frame must
            // not reset the jump counter and accidentally allow a third jump.
            bool grounded = controller.isGrounded && verticalVelocity <= 0f;
            if (grounded)
            {
                verticalVelocity = -groundedStickSpeed;
                jumpsUsed = 0;
            }
            else if (jumpsUsed == 0)
            {
                // Walking off a ledge spends the ground jump. The player still
                // has one air jump, just as after a normal first jump.
                jumpsUsed = 1;
            }

            Vector2 input = controlsEnabled
                ? new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"))
                : Vector2.zero;
            input = Vector2.ClampMagnitude(input, 1f); // No faster diagonal movement.

            Vector3 forward = movementCamera != null ? movementCamera.forward : Vector3.forward;
            forward.y = 0f;
            if (forward.sqrMagnitude < 0.001f)
                forward = Vector3.forward; // Safe if a camera looks straight down.
            forward.Normalize();
            Vector3 right = Vector3.Cross(Vector3.up, forward);
            Vector3 desiredDirection = forward * input.y + right * input.x;
            float speed = Input.GetKey(KeyCode.LeftShift) ? sprintSpeed : walkSpeed;
            Vector3 desiredVelocity = desiredDirection * speed;

            // Stop immediately for dialogue; normal movement accelerates gently.
            horizontalVelocity = controlsEnabled
                ? Vector3.MoveTowards(horizontalVelocity, desiredVelocity, acceleration * dt)
                : Vector3.zero;

            if (desiredDirection.sqrMagnitude > 0.001f)
            {
                float angle = Mathf.Atan2(desiredDirection.x, desiredDirection.z) * Mathf.Rad2Deg;
                float smoothed = Mathf.SmoothDampAngle(transform.eulerAngles.y, angle,
                    ref turnVelocity, rotationSmoothTime);
                transform.rotation = Quaternion.Euler(0f, smoothed, 0f);
            }

            // GetButtonDown is sampled once per frame, with a maximum of two
            // accepted presses before landing. Each jump replaces vertical speed
            // so the air jump feels consistent even while falling.
            if (controlsEnabled && Input.GetButtonDown("Jump") && jumpsUsed < 2)
            {
                float height = jumpsUsed == 0 ? jumpHeight : doubleJumpHeight;
                verticalVelocity = Mathf.Sqrt(height * -2f * gravity);
                jumpsUsed++;
            }

            verticalVelocity = Mathf.Max(verticalVelocity + gravity * dt, -terminalFallSpeed);
            Vector3 velocity = horizontalVelocity + Vector3.up * verticalVelocity;
            CollisionFlags collision = controller.Move(velocity * dt);

            // Do not continue pushing upwards into a ceiling. A floor contact
            // resets the jump budget only while moving downwards.
            if ((collision & CollisionFlags.Above) != 0 && verticalVelocity > 0f)
                verticalVelocity = 0f;
            if ((collision & CollisionFlags.Below) != 0 && verticalVelocity < 0f)
            {
                verticalVelocity = -groundedStickSpeed;
                jumpsUsed = 0;
            }
        }

        /// <summary>
        /// Use for spawning/respawning after terrain generation. Temporarily
        /// disabling the controller avoids an old collision position fighting
        /// the new transform. The position is the Player root's feet position.
        /// </summary>
        public void Teleport(Vector3 feetPosition)
        {
            if (controller == null)
                controller = GetComponent<CharacterController>();
            bool wasEnabled = controller.enabled;
            controller.enabled = false;
            transform.position = feetPosition;
            controller.enabled = wasEnabled;
            horizontalVelocity = Vector3.zero;
            verticalVelocity = 0f;
            jumpsUsed = 0;
            turnVelocity = 0f;
        }

        private void OnValidate()
        {
            gravity = -Mathf.Max(0.1f, Mathf.Abs(gravity));
            sprintSpeed = Mathf.Max(sprintSpeed, walkSpeed);
        }
    }
}
