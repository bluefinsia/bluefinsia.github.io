using System;
using System.Collections.Generic;
using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>
    /// The single authority for ordered progression. Neither a UI button nor an
    /// artifact increments the counter directly: every discovery is validated here.
    /// Attach to GameSystems alongside the bootstrap and world generator.
    /// </summary>
    public sealed class ArtifactQuest : MonoBehaviour
    {
        public const int RequiredArtifacts = 5;
        [SerializeField] private ArtifactDefinition[] definitions;
        [SerializeField] private AudioSource songSource;

        public event Action ProgressChanged;
        public event Action AllArtifactsCollected;
        public event Action JourneyFinished;
        public event Action<ArtifactCollectible, int> ArtifactResolved;

        private readonly List<ArtifactCollectible> artifacts = new List<ArtifactCollectible>();
        public IReadOnlyList<ArtifactCollectible> Artifacts => artifacts;
        public int CollectedCount { get; private set; }
        public int RetunedCount { get; private set; }
        public bool AllCollected => CollectedCount == RequiredArtifacts;
        public bool JourneyCompleted { get; private set; }
        public ArtifactDefinition CurrentClue => AllCollected ? null : definitions[CollectedCount];
        public string FinalLyric => "Thắp đèn ta sẽ chơi trăng ngoài thềm.";
        public string FinalHint => "All five memories resonate. Follow the final causeway southwest from the four stones to the moonlit threshold.";

        public void Initialize()
        {
            // Do not discard authored content when it is valid. An invalid count
            // gets a complete sample trail so the generated scene stays playable.
            if (definitions == null || definitions.Length != RequiredArtifacts)
                definitions = CreateDefaultDefinitions();
            for (int i = 0; i < definitions.Length; i++)
                if (definitions[i] == null) definitions[i] = CreateDefaultDefinitions()[i];

            if (songSource == null) songSource = gameObject.AddComponent<AudioSource>();
            songSource.playOnAwake = false;
            songSource.loop = false;
            songSource.spatialBlend = 0f; // A clear song clue, rather than positional ambience.
            PlayCurrentClue();
        }

        public ArtifactDefinition GetDefinition(int index) => definitions[index];

        public void Register(ArtifactCollectible artifact)
        {
            if (artifact != null && !artifacts.Contains(artifact)) artifacts.Add(artifact);
        }

        public bool CanInteract(ArtifactCollectible artifact)
        {
            return artifact != null && !JourneyCompleted && !AllCollected &&
                   !artifact.IsCollected && artifact.Index == CollectedCount &&
                   artifacts.Contains(artifact);
        }

        public bool TryResolve(ArtifactCollectible artifact, int choice)
        {
            // Also rejects stale callbacks, double clicks, and out-of-order finds.
            if ((choice != 0 && choice != 1) || !CanInteract(artifact)) return false;
            artifact.MarkCollected(choice);
            CollectedCount++;
            if (choice == 1) RetunedCount++;
            PlayCurrentClue();
            ProgressChanged?.Invoke();
            ArtifactResolved?.Invoke(artifact, choice);
            if (AllCollected) AllArtifactsCollected?.Invoke();
            return true;
        }

        public bool CompleteJourney()
        {
            // The hidden-location component calls this only after arrival.
            // Merely collecting five artifacts never finishes the game remotely.
            if (!AllCollected || JourneyCompleted) return false;
            JourneyCompleted = true;
            if (songSource != null) songSource.Stop();
            JourneyFinished?.Invoke();
            return true;
        }

        public void ReplayClue() => PlayCurrentClue();

        private void PlayCurrentClue()
        {
            if (songSource == null) return;
            songSource.Stop();
            ArtifactDefinition clue = CurrentClue;
            if (clue != null && clue.songClip != null)
            {
                songSource.clip = clue.songClip;
                songSource.Play();
            }
        }

        private static ArtifactDefinition[] CreateDefaultDefinitions()
        {
            // Excerpts follow the supplied GDD. Locations/technology are an
            // original game interpretation, not a claim about the song's meaning.
            return new[]
            {
                new ArtifactDefinition {
                    displayName = "01 · Pagoda resonance bell",
                    songLine = "Lên chùa bẻ một cành sen,",
                    explorationHint = "Seek the ruined pagoda on the western ridge. A bell remembers the way.",
                    description = "An ancient bell contains a fragment of the researcher's song. Preserve its ecosystem, or retune its dormant signal?"
                },
                new ArtifactDefinition {
                    displayName = "02 · Lotus memory vessel",
                    songLine = "Lên chùa bẻ một cành sen,",
                    explorationHint = "The bell repeats the lotus image. Follow the causeway north to the luminous lotus garden.",
                    description = "Cyanobacteria bloom inside a lotus-shaped archive. Record the living pattern, or awaken its buried circuitry?"
                },
                new ArtifactDefinition {
                    displayName = "03 · Lamplight core",
                    songLine = "Ăn cơm bằng đèn đi cấy sáng trăng.",
                    explorationHint = "Find the old dining terrace in the north. A blue lamp still burns above the flood.",
                    description = "A lamp powered the meals of the vanished gardeners. Observe its warm memory, or tune it to light the new world?"
                },
                new ArtifactDefinition {
                    displayName = "04 · Moonlit seed archive",
                    songLine = "Ăn cơm bằng đèn đi cấy sáng trăng.",
                    explorationHint = "Continue east to the stepped rice terraces. Under moonlight, a seed archive waits.",
                    description = "The last seed archive has become a nursery for unfamiliar life. Preserve its balance, or invite the old machine to help it grow?"
                },
                new ArtifactDefinition {
                    displayName = "05 · Companions' chorus",
                    songLine = "Ba bốn cô có hẹn cùng chăng,\nCó bạn cùng chăng?",
                    explorationHint = "Look for four standing stones on the eastern ridge. Listen for the friends' answering chorus.",
                    description = "Four resonators sing together. Let their new chorus continue, or retune it to send a welcome across the water?"
                }
            };
        }
    }
}
