using System;
using System.Collections.Generic;
using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>
    /// Attach to an empty "World" GameObject with identity rotation and unit scale.
    /// Call Generate before positioning the player, artifacts, or final destination.
    ///
    /// This is a finite, deterministic prototype world, not an infinite streaming
    /// system. A single 257 x 257 heightmap is inexpensive enough for iteration.
    /// Raised routes connect the starting area, five artifact clearings and a final
    /// sanctuary, so every objective can be reached without swimming mechanics.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class OpenWorldGenerator : MonoBehaviour
    {
        [Header("Reproducible terrain")]
        [SerializeField] private int seed = 7321;
        [SerializeField, Min(80f)] private float worldSize = 220f;
        [SerializeField, Min(12f)] private float terrainHeight = 24f;
        [Tooltip("Unity terrain resolutions must be a power of two plus one.")]
        [SerializeField, Range(33, 513)] private int heightmapResolution = 257;
        [SerializeField, Min(1f)] private float noiseScale = 42f;

        [Header("Accessible objective route")]
        [SerializeField, Min(0f)] private float waterLevel = 2.3f;
        [SerializeField, Min(1f)] private float routeGroundHeight = 5.5f;
        [SerializeField, Min(2f)] private float clearingRadius = 7f;
        [SerializeField, Min(1f)] private float causewayHalfWidth = 3.5f;

        [Header("Simple placeholder scenery")]
        [SerializeField, Range(0, 150)] private int ruinPillarCount = 65;
        [SerializeField] private Color groundColor = new Color(0.38f, 0.48f, 0.39f);
        [SerializeField] private Color stoneColor = new Color(0.52f, 0.62f, 0.59f);
        [SerializeField] private Color waterColor = new Color(0.13f, 0.36f, 0.40f);

        // Normalized X/Z positions inside the square terrain. The order follows
        // the narrative: start -> pagoda -> lotus -> lamp -> rice -> companions
        // -> final moonlit sanctuary. Actual quest logic belongs to ArtifactQuest.
        private static readonly Vector2[] Route =
        {
            new Vector2(-0.30f, -0.28f), // Player start.
            new Vector2(-0.31f, -0.06f), // Artifact 0: pagoda bell.
            new Vector2(-0.20f,  0.21f), // Artifact 1: lotus memory.
            new Vector2( 0.05f,  0.30f), // Artifact 2: lamp core.
            new Vector2( 0.30f,  0.15f), // Artifact 3: rice seed archive.
            new Vector2( 0.25f, -0.15f), // Artifact 4: companions resonance.
            new Vector2( 0.02f, -0.26f)  // Final hidden location.
        };

        private GameObject generatedRoot;
        private Terrain terrain;

        // These are objects created with "new" at runtime, never project assets.
        // Keeping explicit ownership prevents accidental deletion of user assets
        // when the world is regenerated or this component is destroyed.
        private readonly List<UnityEngine.Object> ownedResources =
            new List<UnityEngine.Object>();

        /// <summary>World-space water plane height, useful for land-only respawning.</summary>
        public float WaterSurfaceY { get { return transform.position.y + waterLevel; } }

        public Vector3 PlayerSpawnPosition { get { return RoutePosition(0); } }
        public Vector3 FinalLocationPosition { get { return RoutePosition(Route.Length - 1); } }

        /// <summary>Return the ground position for an artifact index from 0 to 4.</summary>
        public Vector3 GetArtifactPosition(int index)
        {
            if (index < 0 || index >= 5)
                throw new ArgumentOutOfRangeException(nameof(index), "Artifact index must be 0 through 4.");

            return RoutePosition(index + 1);
        }

        /// <summary>
        /// Sample the generated TerrainCollider's surface at a world X/Z position.
        /// heightOffset is useful for placing objects whose pivots are at their
        /// centers; for example, a one-meter sphere needs an offset of 0.5 meters.
        /// </summary>
        public Vector3 SurfacePosition(Vector3 position, float heightOffset = 0f)
        {
            if (terrain == null)
                throw new InvalidOperationException("Call OpenWorldGenerator.Generate() before sampling terrain.");

            // SampleHeight accepts world-space X/Z but returns terrain-relative Y.
            float y = terrain.SampleHeight(position) + terrain.transform.position.y;
            return new Vector3(position.x, y + heightOffset, position.z);
        }

        /// <summary>
        /// Build the terrain and scenery. This method intentionally has no Start
        /// counterpart: the scene bootstrap controls generation order explicitly.
        /// Calling it again replaces only this generator's previous output.
        /// </summary>
        public void Generate()
        {
            // Unity Terrain does not support arbitrary parent rotation or scale.
            // Position offsets are supported, but fail clearly for unsupported
            // transforms rather than placing physics and visuals differently.
            if (Quaternion.Angle(transform.rotation, Quaternion.identity) > 0.01f ||
                (transform.lossyScale - Vector3.one).sqrMagnitude > 0.0001f)
            {
                throw new InvalidOperationException("World must have identity rotation and unit world scale.");
            }

            ValidateSettings();
            ReleaseGeneratedObjects();
            generatedRoot = new GameObject("Generated World (owned by OpenWorldGenerator)");
            generatedRoot.transform.SetParent(transform, false);

            // Local System.Random does not change UnityEngine.Random.state, so
            // terrain generation cannot unexpectedly affect gameplay randomness.
            var random = new System.Random(seed);
            float noiseOffsetX = random.Next(1000, 90000);
            float noiseOffsetZ = random.Next(1000, 90000);

            var data = new TerrainData
            {
                name = "Runtime Sanctuary Terrain",
                heightmapResolution = heightmapResolution,
                size = new Vector3(worldSize, terrainHeight, worldSize)
            };
            ownedResources.Add(data);
            var heights = new float[heightmapResolution, heightmapResolution];

            for (int z = 0; z < heightmapResolution; z++)
            {
                for (int x = 0; x < heightmapResolution; x++)
                {
                    float px = (float)x / (heightmapResolution - 1) * worldSize - worldSize * 0.5f;
                    float pz = (float)z / (heightmapResolution - 1) * worldSize - worldSize * 0.5f;
                    float broad = Mathf.PerlinNoise(noiseOffsetX + px / noiseScale,
                        noiseOffsetZ + pz / noiseScale);
                    float detail = Mathf.PerlinNoise(noiseOffsetX + px / (noiseScale * 0.3f),
                        noiseOffsetZ + pz / (noiseScale * 0.3f));
                    float distanceFromCenter = new Vector2(px, pz).magnitude / (worldSize * 0.5f);
                    float island = 1f - SmoothRange(0.60f, 1.25f, distanceFromCenter);
                    float height = (1.0f + broad * 5.0f + detail * 1.2f) * island;

                    // Blend terrain toward an exact constant height around every
                    // objective. Then flatten a causeway between consecutive pads.
                    // A fully flat center avoids burying colliders in noisy slopes.
                    var point = new Vector2(px, pz);
                    float routeWeight = 0f;
                    for (int i = 0; i < Route.Length; i++)
                    {
                        Vector2 center = Route[i] * worldSize;
                        float distance = Vector2.Distance(point, center);
                        routeWeight = Mathf.Max(routeWeight,
                            1f - SmoothRange(clearingRadius, clearingRadius + 5f, distance));

                        if (i > 0)
                        {
                            float pathDistance = DistanceToSegment(point, Route[i - 1] * worldSize, center);
                            routeWeight = Mathf.Max(routeWeight,
                                1f - SmoothRange(causewayHalfWidth, causewayHalfWidth + 3f, pathDistance));
                        }
                    }

                    height = Mathf.Lerp(height, routeGroundHeight, routeWeight);
                    // Unity's heights array is [z, x], with normalized Y values.
                    heights[z, x] = Mathf.Clamp01(height / terrainHeight);
                }
            }

            data.SetHeights(0, 0, heights);
            AddTerrainColor(data);
            GameObject terrainObject = Terrain.CreateTerrainGameObject(data);
            terrainObject.name = "Walkable Terrain";
            terrainObject.transform.SetParent(generatedRoot.transform, false);
            terrainObject.transform.localPosition = new Vector3(-worldSize * 0.5f, 0f, -worldSize * 0.5f);
            terrain = terrainObject.GetComponent<Terrain>();
            terrain.drawInstanced = true;
            terrain.heightmapPixelError = 8f;
            terrain.detailObjectDistance = 0f;
            terrain.treeDistance = 0f;
            // CreateTerrainGameObject also supplies a TerrainCollider using data.
            // The default layer remains enabled so CharacterController can walk.

            Material stone = MakeMaterial("Runtime Ruin Stone", stoneColor);
            Material water = MakeMaterial("Runtime Water Surface", waterColor);
            CreateWater(water);
            CreateRuins(random, stone);
            CreateBounds();
            terrain.Flush();
        }

        private Vector3 RoutePosition(int routeIndex)
        {
            Vector2 point = Route[routeIndex] * worldSize;
            return SurfacePosition(transform.position + new Vector3(point.x, 0f, point.y));
        }

        // Mathf.SmoothStep interpolates between values; it is not the GLSL
        // smoothstep(edge0, edge1, value). Normalize the range explicitly first.
        private static float SmoothRange(float start, float end, float value)
        {
            return Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(start, end, value));
        }

        private static float DistanceToSegment(Vector2 point, Vector2 a, Vector2 b)
        {
            Vector2 delta = b - a;
            float t = delta.sqrMagnitude > 0f
                ? Mathf.Clamp01(Vector2.Dot(point - a, delta) / delta.sqrMagnitude)
                : 0f;
            return Vector2.Distance(point, a + delta * t);
        }

        private void AddTerrainColor(TerrainData data)
        {
            // A generated 1x1 swatch supplies the TerrainLayer's diffuse color;
            // no texture download, imported artwork, or package is required.
            var swatch = new Texture2D(1, 1, TextureFormat.RGBA32, false)
            {
                name = "Runtime Ground Color"
            };
            swatch.SetPixel(0, 0, groundColor);
            swatch.Apply(false, true);
            ownedResources.Add(swatch);
            var layer = new TerrainLayer
            {
                name = "Runtime Ground Layer",
                diffuseTexture = swatch,
                tileSize = new Vector2(16f, 16f),
                metallic = 0f,
                smoothness = 0.05f
            };
            ownedResources.Add(layer);
            data.terrainLayers = new[] { layer };
            // Explicitly paint the only layer rather than relying on editor
            // defaults when TerrainData is created entirely from code.
            data.alphamapResolution = 16;
            var weights = new float[16, 16, 1];
            for (int z = 0; z < 16; z++)
                for (int x = 0; x < 16; x++) weights[z, x, 0] = 1f;
            data.SetAlphamaps(0, 0, weights);
        }

        private Material MakeMaterial(string materialName, Color color)
        {
            // Built-in and URP projects use different lit shader names. The
            // starter uses Built-in; this fallback keeps simple placeholders
            // usable if the project later switches to URP.
            bool usesRenderPipeline = UnityEngine.Rendering.GraphicsSettings.currentRenderPipeline != null;
            Shader shader = Shader.Find(usesRenderPipeline ? "Universal Render Pipeline/Lit" : "Standard");
            if (shader == null)
                shader = Shader.Find("Standard");
            if (shader == null)
                throw new InvalidOperationException("No supported lit shader found; use Built-in or URP.");

            var material = new Material(shader) { name = materialName };
            material.color = color;
            if (material.HasProperty("_Smoothness")) material.SetFloat("_Smoothness", 0.3f);
            if (material.HasProperty("_Glossiness")) material.SetFloat("_Glossiness", 0.3f);
            ownedResources.Add(material);
            return material;
        }

        private void CreateWater(Material material)
        {
            GameObject water = GameObject.CreatePrimitive(PrimitiveType.Plane);
            water.name = "Water (visual only, no swimming physics)";
            water.transform.SetParent(generatedRoot.transform, false);
            water.transform.localPosition = new Vector3(0f, waterLevel, 0f);
            // Unity's built-in Plane is 10 by 10 meters before scaling.
            water.transform.localScale = Vector3.one * (worldSize / 10f);
            water.GetComponent<Renderer>().sharedMaterial = material;
            Collider collider = water.GetComponent<Collider>();
            collider.enabled = false;
            DestroyOwned(collider);
        }

        private void CreateRuins(System.Random random, Material material)
        {
            // Attempts are bounded: even a dense layout cannot hang generation.
            int placed = 0;
            int attempts = 0;
            while (placed < ruinPillarCount && attempts++ < ruinPillarCount * 20)
            {
                float x = ((float)random.NextDouble() - 0.5f) * worldSize * 0.88f;
                float z = ((float)random.NextDouble() - 0.5f) * worldSize * 0.88f;
                var local = new Vector2(x, z);
                bool blocksRoute = false;
                for (int i = 0; i < Route.Length; i++)
                {
                    if (Vector2.Distance(local, Route[i] * worldSize) < clearingRadius + 3f ||
                        (i > 0 && DistanceToSegment(local, Route[i - 1] * worldSize,
                            Route[i] * worldSize) < causewayHalfWidth + 3f))
                    {
                        blocksRoute = true;
                        break;
                    }
                }
                if (blocksRoute) continue;

                Vector3 ground = SurfacePosition(transform.position + new Vector3(x, 0f, z));
                if (ground.y < transform.position.y + waterLevel + 0.3f) continue;
                float height = Mathf.Lerp(1.5f, 5f, (float)random.NextDouble());
                GameObject pillar = CreatePrimitive(PrimitiveType.Cylinder, "Ancient Ruin Pillar",
                    ground + Vector3.up * height * 0.5f,
                    new Vector3(1.1f, height * 0.5f, 1.1f), material);
                pillar.transform.rotation = Quaternion.Euler(0f, (float)random.NextDouble() * 360f, 0f);
                placed++;
            }
        }

        private GameObject CreatePrimitive(PrimitiveType type, string objectName,
            Vector3 position, Vector3 scale, Material material)
        {
            GameObject item = GameObject.CreatePrimitive(type);
            item.name = objectName;
            item.transform.SetParent(generatedRoot.transform, false);
            item.transform.position = position;
            item.transform.localScale = scale;
            item.GetComponent<Renderer>().sharedMaterial = material;
            // Primitive colliders are retained on ruins; these are physical props.
            return item;
        }

        private void CreateBounds()
        {
            // A finite terrain needs a boundary so players cannot walk off its
            // collision surface. These invisible walls stop horizontal escape;
            // replace them with authored cliffs or extend into streaming later.
            float half = worldSize * 0.5f;
            AddBoundary("West Boundary", new Vector3(-half, 10f, 0f), new Vector3(1f, 30f, worldSize));
            AddBoundary("East Boundary", new Vector3(half, 10f, 0f), new Vector3(1f, 30f, worldSize));
            AddBoundary("South Boundary", new Vector3(0f, 10f, -half), new Vector3(worldSize, 30f, 1f));
            AddBoundary("North Boundary", new Vector3(0f, 10f, half), new Vector3(worldSize, 30f, 1f));
        }

        private void AddBoundary(string objectName, Vector3 localPosition, Vector3 size)
        {
            var boundary = new GameObject(objectName);
            boundary.transform.SetParent(generatedRoot.transform, false);
            boundary.transform.localPosition = localPosition;
            boundary.AddComponent<BoxCollider>().size = size;
        }

        private void ValidateSettings()
        {
            worldSize = Mathf.Max(80f, worldSize);
            terrainHeight = Mathf.Max(12f, terrainHeight);
            noiseScale = Mathf.Max(1f, noiseScale);
            heightmapResolution = Mathf.ClosestPowerOfTwo(Mathf.Clamp(heightmapResolution - 1, 32, 512)) + 1;
            waterLevel = Mathf.Clamp(waterLevel, 0f, terrainHeight - 3f);
            routeGroundHeight = Mathf.Clamp(routeGroundHeight, waterLevel + 1.2f, terrainHeight - 1f);
            clearingRadius = Mathf.Max(2f, clearingRadius);
            causewayHalfWidth = Mathf.Max(1f, causewayHalfWidth);
        }

        private void OnValidate()
        {
            ValidateSettings();
        }

        private void OnDestroy()
        {
            ReleaseGeneratedObjects();
        }

        private void ReleaseGeneratedObjects()
        {
            if (generatedRoot != null)
            {
                // Destroy is deferred in Play Mode. Disable the old hierarchy
                // first so a same-frame regeneration cannot leave two colliders.
                generatedRoot.SetActive(false);
                DestroyOwned(generatedRoot);
                generatedRoot = null;
            }
            terrain = null;
            foreach (UnityEngine.Object resource in ownedResources)
                if (resource != null) DestroyOwned(resource);
            ownedResources.Clear();
        }

        private static void DestroyOwned(UnityEngine.Object resource)
        {
            if (Application.isPlaying) Destroy(resource);
            else DestroyImmediate(resource);
        }
    }
}
