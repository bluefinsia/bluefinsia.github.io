using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>
    /// Third-person orbit camera with a small follow delay and obstruction
    /// handling. Attach to Main Camera and assign the Player root as Target.
    /// Uses LateUpdate so player movement is complete before the camera follows.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Camera))]
    public sealed class SmoothFollowCamera : MonoBehaviour
    {
        [Header("Follow")]
        [SerializeField] private Transform target;
        [Tooltip("World-space offset above the Player root's feet.")]
        [SerializeField] private Vector3 targetOffset = new Vector3(0f, 1.4f, 0f);
        [SerializeField, Min(0.2f)] private float distance = 6f;
        [SerializeField, Min(0.01f)] private float followSmoothTime = 0.12f;
        [SerializeField, Min(0.01f)] private float rotationSmoothTime = 0.08f;

        [Header("Orbit (hold right mouse button)")]
        [SerializeField] private bool enableMouseOrbit = true;
        [SerializeField, Min(0f)] private float mouseSensitivity = 3f;
        [SerializeField] private float yaw = 0f;
        [SerializeField] private float pitch = 18f;
        [SerializeField] private float minPitch = -10f;
        [SerializeField] private float maxPitch = 65f;

        [Header("Obstruction")]
        [Tooltip("Include terrain/ruins, EXCLUDE the Player layer. Ignore UI and triggers.")]
        [SerializeField] private LayerMask obstructionMask = Physics.DefaultRaycastLayers;
        [SerializeField, Min(0.01f)] private float collisionRadius = 0.2f;
        [SerializeField, Min(0.01f)] private float wallPadding = 0.08f;

        private Vector3 followVelocity;
        private Vector3 smoothedPivot;
        private bool initialized;

        /// <summary>Disable orbit input during UI/dialogue; following continues.</summary>
        public bool ControlsEnabled { get; set; } = true;

        public Transform Target
        {
            get { return target; }
            set
            {
                target = value;
                initialized = false;
            }
        }

        /// <summary>Useful when assembling the scene from an Editor helper.</summary>
        public LayerMask ObstructionMask
        {
            get { return obstructionMask; }
            set { obstructionMask = value; }
        }

        private void LateUpdate()
        {
            if (target == null || Time.deltaTime <= 0f)
                return;

            if (ControlsEnabled && enableMouseOrbit && Input.GetMouseButton(1))
            {
                // Mouse axes are already per-frame deltas; do not multiply by
                // deltaTime or orbit speed will change with the frame rate.
                yaw += Input.GetAxis("Mouse X") * mouseSensitivity;
                pitch -= Input.GetAxis("Mouse Y") * mouseSensitivity;
                pitch = Mathf.Clamp(pitch, minPitch, maxPitch);
            }

            Vector3 desiredPivot = target.position + targetOffset;
            if (!initialized)
            {
                smoothedPivot = desiredPivot;
                initialized = true;
            }
            smoothedPivot = Vector3.SmoothDamp(smoothedPivot, desiredPivot,
                ref followVelocity, followSmoothTime);

            Quaternion orbitRotation = Quaternion.Euler(pitch, yaw, 0f);
            Vector3 desiredPosition = smoothedPivot - orbitRotation * Vector3.forward * distance;
            Vector3 obstructionDirection = desiredPosition - desiredPivot;
            float obstructionDistance = obstructionDirection.magnitude;

            // Cast from the real player pivot rather than its delayed position:
            // even while the player turns a corner, the camera stays on the
            // player's side of a wall. Triggers (artifacts/water) do not block it.
            RaycastHit hit;
            if (obstructionDistance > 0.001f && Physics.SphereCast(desiredPivot,
                collisionRadius, obstructionDirection / obstructionDistance, out hit,
                obstructionDistance, obstructionMask, QueryTriggerInteraction.Ignore))
            {
                desiredPosition = desiredPivot + obstructionDirection.normalized *
                    Mathf.Max(0f, hit.distance - wallPadding);
            }

            // Smooth the FOLLOW PIVOT above; apply the collision-corrected camera
            // position immediately. Smoothing the final position after the cast
            // could make the camera drift through a newly encountered wall.
            transform.position = desiredPosition;
            Vector3 lookDirection = smoothedPivot - transform.position;
            if (lookDirection.sqrMagnitude > 0.001f)
            {
                Quaternion wantedRotation = Quaternion.LookRotation(lookDirection, Vector3.up);
                float blend = 1f - Mathf.Exp(-Time.deltaTime / rotationSmoothTime);
                transform.rotation = Quaternion.Slerp(transform.rotation, wantedRotation, blend);
            }
        }

        /// <summary>Remove follow lag immediately after a teleport.</summary>
        public void SnapToTarget()
        {
            initialized = false;
            followVelocity = Vector3.zero;
            if (target == null)
                return;
            smoothedPivot = target.position + targetOffset;
            Quaternion rotation = Quaternion.Euler(pitch, yaw, 0f);
            transform.SetPositionAndRotation(smoothedPivot - rotation * Vector3.forward * distance, rotation);
            initialized = true;
        }

        private void OnValidate()
        {
            maxPitch = Mathf.Clamp(maxPitch, -80f, 80f);
            minPitch = Mathf.Clamp(minPitch, -80f, maxPitch);
            pitch = Mathf.Clamp(pitch, minPitch, maxPitch);
        }
    }
}
