using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>
    /// A persistent world relic, collected through an explicit choice rather than
    /// touch. Attach to each Artifact root; put its animated mesh under Visual.
    /// </summary>
    public sealed class ArtifactCollectible : MonoBehaviour
    {
        [SerializeField] private Transform visual;
        [SerializeField] private Renderer visualRenderer;
        [SerializeField] private float bobHeight = 0.16f;
        [SerializeField] private float rotationSpeed = 24f;
        private ArtifactQuest quest;
        private Vector3 visualRestPosition;
        private MaterialPropertyBlock properties;
        public int Index { get; private set; }
        public bool IsCollected { get; private set; }
        public ArtifactDefinition Definition => quest.GetDefinition(Index);

        public void Initialize(ArtifactQuest owner, int index, Transform mesh)
        {
            quest = owner;
            Index = index;
            visual = mesh;
            if (visual != null)
            {
                visualRestPosition = visual.localPosition;
                visualRenderer = visual.GetComponent<Renderer>();
            }
            properties = new MaterialPropertyBlock();
            quest.Register(this);
        }

        private void Update()
        {
            if (visual == null) return;
            // Animate the mesh only: the interaction anchor never moves away.
            visual.localPosition = visualRestPosition + Vector3.up *
                (Mathf.Sin(Time.time * 1.6f + Index) * bobHeight);
            visual.Rotate(Vector3.up, rotationSpeed * Time.deltaTime, Space.Self);
        }

        public void MarkCollected(int choice)
        {
            if (IsCollected) return;
            IsCollected = true;
            // A preserved relic turns green; a retuned relic glows gold. Keeping
            // the relic visible makes the player's environmental choice legible.
            Color color = choice == 0 ? new Color(0.2f, 0.95f, 0.7f) : new Color(1f, 0.68f, 0.2f);
            if (visualRenderer != null)
            {
                // Property blocks avoid allocating one material per discovery.
                visualRenderer.GetPropertyBlock(properties);
                properties.SetColor("_Color", color);       // Built-in Standard.
                properties.SetColor("_BaseColor", color);   // URP-compatible tint.
                properties.SetColor("_EmissionColor", color * 1.5f);
                visualRenderer.SetPropertyBlock(properties);
            }
        }
    }
}
