# There Are Rivers in the Sky — Unity base framework

A third-person, 3D science-fiction exploration prototype for **Unity 2022.3 LTS** and the **Built-in Render Pipeline**. This project is separate from the existing HTML game; it does not replace or modify that repository.

The supplied GDD is design reference. Its five highlighted clue images become an original playable trail through a post-human, flooded landscape. This is a desktop foundation: it does not implement the GDD's optional VR or photography features.

## Quick start

1. Install Unity **2022.3 LTS** through Unity Hub. This starter's version file selects **2022.3.62f1**; another 2022.3 LTS patch can upgrade it when prompted.
2. Extract the project, then **Unity Hub → Add → Add project from disk**, selecting the folder containing `Assets`, `Packages`, and `ProjectSettings`. Let Unity generate its local Library and restore the included Unity UI package. Alternatively copy `Assets/RiversFramework` into an existing **3D Core / Built-in** Unity 2022.3 project.
3. Under **Edit → Project Settings → Player → Other Settings**, use **Active Input Handling: Input Manager (Old)**. If using Both in another project, install/configure its Input System separately. This starter deliberately uses no Input System package. Its `InputManager.asset` includes Horizontal, Vertical, Jump, Mouse X, Mouse Y, Submit, and Cancel; do not overwrite an existing project's input settings blindly.
4. Select **Tools → Rivers in the Sky → Create Demo Scene**. Save it as `Assets/RiversDemo.unity`. The menu protects unsaved scene work and creates one GameSystems object. Press **Play**, then click inside the Game view.
5. The runtime bootstrap creates the terrain, researcher, camera, artifacts, lights, sanctuary, Canvas, and EventSystem. No prefab references, art downloads, song recording, or hand-wiring are required for the generated demo.

**For a player build:** save the demo scene, add it under **File → Build Settings → Scenes In Build**, then build for the intended platform. Since this prototype constructs materials and primitives in code, keep `Standard` in **Project Settings → Graphics → Always Included Shaders**. The provided Editor menu also creates inactive primitive references in the saved scene to retain the mesh/collider types used by runtime generation. Keep that reference group for builds. Test the resulting executable; Editor success alone is not build validation.

## Controls

| Input | Action |
| --- | --- |
| WASD / arrows | Camera-relative movement |
| Left Shift | Sprint |
| Space, then Space in the air | Jump, then one double jump |
| Hold right mouse + move mouse | Orbit camera |
| E near the current artifact | Open choices |
| Mouse click or arrows + Enter | Choose an action |
| Escape | Cancel choices |
| R | Replay the current clue, if an AudioClip is assigned |
| Home | Return to the starting overlook, keeping discoveries |

Dialogue disables movement and orbit while gravity continues. Falling into water returns the player to the overlook. There is no swimming system. The cursor remains available for UI; right mouse controls orbit without locking it.

## Which GameObject gets each script?

All runtime scripts use the namespace `RiversInTheSky`. Each class is in its own file under `Assets/RiversFramework/Scripts`.

| Script | Attach to | Purpose / important references |
| --- | --- | --- |
| `GameBootstrap.cs` | **GameSystems**, one per demo scene | Assembles and wires the entire demo. Creates missing world/quest components. Keep transform rotation identity and scale `(1,1,1)`. |
| `OpenWorldGenerator.cs` | **GameSystems** in this demo; or a separate **World** object | Generates terrain/causeways, water, ruins, boundaries. Must call `Generate()` before position queries. World rotation must be identity and scale one. |
| `ArtifactQuest.cs` | **GameSystems** | Owns ordered collection and completion events. Inspector Definitions can contain exactly five custom entries; otherwise sample entries are created. |
| `PlayerController.cs` | **Player** root | Requires CharacterController; feet-origin root. Assign Main Camera to Movement Camera. No Rigidbody. |
| `SmoothFollowCamera.cs` | **Main Camera** | Assign Player to Target; exclude the Player layer from Obstruction Mask. Smooth following uses LateUpdate and a small delay. |
| `PlayerInteractor.cs` | **Player** root | Finds a nearby, unobstructed artifact. Bootstrap initializes quest/UI and excludes the player's layer from raycasts. |
| `ArtifactCollectible.cs` | Each of the **five Artifact roots** | Bootstrap calls `Initialize(quest, index, visual)` with index 0–4. Visual is a child mesh; its collider must be disabled/removed. |
| `HiddenLocation.cs` | **HiddenSanctuary** root | Bootstrap initializes quest, player Transform, and a reveal-visual child. Reveals after five discoveries; finishes only on player arrival. |
| `GameUI.cs` | **GameUI** child | Builds its own Canvas, count, song clue, hint, choices and ending text. No TMP dependency. |
| `ArtifactDefinition.cs` | **Do not attach** | Serializable data inside ArtifactQuest; it is not a MonoBehaviour. |
| `Editor/CreateRiversDemo.cs` | **Do not attach** | Editor-only menu. Keep this file in an Editor folder. |

Do not manually add duplicate Players, Cameras, Canvases, or artifacts alongside the bootstrap. For an authored scene, replace the bootstrap with your own composition code and reuse the individual components.

### Runtime hierarchy

```text
GameSystems
├── Generated World
│   ├── Walkable Terrain (Terrain + TerrainCollider)
│   ├── Water (visual only)
│   ├── Ancient Ruin Pillars
│   └── Boundary colliders
├── Player (CharacterController, PlayerController, PlayerInteractor)
│   ├── Researcher capsule (visual only)
│   └── Visor
├── Main Camera (Camera, AudioListener, SmoothFollowCamera)
├── GameUI (GameUI)
│   ├── Runtime Canvas
│   └── UI EventSystem
├── Moon light
├── 01 … 05 Artifact roots (ArtifactCollectible)
│   ├── Pedestal (collider below the interaction ray)
│   └── Visual (renderer, no collider)
└── HiddenSanctuary (HiddenLocation)
    └── Revealed sanctuary (initially inactive)
```

The Editor-created **Primitive Build References** group stays inactive; it is not gameplay scenery. If a Main Camera already exists, the bootstrap reuses it. Prefer the supplied empty-scene workflow. In an authored scene, ensure exactly one active AudioListener and an active EventSystem; an existing inactive EventSystem is not automatically activated.

## Player and camera settings

The bootstrap configures CharacterController height `1.8`, center `(0,0.9,0)`, radius `0.35`, skin width `0.04`, step offset `0.3`, slope limit `50`. Only the controller collides; visual capsule and visor do not.

Player defaults: walk `5 m/s`, sprint `8 m/s`, acceleration `24`, gravity `-25`, first jump height `1.6 m`, second `1.3 m`. Landing resets the two-jump budget; walking off a ledge consumes the ground jump and leaves one air jump. No queued jump fires when closing a dialogue. `Teleport` temporarily disables the controller and clears velocities.

Camera defaults: distance `6 m`, pivot height `1.4 m`, follow delay `0.12 s`, rotation smoothing `0.08 s`, pitch `18°`. A sphere cast prevents the camera from following through terrain/ruins. The final collision correction is immediate, so smoothing cannot push the camera through a newly encountered wall.

The demo puts Player and its visual children on Unity's built-in **Ignore Raycast** layer 2. This avoids editing project layers. Terrain and ruins stay on Default. For a larger project create a dedicated Player layer and exclude it from both camera and interactor obstruction masks. Do not exclude the terrain/ruin layers.

## Five artifacts and the song trail

Text excerpts come from the supplied GDD's version of **Đi Cấy**. English hints and sci-fi relics are game interpretations. The order uses the GDD's magenta highlights: pagoda → lotus → lamplight → rice planting → companions. Two successive clues intentionally share a line; the hint selects a different image within it.

| Step | Clue image / Vietnamese text | Destination and relic |
| --- | --- | --- |
| 1 | “Lên chùa…” | Western ruined pagoda: resonance bell |
| 2 | “…bẻ một cành sen” | Northwest lotus garden: memory vessel |
| 3 | “Ăn cơm bằng đèn…” | Northern dining terrace: lamplight core |
| 4 | “…đi cấy sáng trăng” | Eastern rice terrace: seed archive |
| 5 | “Ba bốn cô… / Có bạn cùng chăng?” | Eastern ridge: four companion stones and a chorus relic |
| Arrival | “…chơi trăng ngoài thềm” | Follow the final causeway southwest to the revealed moonlit sanctuary |

The world is placeholder geometry; the named gardens, pagoda, rice terraces and lamp are narrative destinations with distinct primitive relics, not finished environment artwork. Replace those meshes with authored assets later.

Each interaction offers **Observe and preserve** or **Retune the ancient device**. Both collect the artifact and reveal the next clue. Preserve colors the relic green; retune colors it gold and progressively warms the moonlight and fog. Choices affect presentation without creating an unwinnable route. Collected relics remain visible as landmarks.

The quest is authoritative: out-of-order objects explain that the current clue must be followed, duplicate/stale submissions are rejected, and collected count stays between zero and five. Interaction requires proximity and line of sight, including when confirming a choice. Five discoveries reveal the sanctuary but do not finish the journey until the player physically arrives. All progress is in-memory and resets when Play Mode restarts.

To add recorded song clues, expand the **ArtifactQuest → Definitions** array to exactly **5**, author all fields, and assign a **Song Clip** per entry. If no AudioSource is assigned, one is added automatically. Do this before Play so your data persists. Text-only clues work by default; no recording is bundled. For Vietnamese typography, the runtime UI uses Unity's LegacyRuntime font; substitute a font with the glyph coverage/style you need if your target platform renders missing diacritics.

## World generation

`Generate()` creates a deterministic **220 × 220 m** finite open area using a **257 × 257** Perlin-noise heightmap, seven dry clearings, and connecting causeways. The seed changes terrain and scattered ruins; objective-route positions deliberately stay stable. The generator avoids blocking objective clearings with random pillars and adds invisible boundary colliders. Water is a simple opaque, collider-free plane; it is not a fluid simulation.

`PlayerSpawnPosition`, `GetArtifactPosition(index)`, `FinalLocationPosition`, `WaterSurfaceY`, and `SurfacePosition(worldPosition, heightOffset)` are the public placement API. Terrain sampling accounts for a translated World root. The generator owns its runtime TerrainData, materials, TerrainLayer, texture swatch and generated hierarchy; regeneration releases only those owned resources. Regenerating an active quest does not reposition quest objects: regenerate before spawning gameplay objects, or recreate the entire demo scene.

This is not an infinite streaming implementation. To expand it later, split TerrainData into chunks, stream by player distance, keep objective IDs/quest state outside streamed objects, and pool scenery. Swimming, boats, navmesh agents, VR/XR, save/load, authored art, audio assets and production optimization are separate extensions.

## Initialization and customization

The bootstrap calls these steps in order:

1. `world.Generate()` and `quest.Initialize()`.
2. Create CharacterController player at the sampled spawn; connect camera and teleport.
3. Initialize UI and subscribe events.
4. Create/register five artifacts and initialize the hidden location.
5. Initialize interactor and display the first clue.

`ArtifactQuest.ProgressChanged`, `ArtifactResolved`, `AllArtifactsCollected`, and `JourneyFinished` let other systems respond without touching UI code. `GameUI.ChoiceVisibilityChanged` gates movement/orbit. `PlayerController.ControlsEnabled` stops input while still applying gravity. The framework includes comments explaining these boundaries and safety checks.

The project targets Built-in shaders. A URP/HDRP migration requires compatible terrain/water/character materials and a changed material factory; switching render pipelines alone is not sufficient.

## Verification and Play Mode checklist

The delivery was statically reviewed and C# syntax-parsed. **Unity is not installed in the generation environment; Unity compilation, Play Mode, visuals, package resolution and player builds have not been executed here.** Use this acceptance checklist in Unity 2022.3:

- Import completes with no Console errors, create demo scene, Play: one controller, one active camera/listener, visible terrain and HUD `0 / 5`.
- Walk in every direction, sprint, jump twice; a third air press does not jump. Land and jump again. Check slopes and ceiling collision.
- Follow/rotate the camera near a ruin; it follows with delay and does not pass through the wall.
- Walk into water and press Home: each returns to the overlook without clearing collected artifacts.
- Visit an out-of-order artifact: no choices/collection. Return to the current clue's artifact and press E. Cancel leaves the count unchanged.
- Open choices mid-jump: gravity continues, movement/orbit input is disabled, pointer buttons work. Confirm one choice: count increases exactly once and the next lyric appears.
- Repeat the five artifacts in order; collected relics change color and cannot be collected again. Retuning changes global fog/light tint.
- The sanctuary reveal is inactive before artifact five and visible afterward. Reaching it early does not win. After five, walk into it and confirm the completion message.
- Assign a clue clip, restart Play, press R and confirm playback. Leave clips empty and verify text-only play remains possible.
- Stop and replay: world regeneration is clean, no duplicate EventSystem, progress resets. Test a saved scene in a standalone build too.

Fixed UI dimensions suit ordinary desktop resolutions; very short ultrawide windows can clip the choice panel. Add safe-area handling and scrollable layouts when targeting more display shapes. No persistence, network service or external credentials are required.
