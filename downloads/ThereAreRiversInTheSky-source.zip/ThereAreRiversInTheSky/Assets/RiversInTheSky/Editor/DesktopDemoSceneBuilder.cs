using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace RiversInTheSky.Editor
{
    /// <summary>
    /// Builds a complete, wired desktop test scene from the same runtime systems used by
    /// authored levels. Repeated runs create new scenes and preserve existing material assets.
    /// Art and audio can then be replaced without changing quest data or save identities.
    /// </summary>
    public static class DesktopDemoSceneBuilder
    {
        private const string Root = "Assets/RiversInTheSky";
        private const string MaterialFolder = Root + "/Data/DesktopDemo";
        private static Font Font => Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");

        [MenuItem("Tools/Rivers in the Sky/Create Desktop Demo Scene")]
        public static void Create()
        {
            // Respect an unsaved authored scene; cancellation leaves it untouched.
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            if (Shader.Find("RiversInTheSky/PainterlyBioluminescence") == null)
                throw new InvalidOperationException("Import the RiversInTheSky shader before generating its demo scene.");
            EnsureFolder(Root + "/Scenes");
            EnsureFolder(MaterialFolder);
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            Material stone = Material("Demo Painted Stone", new Color(.2f, .29f, .29f), 0f);
            Material living = Material("Demo Living Water", new Color(.03f, .2f, .21f), 1.5f);
            Material restoration = Material("Demo Restoration", new Color(.08f, .5f, .38f), .5f);
            Material impact = Material("Demo Impact", new Color(.65f, .24f, .12f), .15f);
            var diagnostics = new List<CyanobacteriaController>();

            var services = new GameObject("Services");
            var quests = services.AddComponent<QuestManager>();
            // A demo run starts fresh and cannot replace an existing game's save files.
            Edit(quests, so => { so.FindProperty("loadOnAwake").boolValue = false; so.FindProperty("autoSave").boolValue = false; });
            var journal = services.AddComponent<JournalManager>();
            Edit(journal, so => so.FindProperty("persistenceEnabled").boolValue = false);
            var audio = services.AddComponent<AudioLandscapeManager>();
            audio.Configure(quests);

            var player = new GameObject("Desktop Player");
            player.layer = 2; // Built-in Ignore Raycast: the player's collider must not hide a subject.
            player.transform.position = new Vector3(0f, .05f, -4f);
            var body = player.AddComponent<CharacterController>();
            body.height = 1.8f; body.radius = .3f; body.center = new Vector3(0, .9f, 0);
            body.stepOffset = .25f; body.slopeLimit = 45f;
            var cameraObject = Child("Main Camera", player.transform);
            cameraObject.tag = "MainCamera"; cameraObject.layer = 2;
            cameraObject.transform.localPosition = new Vector3(0, 1.65f, 0);
            var camera = cameraObject.AddComponent<Camera>();
            camera.nearClipPlane = .05f; camera.farClipPlane = 150f; camera.fieldOfView = 65f;
            camera.backgroundColor = new Color(.12f, .18f, .25f);
            camera.GetUniversalAdditionalCameraData().renderPostProcessing = true;
            cameraObject.AddComponent<AudioListener>();

            var panelOwner = new GameObject("Choice Panel Controller");
            var panel = panelOwner.AddComponent<ArtifactChoicePanel>();
            CreateChoicePanel(panel, camera);
            var photoCamera = cameraObject.AddComponent<EnvironmentCamera>();
            Edit(photoCamera, so =>
            {
                Ref(so, "viewfinder", camera.transform); Ref(so, "journal", journal);
                so.FindProperty("visibilityMask").intValue = Physics.DefaultRaycastLayers;
            });
            player.AddComponent<DesktopPlayerController>().Configure(camera, panel);
            var interaction = player.AddComponent<DesktopInteractor>();
            interaction.Configure(camera, panel, photoCamera);

            var eventSystem = new GameObject("EventSystem", typeof(EventSystem), typeof(InputSystemUIInputModule));
            // The module creates and owns its standard pointer/UI actions when no asset is assigned.
            eventSystem.GetComponent<InputSystemUIInputModule>().AssignDefaultActions();

            Primitive("Floor", PrimitiveType.Cube, null, new Vector3(0, -.15f, 3f), new Vector3(18, .3f, 18), stone);
            var sunObject = new GameObject("Twilight Sun");
            var sun = sunObject.AddComponent<Light>();
            sun.type = LightType.Directional; sun.intensity = 1.2f; sun.color = new Color(1f, .85f, .67f);
            sun.shadows = LightShadows.Soft; sun.transform.rotation = Quaternion.Euler(48, -28, 0);
            RenderSettings.ambientMode = AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(.32f, .4f, .5f);
            var gradeObject = new GameObject("Painterly Global Volume");
            gradeObject.AddComponent<Volume>().isGlobal = true;
            gradeObject.AddComponent<PainterlyGradeController>().Configure(quests);

            CreateHud(quests, camera, living);
            Vector3[] positions =
            {
                new Vector3(-3, 0, 0), new Vector3(0, 0, 1), new Vector3(3, 0, 0),
                new Vector3(-3, 0, 4), new Vector3(3, 0, 4)
            };
            for (int i = 0; i < positions.Length; i++)
            {
                ArtifactId id = (ArtifactId)i;
                ArtifactDefinition definition = ArtifactDefinition.CreateDefault(id);
                try
                {
                    var artifact = new GameObject(definition.DisplayName);
                    artifact.transform.position = positions[i];
                    var visual = Primitive("Artifact Form", i == 1 ? PrimitiveType.Sphere : PrimitiveType.Cube,
                        artifact.transform, new Vector3(0, .65f, 0), new Vector3(1, 1.1f, 1), i == 1 ? living : stone);
                    var node = artifact.AddComponent<ArtifactNode>(); node.Configure(quests, id);
                    artifact.AddComponent<ArtifactInteractor>().Configure(node, panel, camera.transform);
                    var memory = artifact.AddComponent<Photographable>();
                    memory.Configure("artifact-" + id.ToString().ToLowerInvariant(), definition.DisplayName, true, id);
                    Edit(memory, so => Ref(so, "framingPoint", visual.transform));
                    Label(definition.DisplayName, artifact.transform, new Vector3(0, 1.5f, -.1f));
                    CreateBranchMarkers(artifact, node, definition, restoration, impact);
                    var biology = visual.AddComponent<CyanobacteriaController>();
                    biology.Configure(quests, camera.transform, new[] { visual.GetComponent<Renderer>() });
                    diagnostics.Add(biology);
                    if (i < 4)
                    {
                        var metric = visual.AddComponent<EcologyThermalDriver>();
                        EcologyThermalDriver.Metric[] metrics =
                        { EcologyThermalDriver.Metric.Habitat, EcologyThermalDriver.Metric.Pollution,
                          EcologyThermalDriver.Metric.Toxicity, EcologyThermalDriver.Metric.FloodRisk };
                        Edit(metric, so =>
                        {
                            Ref(so, "quests", quests); Ref(so, "surface", biology);
                            so.FindProperty("metric").enumValueIndex = (int)metrics[i];
                            so.FindProperty("invert").boolValue = i == 0;
                        });
                    }
                }
                finally { Object.DestroyImmediate(definition); }
            }

            CreatePool(quests, camera, stone, living, restoration, diagnostics);
            Edit(interaction, so =>
            {
                var array = so.FindProperty("diagnosticSurfaces"); array.arraySize = diagnostics.Count;
                for (int i = 0; i < diagnostics.Count; i++) array.GetArrayElementAtIndex(i).objectReferenceValue = diagnostics[i];
            });

            string scenePath = AssetDatabase.GenerateUniqueAssetPath(Root + "/Scenes/DesktopDemo.unity");
            EditorSceneManager.MarkSceneDirty(scene);
            if (!EditorSceneManager.SaveScene(scene, scenePath)) throw new InvalidOperationException("Could not save the desktop demo scene.");
            AssetDatabase.SaveAssets();
            Selection.activeGameObject = player;
            if (SceneView.lastActiveSceneView != null) SceneView.lastActiveSceneView.AlignViewToObject(camera.transform);
            Debug.Log("Desktop demo ready at " + scenePath + ". Press Play: WASD move, mouse look, E/click interact, F photograph, T diagnostics, Esc close/release cursor.");
        }

        private static void CreateChoicePanel(ArtifactChoicePanel panel, Camera camera)
        {
            var canvasObject = new GameObject("Choice Canvas", typeof(RectTransform), typeof(Canvas), typeof(GraphicRaycaster));
            var canvas = canvasObject.GetComponent<Canvas>(); canvas.renderMode = RenderMode.WorldSpace; canvas.worldCamera = camera;
            var rect = canvasObject.GetComponent<RectTransform>(); rect.sizeDelta = new Vector2(1000, 650); rect.localScale = Vector3.one * .001f;
            var background = canvasObject.AddComponent<Image>(); background.color = new Color(.035f, .075f, .09f, .98f);
            Text title = Text("Artifact Title", rect, new Vector2(25, -20), new Vector2(950, 65), 38, TextAnchor.UpperLeft);
            Text description = Text("Description", rect, new Vector2(25, -100), new Vector2(950, 110), 27, TextAnchor.UpperLeft);
            Text status = Text("Status", rect, new Vector2(25, -210), new Vector2(950, 75), 25, TextAnchor.UpperLeft);
            var container = new GameObject("Choices", typeof(RectTransform), typeof(VerticalLayoutGroup));
            container.transform.SetParent(rect, false);
            Place(container.GetComponent<RectTransform>(), new Vector2(25, -300), new Vector2(950, 225));
            var layout = container.GetComponent<VerticalLayoutGroup>();
            layout.spacing = 18; layout.childControlWidth = true; layout.childControlHeight = true;
            layout.childForceExpandWidth = true; layout.childForceExpandHeight = false;
            Button template = Button("Choice Button Template", panel.transform, "Choice");
            template.gameObject.SetActive(false);
            Button close = Button("Close", rect, "Close");
            Place(close.GetComponent<RectTransform>(), new Vector2(800, -565), new Vector2(175, 60));
            UnityEventTools.AddPersistentListener(close.onClick, panel.Close);
            Edit(panel, so =>
            {
                Ref(so, "panelRoot", canvasObject); Ref(so, "title", title); Ref(so, "description", description);
                Ref(so, "status", status); Ref(so, "buttonContainer", container.transform); Ref(so, "buttonPrefab", template);
            });
        }

        private static void CreateHud(QuestManager quests, Camera camera, Material living)
        {
            var hud = new GameObject("Desktop HUD", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler));
            hud.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = hud.GetComponent<CanvasScaler>(); scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1280, 720); scaler.matchWidthOrHeight = .5f;
            Text instructions = Text("Controls", hud.transform, new Vector2(24, -20), new Vector2(900, 95), 21, TextAnchor.UpperLeft);
            instructions.text = "WASD move  |  Mouse look  |  E / click interact\nF photograph  |  T environmental view  |  Esc close / release cursor";
            Text crosshair = Text("Aim", hud.transform, Vector2.zero, new Vector2(40, 40), 30, TextAnchor.MiddleCenter);
            var crossRect = crosshair.rectTransform; crossRect.anchorMin = crossRect.anchorMax = crossRect.pivot = new Vector2(.5f, .5f);
            crossRect.anchoredPosition = Vector2.zero; crosshair.text = "+";
            Text subtitle = Text("ISO Subtitle", hud.transform, Vector2.zero, new Vector2(1100, 115), 26, TextAnchor.MiddleCenter);
            subtitle.rectTransform.anchorMin = subtitle.rectTransform.anchorMax = subtitle.rectTransform.pivot = new Vector2(.5f, 0);
            subtitle.rectTransform.anchoredPosition = new Vector2(0, 35);
            var group = subtitle.gameObject.AddComponent<CanvasGroup>();
            var isoVisual = Primitive("ISO", PrimitiveType.Sphere, null, new Vector3(.8f, 1.5f, -2.7f), Vector3.one * .24f, living);
            isoVisual.layer = 2; Object.DestroyImmediate(isoVisual.GetComponent<Collider>());
            var iso = isoVisual.AddComponent<IsoCompanion>(); iso.Configure(quests, camera.transform);
            var presenter = hud.AddComponent<IsoSubtitlePresenter>();
            Edit(presenter, so => { Ref(so, "iso", iso); Ref(so, "subtitle", subtitle); Ref(so, "visibility", group); });
        }

        private static void CreateBranchMarkers(GameObject owner, ArtifactNode node, ArtifactDefinition data, Material restored, Material impact)
        {
            if (data.Choices.Count == 0) return;
            var consequences = owner.AddComponent<ArtifactConsequenceView>();
            var markers = new GameObject[data.Choices.Count];
            for (int i = 0; i < markers.Length; i++)
            {
                var choice = data.Choices[i];
                markers[i] = Primitive("Consequence - " + choice.Id, PrimitiveType.Cube, owner.transform,
                    new Vector3(0, .16f, -.7f), new Vector3(.85f, .25f, .25f), choice.IsRestorative ? restored : impact);
                Object.DestroyImmediate(markers[i].GetComponent<Collider>());
                markers[i].SetActive(false);
            }
            Edit(consequences, so =>
            {
                Ref(so, "artifact", node);
                var branches = so.FindProperty("branches"); branches.arraySize = markers.Length;
                for (int i = 0; i < markers.Length; i++)
                {
                    var branch = branches.GetArrayElementAtIndex(i);
                    branch.FindPropertyRelative("choiceId").stringValue = data.Choices[i].Id;
                    var objects = branch.FindPropertyRelative("objects"); objects.arraySize = 1;
                    objects.GetArrayElementAtIndex(0).objectReferenceValue = markers[i];
                }
            });
        }

        private static void CreatePool(QuestManager quests, Camera camera, Material stone, Material living,
            Material restored, List<CyanobacteriaController> diagnostics)
        {
            var pool = new GameObject("Central Pool"); pool.transform.position = new Vector3(0, 0, 6);
            Primitive("Pool Base", PrimitiveType.Cylinder, pool.transform, new Vector3(0, .1f, 0), new Vector3(3, .1f, 3), stone);
            var water = Primitive("Water Surface", PrimitiveType.Cylinder, pool.transform, new Vector3(0, .25f, 0), new Vector3(2.7f, .025f, 2.7f), living);
            Object.DestroyImmediate(water.GetComponent<Collider>());
            var biology = water.AddComponent<CyanobacteriaController>();
            biology.Configure(quests, camera.transform, new[] { water.GetComponent<Renderer>() }); diagnostics.Add(biology);
            var memory = new GameObject("Final Memory"); memory.transform.SetParent(pool.transform, false);
            Primitive("Memory Light", PrimitiveType.Sphere, memory.transform, new Vector3(0, 1.4f, 0), Vector3.one * .65f, restored);
            Label("Four streams, one living home.", memory.transform, new Vector3(0, 2.1f, -.2f));
            memory.SetActive(false);
            var poolView = pool.AddComponent<CentralPoolView>();
            Edit(poolView, so =>
            {
                Ref(so, "quests", quests); Ref(so, "waterSurface", water.transform); Ref(so, "finalMemoryRoot", memory);
                so.FindProperty("emptyLocalY").floatValue = .25f; so.FindProperty("fullLocalY").floatValue = .8f;
            });
            WaterChannel[] channels = { WaterChannel.Water, WaterChannel.Lotus, WaterChannel.Lantern, WaterChannel.Rice };
            for (int i = 0; i < channels.Length; i++)
            {
                var valveRoot = new GameObject(channels[i] + " Channel Valve");
                valveRoot.transform.position = new Vector3(-2.25f + i * 1.5f, 0, 4.2f);
                Primitive("Valve", PrimitiveType.Cylinder, valveRoot.transform, new Vector3(0, .5f, 0), new Vector3(.4f, .5f, .4f), stone);
                Label(channels[i].ToString(), valveRoot.transform, new Vector3(0, 1.15f, -.05f));
                var valve = valveRoot.AddComponent<WaterChannelValve>(); valve.Configure(quests, channels[i]);
                var indicator = Primitive("Connected Indicator", PrimitiveType.Sphere, valveRoot.transform,
                    new Vector3(0, 1.35f, 0), Vector3.one * .17f, restored);
                Object.DestroyImmediate(indicator.GetComponent<Collider>()); indicator.SetActive(false);
                UnityEventTools.AddPersistentListener(Event<bool>(valve, "onConnectedState"), indicator.SetActive);
            }
        }

        private static GameObject Primitive(string name, PrimitiveType type, Transform parent, Vector3 position, Vector3 scale, Material material)
        {
            var result = GameObject.CreatePrimitive(type); result.name = name;
            if (parent != null) result.transform.SetParent(parent, false);
            result.transform.localPosition = position; result.transform.localScale = scale;
            result.GetComponent<Renderer>().sharedMaterial = material;
            return result;
        }
        private static GameObject Child(string name, Transform parent)
        { var result = new GameObject(name); result.transform.SetParent(parent, false); return result; }

        private static Material Material(string name, Color color, float emission)
        {
            string path = MaterialFolder + "/" + name + ".mat";
            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (material != null) return material;
            material = new Material(Shader.Find("RiversInTheSky/PainterlyBioluminescence")) { name = name };
            material.SetColor("_BaseColor", color); material.SetFloat("_EmissionStrength", emission);
            AssetDatabase.CreateAsset(material, path); return material;
        }
        private static void Label(string value, Transform parent, Vector3 localPosition)
        {
            var label = Child("Label", parent); label.transform.localPosition = localPosition;
            var text = label.AddComponent<TextMesh>(); text.text = value; text.font = Font; text.fontSize = 64;
            text.characterSize = .045f; text.anchor = TextAnchor.MiddleCenter; text.alignment = TextAlignment.Center;
            text.color = new Color(.85f, 1f, .94f); label.GetComponent<Renderer>().sharedMaterial = Font.material;
        }
        private static Text Text(string name, Transform parent, Vector2 position, Vector2 size, int fontSize, TextAnchor alignment)
        {
            var result = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));
            result.transform.SetParent(parent, false);
            var text = result.GetComponent<Text>(); text.font = Font; text.fontSize = fontSize;
            text.color = new Color(.9f, .97f, .95f); text.alignment = alignment; text.raycastTarget = false;
            text.horizontalOverflow = HorizontalWrapMode.Wrap; text.verticalOverflow = VerticalWrapMode.Truncate;
            Place(text.rectTransform, position, size); return text;
        }
        private static Button Button(string name, Transform parent, string caption)
        {
            var result = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button), typeof(LayoutElement));
            result.transform.SetParent(parent, false); result.GetComponent<Image>().color = new Color(.1f, .25f, .26f);
            result.GetComponent<LayoutElement>().preferredHeight = 95f;
            var button = result.GetComponent<Button>(); button.targetGraphic = result.GetComponent<Image>();
            var label = Text("Text", result.transform, Vector2.zero, Vector2.zero, 27, TextAnchor.MiddleCenter); label.text = caption;
            label.rectTransform.anchorMin = Vector2.zero; label.rectTransform.anchorMax = Vector2.one;
            label.rectTransform.offsetMin = new Vector2(14, 8); label.rectTransform.offsetMax = new Vector2(-14, -8);
            return button;
        }
        private static void Place(RectTransform rect, Vector2 position, Vector2 size)
        {
            rect.anchorMin = rect.anchorMax = rect.pivot = new Vector2(0, 1);
            rect.anchoredPosition = position; rect.sizeDelta = size;
        }
        private static void Edit(Object target, Action<SerializedObject> update)
        { var so = new SerializedObject(target); update(so); so.ApplyModifiedPropertiesWithoutUndo(); }
        private static void Ref(SerializedObject so, string field, Object value)
        {
            SerializedProperty property = so.FindProperty(field);
            if (property == null) throw new MissingFieldException(so.targetObject.GetType().Name, field);
            property.objectReferenceValue = value;
        }
        private static UnityEvent<T> Event<T>(Object owner, string field)
        {
            var member = owner.GetType().GetField(field, BindingFlags.Instance | BindingFlags.NonPublic);
            return (UnityEvent<T>)(member?.GetValue(owner) ?? throw new MissingFieldException(owner.GetType().Name, field));
        }
        private static void EnsureFolder(string path)
        {
            string[] parts = path.Split('/'); string parent = parts[0];
            for (int i = 1; i < parts.Length; i++)
            { if (!AssetDatabase.IsValidFolder(parent + "/" + parts[i])) AssetDatabase.CreateFolder(parent, parts[i]); parent += "/" + parts[i]; }
        }
    }
}
