using System;
using UnityEditor;
using UnityEngine;

namespace RiversInTheSky.Editor
{
    /// <summary>
    /// Creates editable assets from the same complete catalog used by the runtime fallback.
    /// Existing assets are preserved, so rerunning the menu cannot erase authored narrative.
    /// </summary>
    public static class RiversAuthoringTools
    {
        private const string DataFolder = "Assets/RiversInTheSky/Data";

        [MenuItem("Tools/Rivers in the Sky/Create Default Artifact Assets")]
        public static void CreateDefaultArtifactAssets()
        {
            EnsureFolder("Assets", "RiversInTheSky");
            EnsureFolder("Assets/RiversInTheSky", "Data");
            foreach (ArtifactId id in Enum.GetValues(typeof(ArtifactId)))
            {
                string path = $"{DataFolder}/{id}.asset";
                if (AssetDatabase.LoadMainAssetAtPath(path) != null) continue;
                ArtifactDefinition definition = ArtifactDefinition.CreateDefault(id);
                AssetDatabase.CreateAsset(definition, path);
            }
            AssetDatabase.SaveAssets();
            Selection.activeObject = AssetDatabase.LoadAssetAtPath<DefaultAsset>(DataFolder);
            EditorGUIUtility.PingObject(Selection.activeObject);
            Debug.Log("Five artifact assets are ready. Assign them to QuestManager, or leave its array empty to use runtime defaults.");
        }

        [MenuItem("Tools/Rivers in the Sky/Validate Artifact Assets")]
        public static void ValidateArtifactAssets()
        {
            int valid = 0;
            foreach (string guid in AssetDatabase.FindAssets("t:ArtifactDefinition"))
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                ArtifactDefinition definition = AssetDatabase.LoadAssetAtPath<ArtifactDefinition>(path);
                if (!definition.Validate(out string error)) Debug.LogError($"{path}: {error}", definition);
                else valid++;
            }
            Debug.Log($"Validated {valid} artifact definitions. Duplicate IDs are permitted across catalogs; each QuestManager accepts one definition per ID.");
        }

        private static void EnsureFolder(string parent, string name)
        {
            if (!AssetDatabase.IsValidFolder(parent + "/" + name)) AssetDatabase.CreateFolder(parent, name);
        }
    }
}
