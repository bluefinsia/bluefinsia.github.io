using System;
using System.Collections.Generic;
using System.IO;
using NUnit.Framework;
using UnityEngine;

namespace RiversInTheSky.Tests
{
    public sealed class QuestStateTests
    {
        private Dictionary<ArtifactId, ArtifactDefinition> catalog;

        [SetUp]
        public void SetUp()
        {
            catalog = new Dictionary<ArtifactId, ArtifactDefinition>();
            foreach (ArtifactId id in Enum.GetValues(typeof(ArtifactId))) catalog.Add(id, ArtifactDefinition.CreateDefault(id));
        }

        [TearDown]
        public void TearDown()
        { foreach (ArtifactDefinition definition in catalog.Values) UnityEngine.Object.DestroyImmediate(definition); }

        [Test]
        public void RepeatedChoiceCannotApplyConsequencesTwice()
        {
            var state = new QuestState(catalog);
            Assert.That(state.TryChoose(ArtifactId.Pagoda, "force_entrance", out _, out _), Is.True);
            Assert.That(state.TryChoose(ArtifactId.Pagoda, "restore_passage", out _, out _), Is.False);
            Assert.That(state.Snapshot.ResolvedCount, Is.EqualTo(1));
            Assert.That(state.Snapshot.Habitat, Is.EqualTo(-2));
            Assert.That(state.GetChoiceId(ArtifactId.Pagoda), Is.EqualTo("force_entrance"));
        }

        [Test]
        public void UnknownChoiceAndCompoundChannelAreRejected()
        {
            var state = new QuestState(catalog);
            Assert.That(state.TryChoose(ArtifactId.Lotus, "unknown", out _, out _), Is.False);
            Assert.That(state.TryConnectChannel(WaterChannel.All, out _), Is.False);
            Assert.That(state.TryConnectChannel(WaterChannel.Lotus, out _), Is.False);
            Assert.That(state.Snapshot.ResolvedCount, Is.Zero);
        }

        [TestCase(0)] [TestCase(1)] [TestCase(2)] [TestCase(3)]
        [TestCase(4)] [TestCase(5)] [TestCase(6)] [TestCase(7)]
        [TestCase(8)] [TestCase(9)] [TestCase(10)] [TestCase(11)]
        [TestCase(12)] [TestCase(13)] [TestCase(14)] [TestCase(15)]
        public void EveryBranchCombinationCanReachFinalMemory(int combination)
        {
            var state = ResolveAll(combination);
            Assert.That(state.Snapshot.FinalMemoryUnlocked, Is.False);
            foreach (WaterChannel channel in new[] { WaterChannel.Lotus, WaterChannel.Lantern, WaterChannel.Rice, WaterChannel.Water })
                Assert.That(state.TryConnectChannel(channel, out _), Is.True);
            Assert.That(state.AdvancePool(4f, 8f, out bool unlocked), Is.True);
            Assert.That(unlocked, Is.False);
            Assert.That(state.Snapshot.PoolFill01, Is.EqualTo(.5f));
            state.AdvancePool(4f, 8f, out unlocked);
            Assert.That(unlocked, Is.True);
            Assert.That(state.Snapshot.ResolvedCount, Is.EqualTo(5));
            Assert.That(state.Snapshot.FinalMemoryUnlocked, Is.True);
            Assert.That(state.AdvancePool(4f, 8f, out unlocked), Is.False);
            Assert.That(unlocked, Is.False);
        }

        [Test]
        public void IncompleteChannelsCannotFillPool()
        {
            var state = ResolveAll(15);
            state.TryConnectChannel(WaterChannel.Lotus, out _);
            Assert.That(state.AdvancePool(100f, 8f, out _), Is.False);
            Assert.That(state.Snapshot.PoolFill01, Is.Zero);
        }

        [Test]
        public void SaveRoundTripPreservesConsequencesAndPartialPool()
        {
            var state = ResolveAll(5);
            foreach (WaterChannel channel in new[] { WaterChannel.Lotus, WaterChannel.Lantern, WaterChannel.Rice, WaterChannel.Water })
                state.TryConnectChannel(channel, out _);
            state.AdvancePool(2f, 8f, out _);
            QuestSaveData copy = JsonUtility.FromJson<QuestSaveData>(JsonUtility.ToJson(state.Export()));
            var restored = new QuestState(catalog);
            restored.Restore(copy);
            Assert.That(restored.Snapshot.ResolvedCount, Is.EqualTo(state.Snapshot.ResolvedCount));
            Assert.That(restored.Snapshot.CleansedCount, Is.EqualTo(state.Snapshot.CleansedCount));
            Assert.That(restored.Snapshot.Toxicity, Is.EqualTo(state.Snapshot.Toxicity));
            Assert.That(restored.Snapshot.PoolFill01, Is.EqualTo(.25f));
        }

        [Test]
        public void RestoreCanonicalizesDuplicatesUnknownIdsAndImpossibleProgress()
        {
            var data = new QuestSaveData { connectedChannels = 255, poolFill = 1f };
            data.choices.Add(new ArtifactChoiceRecord(ArtifactId.Pagoda, "force_entrance"));
            data.choices.Add(new ArtifactChoiceRecord(ArtifactId.Pagoda, "restore_passage"));
            data.choices.Add(new ArtifactChoiceRecord((ArtifactId)99, "force_entrance"));
            data.choices.Add(new ArtifactChoiceRecord(ArtifactId.Lotus, "removed_choice"));
            data.choices.Add(new ArtifactChoiceRecord(ArtifactId.FourYoungMaidens, "anything"));
            var state = new QuestState(catalog);
            state.Restore(data);
            Assert.That(state.Snapshot.ResolvedCount, Is.EqualTo(1));
            Assert.That(state.Snapshot.ConnectedChannels, Is.EqualTo(WaterChannel.Water));
            Assert.That(state.Snapshot.PoolFill01, Is.Zero);
            Assert.That(state.Snapshot.Habitat, Is.EqualTo(-2));
        }

        [Test]
        public void FutureVersionIsRejectedBeforeExistingStateIsChanged()
        {
            var state = ResolveAll(15);
            Assert.Throws<InvalidDataException>(() => state.Restore(new QuestSaveData { version = 2 }));
            Assert.That(state.Snapshot.ResolvedCount, Is.EqualTo(4));
        }

        [Test]
        public void WetlandRiceRoutePreservesItsNutrientTradeoff()
        {
            var state = new QuestState(catalog);
            state.TryChoose(ArtifactId.RiceField, "wetland_route", out _, out _);
            Assert.That(state.Snapshot.Nutrients, Is.EqualTo(-1));
            Assert.That(state.Snapshot.FloodRisk, Is.EqualTo(-1));
            Assert.That(state.Snapshot.CleansedCount, Is.EqualTo(1));
        }

        [Test]
        public void ArcAdvancesWithExperienceEvenAfterNonrestorativeChoices()
        {
            var state = new QuestState(catalog);
            Assert.That(state.Snapshot.Act, Is.EqualTo(IsoAct.AnalyticalCurious));
            state.TryChoose(ArtifactId.Pagoda, "force_entrance", out _, out _);
            state.TryChoose(ArtifactId.Lotus, "remove_rubbish", out ChoiceOutcome outcome, out _);
            Assert.That(outcome.Act, Is.EqualTo(IsoAct.QuestionAndLearn));
            state.TryChoose(ArtifactId.Lamplight, "old_cell", out _, out _);
            state.TryChoose(ArtifactId.RiceField, "direct_gate", out outcome, out _);
            Assert.That(outcome.Act, Is.EqualTo(IsoAct.UnderstandingEmpathetic));
        }

        private QuestState ResolveAll(int combination)
        {
            var state = new QuestState(catalog);
            for (int i = 0; i < 4; i++)
            {
                ArtifactId id = (ArtifactId)i;
                string choice = catalog[id].Choices[(combination >> i) & 1].Id;
                Assert.That(state.TryChoose(id, choice, out _, out _), Is.True);
            }
            return state;
        }
    }
}
