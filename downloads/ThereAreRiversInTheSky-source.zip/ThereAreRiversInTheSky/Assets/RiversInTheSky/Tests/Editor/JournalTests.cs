using System.IO;
using System.Reflection;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using UnityEngine.TestTools;

namespace RiversInTheSky.Tests
{
    public sealed class JournalTests
    {
        private GameObject host;
        private JournalManager journal;
        private string isolatedSavePath;

        [SetUp]
        public void SetUp()
        {
            host = new GameObject("Journal Test");
            host.SetActive(false); // Prevent Awake from loading the player's real journal.
            journal = host.AddComponent<JournalManager>();
            var serialized = new SerializedObject(journal);
            serialized.FindProperty("persistenceEnabled").boolValue = false;
            serialized.ApplyModifiedPropertiesWithoutUndo();
        }
        [TearDown]
        public void TearDown()
        {
            Object.DestroyImmediate(host);
            if (string.IsNullOrEmpty(isolatedSavePath)) return;
            foreach (var suffix in new[] { string.Empty, ".bak", ".tmp" })
                if (File.Exists(isolatedSavePath + suffix)) File.Delete(isolatedSavePath + suffix);
            isolatedSavePath = null;
        }

        [Test]
        public void DuplicateMemoryDoesNotDispatchOrAppend()
        {
            int notifications = 0;
            journal.PhotoRecorded += _ => notifications++;
            Assert.That(journal.TryRecordPhoto(new PhotoMemory { memoryId = "lotus" }), Is.True);
            Assert.That(journal.TryRecordPhoto(new PhotoMemory { memoryId = "lotus" }), Is.False);
            Assert.That(journal.Photos.Count, Is.EqualTo(1));
            Assert.That(notifications, Is.EqualTo(1));
        }
        [Test]
        public void CallerAndEventAndGetterCannotMutateStoredIdentity()
        {
            var input = new PhotoMemory { memoryId = "pagoda", displayName = "Pagoda" };
            journal.PhotoRecorded += copy => copy.memoryId = "changed-by-event";
            Assert.That(journal.TryRecordPhoto(input), Is.True);
            input.memoryId = "changed-by-caller";
            journal.Photos[0].memoryId = "changed-by-getter";
            Assert.That(journal.ContainsPhoto("pagoda"), Is.True);
            Assert.That(journal.Photos[0].memoryId, Is.EqualTo("pagoda"));
            Assert.That(journal.ContainsPhoto("changed-by-getter"), Is.False);
        }
        [Test]
        public void FuturePrimaryPreventsFallbackAndAnySaveOverwrite()
        {
            var fileName = "rivers-journal-test-" + System.Guid.NewGuid().ToString("N") + ".json";
            isolatedSavePath = Path.Combine(Application.persistentDataPath, fileName);
            Directory.CreateDirectory(Application.persistentDataPath);
            const string futurePrimary = "{\"version\":2,\"photos\":[]}";
            const string oldBackup = "{\"version\":1,\"photos\":[{\"memoryId\":\"backup-memory\"}]}";
            File.WriteAllText(isolatedSavePath, futurePrimary);
            File.WriteAllText(isolatedSavePath + ".bak", oldBackup);
            var serialized = new SerializedObject(journal);
            serialized.FindProperty("saveFileName").stringValue = fileName;
            serialized.FindProperty("persistenceEnabled").boolValue = true;
            serialized.ApplyModifiedPropertiesWithoutUndo();
            LogAssert.Expect(LogType.Error,
                "This journal belongs to a newer game version; writes are disabled to preserve it.");
            typeof(JournalManager).GetMethod("Load", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(journal, null);
            Assert.That(journal.Photos.Count, Is.Zero, "The older backup must not replace a future primary.");
            Assert.That(journal.TryRecordPhoto(new PhotoMemory { memoryId = "session-memory" }), Is.True);
            journal.Save();
            Assert.That(journal.ContainsPhoto("session-memory"), Is.True);
            Assert.That(File.ReadAllText(isolatedSavePath), Is.EqualTo(futurePrimary));
            Assert.That(File.ReadAllText(isolatedSavePath + ".bak"), Is.EqualTo(oldBackup));
        }
        [Test]
        public void EmptyMemoryIdIsRejected()
        {
            Assert.That(journal.TryRecordPhoto(new PhotoMemory { memoryId = "  " }), Is.False);
            Assert.That(journal.Photos.Count, Is.Zero);
        }
    }
}
