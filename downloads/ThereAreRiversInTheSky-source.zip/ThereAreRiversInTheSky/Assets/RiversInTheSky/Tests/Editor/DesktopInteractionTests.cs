using System.Collections.Generic;
using System.Reflection;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using UnityEngine.Events;

namespace RiversInTheSky.Tests
{
    /// <summary>
    /// Exercises the actual desktop aim query without creating keyboard/mouse devices.
    /// A valve's existing rejection feedback observes delivery; no quest save is loaded
    /// or modified, and no cursor ownership or rendered frame is required.
    /// </summary>
    public sealed class DesktopInteractionTests
    {
        private const int TestLayer = 30;
        private readonly List<GameObject> roots = new List<GameObject>();
        private DesktopInteractor interactor;
        private Camera camera;
        private GameObject player;
        private int delivered;

        [SetUp]
        public void SetUp()
        {
            player = CreateRoot("Desktop query test player");
            player.SetActive(false);
            player.transform.position = Vector3.up * 1000f;
            var lens = new GameObject("Disabled test camera");
            lens.transform.SetParent(player.transform, false);
            camera = lens.AddComponent<Camera>();
            camera.enabled = false;
            camera.nearClipPlane = 0.3f;
            interactor = player.AddComponent<DesktopInteractor>();
            interactor.Configure(camera, null, null);
            var serialized = new SerializedObject(interactor);
            serialized.FindProperty("interactionMask").intValue = 1 << TestLayer;
            serialized.FindProperty("interactionDistance").floatValue = 4f;
            serialized.ApplyModifiedPropertiesWithoutUndo();
            player.SetActive(true);
            delivered = 0;
        }

        [TearDown]
        public void TearDown()
        {
            foreach (var root in roots) if (root != null) Object.DestroyImmediate(root);
            roots.Clear();
            Physics.SyncTransforms();
        }

        [Test]
        public void UnobstructedValveReceivesExactlyOneInteraction()
        {
            CreateValve(2f);
            Physics.SyncTransforms();
            Assert.That(interactor.TryInteract(), Is.True);
            Assert.That(delivered, Is.EqualTo(1));
        }

        [TestCase(1f, 0.1f)]
        [TestCase(0.12f, 0.04f)]
        public void SolidWallBlocksValveIncludingBeforeCameraNearPlane(float distance, float thickness)
        {
            CreateValve(2f);
            CreateBox("Solid occluder", distance, new Vector3(1f, 1f, thickness));
            Physics.SyncTransforms();
            Assert.That(interactor.TryInteract(), Is.False);
            Assert.That(delivered, Is.Zero);
        }

        [Test]
        public void BeyondRangeValveReceivesNoInteraction()
        {
            CreateValve(8f);
            Physics.SyncTransforms();
            Assert.That(interactor.TryInteract(), Is.False);
            Assert.That(delivered, Is.Zero);
        }

        [Test]
        public void OwnChildColliderDoesNotHideAnUnobstructedValve()
        {
            CreateValve(2f);
            var ownBody = new GameObject("Player-owned collider");
            ownBody.layer = TestLayer;
            ownBody.transform.SetParent(player.transform, false);
            ownBody.transform.localPosition = Vector3.forward * 0.5f;
            ownBody.AddComponent<BoxCollider>().size = Vector3.one * 0.2f;
            Physics.SyncTransforms();
            Assert.That(interactor.TryInteract(), Is.True);
            Assert.That(delivered, Is.EqualTo(1));
        }

        [Test]
        public void TriggerVolumeDoesNotHideAnUnobstructedValve()
        {
            CreateValve(2f);
            CreateBox("Trigger volume", 1f, Vector3.one * 0.25f).isTrigger = true;
            Physics.SyncTransforms();
            Assert.That(interactor.TryInteract(), Is.True);
            Assert.That(delivered, Is.EqualTo(1));
        }

        [Test]
        public void DisabledValveReceivesNoInteraction()
        {
            CreateValve(2f).enabled = false;
            Physics.SyncTransforms();
            Assert.That(interactor.TryInteract(), Is.False);
            Assert.That(delivered, Is.Zero);
        }

        [Test]
        public void MissingCameraReceivesNoInteraction()
        {
            CreateValve(2f);
            interactor.Configure(null, null, null);
            Physics.SyncTransforms();
            Assert.That(interactor.TryInteract(), Is.False);
            Assert.That(delivered, Is.Zero);
        }

        private GameObject CreateRoot(string name)
        {
            var result = new GameObject(name);
            roots.Add(result);
            return result;
        }

        private BoxCollider CreateBox(string name, float distance, Vector3 size)
        {
            var result = CreateRoot(name);
            result.layer = TestLayer;
            result.transform.position = player.transform.position + Vector3.forward * distance;
            var collider = result.AddComponent<BoxCollider>();
            collider.size = size;
            return collider;
        }

        private WaterChannelValve CreateValve(float distance)
        {
            var collider = CreateBox("Test valve", distance, Vector3.one * 0.5f);
            var valve = collider.gameObject.AddComponent<WaterChannelValve>();
            var rejected = (UnityEvent<string>)typeof(WaterChannelValve)
                .GetField("onRejected", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(valve);
            rejected.AddListener(_ => delivered++);
            return valve;
        }
    }
}
