# XR player, artifact UI, and memory camera

Target: Unity 6000.0 LTS, XR Interaction Toolkit **3.0.x**, Input System 1.11.x,
XR Plug-in Management 4.5.x and OpenXR 1.12.x, URP 17.x, Unity UI 2.0.x.
Use Package Manager versions supported by your particular Unity 6 patch; the source
uses XRI 3 namespaces, not the older action-based provider names from XRI 2.

## Rig

1. Enable Input System (or Both) in Player settings. Enable OpenXR for Android
   and/or Standalone. Add the appropriate controller interaction profiles and
   run OpenXR's project validation. Install the XRI 3.0.x Starter Assets sample.
2. Create **XR Origin (VR)** with a tracked main Camera and controller objects,
   using the Starter Assets rig as a reference. Retain its tracked pose drivers,
   controller input readers, XR Interaction Manager, XR Body Transformer and
   Locomotion Mediator. Use floor tracking for room-scale VR. Configure the
   Origin's CharacterController and character-height tracking from that sample
   so standing, crouching, collision and gravity remain tracked.
3. Establish one owner for action enablement **before entering Play mode**:
   disable every Starter Assets **Controller Input Action Manager** component
   (`ControllerInputActionManager`) on the left and right controllers. Disable
   only those components, keeping the controller GameObjects, tracking and
   normal interaction rays active. These sample components call
   `UpdateLocomotionActions()` in Start and during interaction, independently
   disabling Turn or Snap Turn according to their sample settings; leaving them
   enabled prevents `XRPlayerSettings` from reliably switching turn modes.
4. Keep one enabled **Input Action Manager** (`InputActionManager`) and add
   **XRI Default Input Actions** to its Action Assets list. It enables the whole
   action asset, including both Turn and Snap Turn actions. Do not also use
   PlayerInput to switch/disable these maps, or another script to change their
   enabled state. Both turn actions stay enabled; only the selected provider
   consumes input. This ownership also applies to the photo-shutter action map.
5. Use exactly one plain **Continuous Move Provider**, one **Snap Turn Provider**
   and one **Continuous Turn Provider**, all pointing to the same Locomotion
   Mediator. If adapting the sample rig, remove its **Dynamic Move Provider**
   before adding the plain Continuous Move Provider. Do not run duplicate move
   providers. Disable unused sample teleport, grab-move, two-handed grab-move and
   climb providers, and explicitly deactivate Teleport Interactor GameObjects;
   the disabled sample controller manager no longer toggles teleport rays.
6. Set the provider input readers to the following XRI 3 modes and references.
   These are the exact action names in the XRI 3.0.7 Starter Assets action asset:

   | Provider | Left hand reader | Right hand reader |
   | --- | --- | --- |
   | Continuous Move Provider | Input Action Reference: `XRI Left Locomotion/Move` | **Unused** |
   | Snap Turn Provider | **Unused** | Input Action Reference: `XRI Right Locomotion/Snap Turn` |
   | Continuous Turn Provider | **Unused** | Input Action Reference: `XRI Right Locomotion/Turn` |

   Set Move's Forward Source to the tracked Camera, Enable Strafe on, Enable Fly
   off and Use Gravity on. The left stick moves; the right stick turns. Using
   Unused for the other readers prevents the same stick from moving and turning.
7. Add `XRPlayerSettings`, assign these three providers, and start with Snap.
   Wire a menu to `SetTurnMode(0)` for Snap, `SetTurnMode(1)` for Continuous, or
   `SetTurnMode(2)` for Disabled. Its setters change provider enablement only,
   so both turn actions must remain enabled by the Input Action Manager in
   step 4. It preserves tracked head motion when locomotion is paused.
8. Keep normal XR Ray Interactors active and configure Select to the controller
   trigger and UI Press to its matching action in the Starter Assets action
   asset. Turn **Enable UI Interaction** on. Set **Manipulate Attach Transform**
   off on the rays and leave their thumbstick/UI-scroll inputs unused: this
   game's sticks are reserved for movement and turning, with button-only
   artifact panels. If using the sample line visuals, assign their active
   provider to the normal interaction ray rather than the disabled teleport
   ray. Keep an XR Interaction Manager and configure XRI interaction layers so
   artifacts are reachable; physics and XRI interaction layers are separate.

The normal rays read tracking, Select and UI Press directly, so disabling the
sample controller manager does not disable trigger interaction. That manager's
sample teleport switching, ray attach manipulation arbitration and UI-scroll
arbitration are intentionally replaced by the fixed configuration above. Do not
re-enable it later while this component owns locomotion settings.

## Artifact selection and branching UI

- Each artifact GameObject needs its `ArtifactNode`, a Collider and
  `XRSimpleInteractable`. Put the collider on the interactable's collider list or
  let XRI discover its children. Add `ArtifactInteractor`, assign that node, the
  shared `ArtifactChoicePanel`, and the tracked head Transform. The artifact
  transform should be close to the intended selection point.
- Create a **world-space Canvas** at metre scale, about 1.0 m wide. Add
  `TrackedDeviceGraphicRaycaster` and assign the XR Camera as its event camera.
  Create a title `UnityEngine.UI.Text`, description Text, status Text, button
  container with VerticalLayoutGroup and ContentSizeFitter, a Button prefab
  containing Text, and a Close button.
- Put the `ArtifactChoicePanel` component on a persistent controller object and
  assign the Canvas object as `panelRoot`. Assign its text fields, button
  container, and Button prefab. Prefer a prefab asset or an inactive template
  outside the button container. Wire Close to `ArtifactChoicePanel.Close`.
  Add font assets to all uGUI Text components; no TMP package is required.
- The scene must have **one EventSystem** using `XRUIInputModule`. Remove its
  StandaloneInputModule/InputSystemUIInputModule. Ray interactors deliver UI
  presses to this module. Ensure the Canvas graphic raycaster and button
  graphics allow raycasts, and keep the panel outside opaque scenery.
- Selection opens the panel in front of the head. Buttons use stable choice IDs
  and call `QuestManager.TryChoose`; the manager owns all prerequisites and
  single-commit rules. Walking out of range closes the panel and range is checked
  again at commit. The final artifact instructs the player to use the four
  water-channel controls supplied by the Core module.

`ArtifactInteractor.Configure(node, panel, head)` and
`Photographable.Configure(id, label, isArtifact, artifactId)` support procedural
scene builders. For authored scenes use the serialized Inspector fields.

## Environment camera and journal

1. Create one persistent `JournalManager`. It reads/writes a versioned JSON file
   under `Application.persistentDataPath`; it keeps the previous revision as a
   backup. The journal keys photos by stable, case-sensitive memory ID. Corrupt or
   unsupported older saves may fall back to the backup. A newer save version
   stops fallback and disables JSON writes for the session, preserving both the
   primary and backup while allowing new photos to be journaled in memory.
2. Add `Photographable` to each landmark/artifact root. Set a unique `memoryId`,
   label, optional artifact relation, and a framing point on the visible part of
   the model. Put its solid colliders on that root or its children. The framing
   point must be visible from the intended photography location.
3. Add `EnvironmentCamera` to a held camera tool or player object. Assign the
   viewfinder (tool lens or head), journal, and a dedicated Button action such
   as a grip press. Enable that action's map through Input Action Manager;
   this script subscribes but never enables/disables a shared action. A Unity UI
   button may instead call the public, parameterless `Photograph()` method.
4. Set `visibilityMask` to include scenery **and** target colliders, excluding
   the player/tool's colliders. It must include every wall that should block a
   shot. Non-trigger colliders block the line of sight. The code chooses the
   unrecorded target nearest the centre of the cone; ties use distance.
5. Subscribe to `JournalManager.PhotoRecorded` or the serialized camera events
   for shutter sound, haptics and memory UI. `onNoNewMemory` handles misses and
   previously recorded subjects without creating duplicate entries.

Without an image camera, photographing still records a complete memory entry
(ID, label, UTC timestamp, pose, artifact relation), useful for a diegetic memory
journal. For actual PNGs, create a **separate disabled Camera**, set Target Eye
= None, and assign it as `captureCamera`. Give it a suitable near clip, culling
mask, URP renderer and FOV. Do not use the tracked XR Camera: changing its
render target disrupts headset rendering. On capture its pose temporarily
matches the viewfinder and is restored, as are all render targets. URP uses a
`RenderPipeline.StandardRequest`, and temporary GPU/CPU resources are released
in `finally`. Image filenames are GUIDs under the journal's `rivers-photos`
folder. There is a synchronous readback/PNG encode only at shutter time; leave
images disabled or use a low resolution on Quest to avoid a capture hitch.

## Device acceptance checks

Test floor height, crouching, collision, smooth movement, snap/continuous
exclusivity, trigger selection and world-space UI in a headset. Verify a wall
blocks photos and that child colliders are accepted; reopening the app must
keep exactly one entry per memory ID. The code has not been headset-tested in
this workspace; package resolution, rendering and hardware input require the
Unity Editor and a target device.
