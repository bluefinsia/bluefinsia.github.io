# Create a playable desktop test scene

Import the source folder into a Unity 6000.0 Universal 3D project, install the package
dependencies, and use **Input System Package (New)** as Active Input Handling. Once
scripts compile, choose **Tools → Rivers in the Sky → Create Desktop Demo Scene**.
The generator offers to save any modified current scene before creating a new one.
It never replaces an existing scene: repeated runs use a unique DesktopDemo filename.
Generated material assets are reused and existing material edits are preserved.

Open the Game view and press **Play**. The pointer locks for mouse look. Use:

| Control | Action |
| --- | --- |
| WASD | Walk with collision and gravity |
| Mouse | Look around |
| E or left click | Open the aimed artifact or connect an aimed channel valve |
| F | Photograph a visible new memory |
| T | Toggle the colored environmental diagnostic on demo materials |
| Escape | Close a choice panel, or release the cursor |
| Left click with free cursor | Return to mouse look when no choice panel is open |

Choice panels release the pointer and pause movement/look while visible. Use the
mouse to click a choice or Close. The crosshair marks the centre of the view.

## What the generator wires

- A CharacterController player, eye-height camera, one AudioListener, and the
  desktop movement/interaction components. No input action asset is required.
- One quest service, journal, and audio landscape, using the original five-artifact
  defaults. The first four artifacts have their original eight choices; the final
  artifact describes the four water channels.
- A world-space legacy uGUI choice panel, normal GraphicRaycaster, EventSystem,
  and InputSystemUIInputModule. Its controller stays outside the hidden Canvas.
- Five labeled artifact primitives with distance/occlusion-checked interaction,
  unique photo memory IDs, and branch-specific colored consequence markers.
- ISO's following sphere and on-screen subtitles using the original act/choice
  dialogue. You may replace its mesh and assign recorded voice clips later.
- Four channel valves with green connected indicators. Water requires Pagoda,
  Lotus requires Lotus, Lantern requires Lamplight, and Rice requires Rice Field.
  Either branch resolves a prerequisite. All four channels fill the pool over
  time and show the final memory when it is full.
- Procedural glowing materials, a directional light, the painterly global Volume,
  and camera post-processing. EcologyThermalDriver maps habitat, pollution,
  toxicity, and flood-risk deltas onto the corresponding first four artifact
  materials. These are relative game-unit diagnostics, not measured temperature;
  the pool and final-artifact surfaces retain their neutral authored values.

The colored primitives are test-scene art. The underlying choice data, ISO lines,
quest consequences, channel conditions, and final-memory timing are the same systems
used by authored scenes. Replace meshes and material textures with your environment
art without changing the quest or memory IDs.

## Saves and media

The generated demo turns **QuestManager Load On Awake / Auto Save** and
**JournalManager Persistence Enabled** off. Every Play starts fresh and does not
overwrite an existing game's saves. To test the original persistent state behavior,
enable those settings in the Inspector. Existing save filenames and schemas are
unchanged. Keep a single owner of each save file.

The photography tool records memory metadata by default. For PNG output, assign a
separate disabled camera as described in Desktop.md; do not reuse the active view
camera. F does not capture the whole Game view or its HUD.

The AudioLandscapeManager is wired to quests but has no audio recordings assigned.
Assign wind, underwater ambience, and five aligned Đi Cấy stems to hear the original
dynamic arrangement. No generated substitute song or voice recordings are included.

## Build

Save the generated scene, add it to **File → Build Profiles → Scene List**, select
your supported desktop platform, and choose **Build And Run**. No headset, runtime
loader, or device-specific setup is needed.

Unity is not installed in the source-generation environment, so this scene builder
still needs its first Unity import/Play validation. Test mouse capture, both choices,
wall occlusion, photo uniqueness, all four valves and final pool, diagnostics, and
save/reload behavior before using a desktop build as a release.
