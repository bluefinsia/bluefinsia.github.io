# Verification performed in this environment

The Unity Editor and a VR headset are not installed in this environment. The package has
not been imported into Unity, rendered, built for Android, or tested on a headset here.
Do those checks before treating it as a production build.

## Executed domain checks

The actual `ArtifactDefinition.cs` and `QuestState.cs` sources were compiled as C# 9
using portable .NET SDK 8.0.427. Minimal stand-ins supplied only Unity's metadata
attributes, ScriptableObject factory, and asset destruction so the deterministic domain
code could execute outside Unity. No quest logic was replaced by a test double.

**Result: 13,842 assertions passed across 384 complete runs**, covering all 16 combinations
of the first four branch choices in all 24 artifact orders. Checks included:

- Exactly one commitment per artifact, with unchanged counters on repeated input.
- Correct resolved/restorative counts and ISO act at every step.
- Every branch combination reaches the final memory, including all nonrestorative choices.
- Channel prerequisites, duplicate channel rejection and compound flag rejection.
- No pool fill before all channels, partial fill persistence and one final unlock edge.
- Restoring canonical state from duplicate, unknown and removed choice records.
- Rejecting nonfinite fill data, invalid time deltas and unsupported future save versions.

## Source/API checks

All 23 generated C# files were parsed with Roslyn using Unity-compatible C# 9 syntax; no
syntax errors were found. This does not establish Unity assembly/API compilation.
Assembly definition and dependency JSON were checked for valid syntax.

The official XR Interaction Toolkit **3.0.7** package source was inspected to verify:

- Movement.ContinuousMoveProvider and its moveSpeed property.
- Turning.SnapTurnProvider.turnAmount and ContinuousTurnProvider.turnSpeed.
- Interactables.XRSimpleInteractable and selectEntered's SelectEnterEventArgs namespace.
- Runtime assembly name Unity.XR.Interaction.Toolkit.

The official uGUI runtime assembly definition was inspected: its assembly name is
**UnityEngine.UI**; that is the required runtime reference for UnityEngine.UI widgets.

Unity-Technologies Graphics **6000.0/staging** source was inspected to verify:

- UniversalRenderPipeline accepts RenderPipeline.StandardRequest and SingleCameraRequest.
- VolumeProfile.Add<T>(bool) and TryGet<T> generic contracts.
- Standard URP shader shadow and lighting helper usage reviewed against supplied HLSL.
  The shader uses inline directional near-depth clamping, so it does not require the
  newer ApplyShadowClamping helper whose presence in pinned URP 17.0.3 was unverified.

## Required Unity checks

Use Window > General > Test Runner to run the included **28 EditMode test cases** after
import (24 quest cases and 4 journal cases). These Unity tests were supplied but were not
executed in this environment.
Then test ray-to-UI selection, save reload without dialogue replay, final pool timing,
photograph occlusion and PNG output, stem synchronization, both eye rendering, snap and
continuous turn exclusion, and standalone device CPU/GPU frame time. Compile the shader
for the graphics APIs used by each target. Audio recordings, voice clips and world art
must be supplied as authored media and assigned as described by the setup documentation.
