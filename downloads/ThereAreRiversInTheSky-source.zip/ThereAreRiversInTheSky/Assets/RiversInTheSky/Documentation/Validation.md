# Desktop conversion verification

Unity is not installed in this environment. This source kit and its generated scene
have not yet undergone Unity import, full Unity assembly compilation, shader
compilation, Play-mode input testing, or a desktop build here.

## Retained behavior

A Roslyn token comparison checked all **16 retained non-VR C# components** against
the original package, ignoring comments/formatting. Result: **0 token differences**.
These are the seven Core components, two Companion components, two Audio components,
three Rendering components, JournalManager, and Photographable. Serialized choice
IDs, dialogue text, quest/journal save schemas and filenames remain unchanged.

ArtifactInteractor and ArtifactChoicePanel replace controller selection with
camera-ray/mouse UI. EnvironmentCamera keeps its original capture/journal behavior
while removing the stereo-camera restriction. The shader removes stereo output
macros while retaining its color, light, emission, flow and diagnostic math.

## Executed checks

The actual ArtifactDefinition.cs and QuestState.cs were compiled with portable
.NET SDK 8.0.427 and C# 9. Minimal stand-ins supply only Unity metadata attributes,
ScriptableObject creation and asset destruction; domain logic is the real source.

**13,842 assertions passed across 384 complete runs**: all 16 branch combinations
in all 24 artifact orders, plus duplicate rejection, canonical invalid-save
restoration, channel prerequisites, partial fill, nonfinite inputs, future schema
rejection and exactly one final-unlock transition.

All **26 C# files** parse as Unity-compatible C# 9 with **0 syntax errors**.
This parse does not establish Unity API/assembly compilation. All three assembly
JSON files and the four-package dependency snippet parse. No controller/headset
package, namespace, runtime component or shader stereo macro remains in deployable
source/configuration. The old player-settings component is removed.

## Source API review

Official Input System 1.11.2 source was checked for InputActionMap.AddAction's
expectedControlLayout parameter and InputSystemUIInputModule.AssignDefaultActions.
Both desktop drivers own their input maps, and the UI module owns its own UI actions.
The viewport-ray Vector3 argument uses three coordinates. The first non-player
solid hit blocks targeting; the ray starts at the lens to include near-plane walls.

Cursor/menu review covers opening-click suppression, closing-frame input blocking,
movement/look suspension, capture-click suppression, focus release, and first-look
sample suppression after capture. These paths require interactive Unity validation.

The uGUI runtime assembly is UnityEngine.UI. URP17 source API checks from the
original package remain applicable: StandardRequest image capture, VolumeProfile
Add/TryGet, main-light shadows and lighting helpers. Shadow near-plane clamping is
inlined for URP17 patch compatibility. Ordinary GPU instancing remains supported.

## Supplied Unity tests and acceptance

There are **36 EditMode test cases**: 24 quest cases, 4 journal cases and 8 desktop
interaction cases. Desktop cases exercise unobstructed delivery, wall and near-plane
wall occlusion, distance limits, self-collider filtering, trigger exclusion, disabled
valves and missing cameras without physical input devices. These tests have not been
executed in Unity here. Run Window > General > Test Runner > EditMode after import.

Create the demo through Tools > Rivers in the Sky > Create Desktop Demo Scene.
Verify walking against walls, diagonal speed, mouse-look pitch, E/click selection,
mouse UI choices, Escape/cursor restore, F photo uniqueness/occlusion, optional PNG,
T diagnostic view, ISO's act/dialogue, all four valves, final fill and save/reload.
Assign real audio media and verify stem alignment and underwater crossfade.
Build the scene for the selected desktop graphics API and measure CPU/GPU frame
time. A source parse or domain check cannot replace these Unity checks.
