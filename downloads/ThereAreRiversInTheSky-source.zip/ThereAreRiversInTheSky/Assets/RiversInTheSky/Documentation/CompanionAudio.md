# ISO companion and soundscape

## ISO

Add `IsoCompanion` to the visual root of ISO. Assign `QuestManager`, the XR Origin's
tracked Main Camera transform, and an optional dedicated mono `AudioSource` on ISO.
Set that source to spatial blend 1, logarithmic rolloff, a near distance around 1 m,
and a maximum distance appropriate to the scene. Never put another AudioListener on ISO.
`Configure(QuestManager, Transform)` supports runtime spawning without a scene search.

The follow offset is relative to the headset's horizontal heading, with world-up
vertical movement. Each axis has its own damp time and velocity. Teleport jumps
reset those velocities instead of causing a long high-speed flyover. Optional
sphere casts constrain the desired location and each movement step. Configure the
obstacle mask to static environment geometry; exclude player, ISO, triggers and water.
This is local collision avoidance, not a pathfinding system: narrow passages may
hold ISO near a wall. For large separated rooms use teleporting or a designed follow route.

Quest state is the authoritative state machine. `IsoCompanion.Act` follows its saved
act; `ActChanged` and the serialized act UnityEvent update animations or light colour.
Loading updates the act without enqueuing dialogue. Only new committed choices and
the new final-memory transition enqueue lines. All eight branches include original
English subtitle dialogue for each of the three acts. Its interpretation follows
the committed act even when artifacts are visited in a different order: resource
analysis, concern and questioning, then empathy for a living home. Per-artifact/per-act
overrides can assign localized text and recorded voice. No third-party dialogue or
voice recordings are bundled.

Wire `On Subtitle Changed` to a UI text setter, subscribe to `SubtitleChanged`, or
use `IsoSubtitlePresenter` with a world-space uGUI `Text` and `CanvasGroup`.
Use a stable, comfortably sized panel; avoid locking a constantly moving panel to
the centre of the player's view. Empty subtitles hide via CanvasGroup without
disabling the presenter. ISO never drives the tracked headset.

The queue keeps voices from overlapping. A disabled companion stops its dedicated
voice source and clears the transient queue; re-enabling never replays old choices.
Subtitle time uses unscaled time, so menu pauses do not strand a subtitle.

## Audio

See [Audio.md](Audio.md) for the DSP-synchronized environmental and folk-song stems.
