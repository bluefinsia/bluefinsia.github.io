# Desktop player, artifact UI, and memory camera

Target: Unity 6000.0, URP 17, Input System 1.11.x, and Unity UI 2.0.x.
The player uses a normal Camera and CharacterController. No headset, tracked
controllers, interaction toolkit, or headset runtime is required.

## Controls

| Input | Action |
| --- | --- |
| W / A / S / D or arrow keys | Walk |
| Mouse movement | Look around |
| E or left mouse button | Interact with the artifact or water-channel valve under the centre ray |
| F | Photograph a visible, unrecorded memory |
| T | Toggle the diagnostic overlay on the interactor's assigned Diagnostic Surfaces |
| Escape | Close the choice panel, or release the gameplay cursor |
| Left mouse button while the cursor is free | Return to mouse-look when no choice panel is open |

Opening an artifact releases the cursor so its world-space buttons can be clicked.
Movement, look and gameplay ray actions are suspended while the panel is open or
the cursor is released. Closing the panel restores the previous cursor state;
the opening click cannot also select a newly spawned choice.

## Player and action ownership

1. In Player settings, set **Active Input Handling** to **Input System Package
   (New)**. Create a Player object with a CharacterController. Keep its physical
   dimensions appropriate for the environment; one Unity unit represents a metre.
2. Add one normal Camera beneath Player at eye height and tag it MainCamera. Use
   one AudioListener on that Camera. Add `DesktopPlayerController` to Player and
   assign that Camera and the shared choice panel. Its movement uses the
   CharacterController, gravity, a normalized movement vector and yaw-relative
   direction. Mouse look rotates the player horizontally and clamps camera pitch.
3. Add `DesktopInteractor` and assign the view Camera, shared choice panel and
   `EnvironmentCamera`. It casts one camera-centre ray when interacting. The first
   non-trigger solid hit determines the target: walls block selection. Its mask
   must include both scenery and interactables and exclude the player's own layer.
4. The two desktop components own their generated InputActionMaps. They enable,
   disable and dispose only their own actions. No input-action asset is required
   for movement, look, interaction or the default F shutter binding. Keep a
   PlayerInput component from independently driving the same gameplay controls.
   The EventSystem's UI input module owns its separate mouse/UI actions.
5. Keep one scene-owned Services object with `QuestManager`, `JournalManager`, and
   `AudioLandscapeManager`. Assign their references explicitly in consumers.
   Services do not automatically survive replacing their scene: retain the service
   scene during additive world loading, or provide your own persistent scene owner.

## Artifact selection and branching UI

- Each artifact needs a solid Collider, `ArtifactNode`, and `ArtifactInteractor`.
  Set the node's quest-manager reference and unique ArtifactId. Assign the shared
  choice panel and player Camera transform to the artifact interactor. Its
  serialized **Player Head** field now means the desktop Camera; its name is kept
  to preserve existing serialized references.
- `DesktopInteractor` calls `ArtifactInteractor.TryInteract(camera.transform)`
  only when its ray hits that artifact. The artifact rejects missing references,
  disabled components, and out-of-range attempts. Range is checked again before a
  branching choice commits. Both branches and all progression rules are unchanged.
- Create a **world-space Canvas**, about 1.0 m wide, with a regular
  `GraphicRaycaster`. Set its event Camera to the desktop Camera. A RectTransform
  of 1000 by 600 scaled to 0.001 is a useful starting size.
- Use **Legacy uGUI Text**, not TMP, for the title, description, status, and button
  labels. The fields are explicitly typed `UnityEngine.UI.Text`. Assign readable
  fonts. Create a button container with VerticalLayoutGroup/ContentSizeFitter, a
  reusable Button prefab containing legacy Text, and a Close button.
- Put `ArtifactChoicePanel` on a controller object **outside** its `panelRoot`.
  Assign the Canvas as panelRoot, its label fields, the button container, and the
  prefab asset. Wire Close to `ArtifactChoicePanel.Close()`. The script creates
  choice callbacks from the stable IDs, so leave the prefab's gameplay callbacks
  empty. It temporarily suppresses raycasts while an opening mouse click is held.
- Use exactly one EventSystem with `InputSystemUIInputModule`. Remove any
  StandaloneInputModule. Assign the module's standard UI actions/default actions
  so mouse movement and clicks reach the GraphicRaycaster.
- The fifth artifact displays instructions for the four channel controls. Add a
  solid Collider and `WaterChannelValve` to each control. Set its manager and one
  channel flag. The desktop centre ray calls `Connect()` directly; no Inspector
  event wiring is required for the default desktop driver. Buttons may also call
  the same public Connect method. Channel prerequisites and timed pool fill are
  identical to the original quest design.

`ArtifactInteractor.Configure(node, panel, cameraTransform)` and
`Photographable.Configure(id, label, isArtifact, artifactId)` support procedural
scene builders. Leave QuestManager's definitions array empty for the complete
built-in five-artifact catalog, or assign editable assets created through the
provided authoring menu.

## Environment camera and journal

1. Create one `JournalManager`. It uses the same versioned JSON schema, stable
   case-sensitive memory IDs, relative image names, timestamps, and pose records.
   The existing save and photo-directory names are unchanged. Corrupt older files
   may fall back to a backup; a newer schema disables writes and backup fallback
   for that session so both saved revisions remain intact.
2. Add `Photographable` to each artifact or landmark root. Assign a unique memory
   ID, display label, optional artifact relation, and a framing point on a visible
   part of the object. Place its solid colliders on that root or its children.
3. Add `EnvironmentCamera` to the player or Camera. Assign the player Camera
   transform as Viewfinder and the JournalManager. Assign this component to
   DesktopInteractor; F calls its public `Photograph()` method. Leave Shutter
   Action empty when using that default binding to avoid duplicate shutter calls.
4. An optional `InputActionReference` can instead drive the shutter. Its owning
   Input System component must enable that map; EnvironmentCamera only subscribes
   and never changes the enablement of an externally owned action. Coordinate
   that map's menu state with your player UI. A UI button can call Photograph()
   directly without an action asset.
5. Set Visibility Mask to include scenery and targets and exclude the player/tool.
   The photograph must meet distance and framing-cone limits and have a clear line
   of sight. The nearest-to-centre unrecorded subject wins; distance breaks ties.
   Misses and duplicate subjects do not append journal entries. The serialized
   camera events and JournalManager.PhotoRecorded can drive sound, feedback and UI.

Metadata photography is fully functional without a capture Camera. For actual
PNGs, create a **separate disabled Camera** and assign it as Capture Camera. Give
it an appropriate URP renderer, culling mask, near clip and FOV; its FOV should
include the framing cone. The script temporarily matches its pose to the
Viewfinder and restores its transform and render target in finally. It never
redirects the active player Camera. URP uses RenderPipeline.StandardRequest.
Temporary GPU/CPU resources are released, and image filenames are GUIDs under
Application.persistentDataPath/rivers-photos. PNG capture performs a synchronous
readback/encode at shutter time, so measure capture frame time and use a modest
resolution when needed.

## First scene and acceptance checks

Use a floor collider, one player, one Services object, one choice Canvas, and a
Pagoda cube about 2 m ahead for the first test. Connect the references above.
Select the cube, choose a branch, and reopen it to see the recorded memory.
For repeatable initial runs, disable QuestManager Load On Awake and Auto Save and
JournalManager Persistence Enabled. Re-enable persistence to test reloading.

Then verify walls block both interaction and photographs, the opening click does
not choose an option, Escape closes/releases correctly, WASD/look stop while
clicking choices, F records each memory once, and all four valves fill the pool.
The included domain tests remain valid; desktop input and rendering require the
Unity Editor for interactive validation. Add the scene to File > Build Profiles >
Scene List, select the desktop target supported by your Editor, and Build And Run.
