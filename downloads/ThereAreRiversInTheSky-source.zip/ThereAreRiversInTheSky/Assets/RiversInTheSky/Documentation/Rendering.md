# URP 17 painterly rendering and environmental diagnostic view

## Complete included shader

`RiversInTheSky/PainterlyBioluminescence` is an opaque, depth-writing shader with Forward,
ShadowCaster and DepthOnly passes. It requires a **Universal Renderer using Forward or
Forward+**; deferred, SSAO/DepthNormals, motion vectors, baked lightmaps and additional
per-pixel lights are outside this shader's feature set. Ambient spherical harmonics and
the main realtime light are supported. Use an ordinary URP Lit material where those
additional features are required. This surface shader is not a water/refraction shader.

Create a material using this shader. The default procedural value noise supplies colony
and brush variation without requiring a texture. Set `_ProceduralPattern=0` to replace it
with an artist's repeating linear-data texture: **R** colony density, **G** brush variation,
**B** diagnostic spatial variation. Disable sRGB on this texture and use Repeat wrap.
`_BaseMap` remains an ordinary sRGB albedo texture. `_PatternScale` is world XZ frequency;
use a mesh/UV Shader Graph variant for vertical walls where XZ projection stretches.

For cyanobacteria use `_EmissionStrength=1`, HDR `_GlowColor=(0.03,1.8,1.4)`, colony threshold
0.5, softness 0.12, iridescence 0.6 and flow speed 0.04. For palace stone use the same
shader with emission 0 and a warm neutral base color. Light quantization and smooth brush
variation produce painterly surfaces without noisy screen-space processing. A single
opaque water-surface coating or rock material avoids multiple translucent glowing shells.

Attach `CyanobacteriaController` to a surface root, assign **XR Origin > Camera** as Head,
QuestManager, and its target renderers. Empty renderer lists populate from children in
Awake. It supplies the same head position to both eyes, a smooth proximity falloff,
and water flow increasing as channels reconnect. `SetFlowStrength(float)` changes to
manual flow, useful for a stream whose gate has independent gameplay state. Missing Head
turns proximity response off. No `renderer.material` calls or material allocation occur
per frame. MaterialPropertyBlocks can exclude these controlled renderers from SRP
Batcher batching; keep controlled surface groups modest and profile on the target Quest.
The shader's CBUFFER layout itself is consistent across all passes. Do not let a second
component overwrite these same property names in a separate block.

## Environmental diagnostic / thermal-imaging appearance

Call `SetThermalView(true)` on relevant controllers, or connect a UI button to
`ToggleThermalView()`. `SetThermalValue(0..1)` provides an environmental impact index: blue
and cyan are low values, yellow and red high values. `_ThermalTextureInfluence` optionally
adds spatial detail from the B channel; keep 0 when displaying a measured uniform scalar.
This overlay replaces surface RGB in the same opaque pass, preserves the surface/depth
silhouette and avoids a fullscreen XR blit. It does not claim to measure physical heat
and does not reveal occluded objects. Objects must use this shader to participate.

Core ecology values are **signed game-unit deltas**, so do not feed them directly as
normalized temperature. For a deliberately labeled relative diagnostic, an author can
map Toxicity / 2 for the default catalog; custom catalogs should supply their own range.
For local leakage or flood-risk zones, feed a normalized local simulation value instead.
`EcologyThermalDriver` provides a complete bridge: assign QuestManager and the local
CyanobacteriaController, choose Habitat/Pollution/Toxicity/FloodRisk/Nutrients, and author
a baseline and `unitsToFullScale`. Its mapping is `Clamp01(baseline + signedDelta / unitsToFullScale)`;
`invert` negates the delta before mapping. Use invert for habitat loss (a negative Habitat
delta becomes a hotter impact color). A baseline of 0.5 with 4 units to full scale maps
Toxicity +2 to red at 1.0. For nutrient deprivation, enable invert; for nutrient excess,
leave it off. Use separate local drivers for the wetland, leaking energy cell and rice
irrigation areas; displaying the global aggregate in every area is a narrative choice,
not a spatial simulation. This makes the overlay useful without inventing scientific units.

## Equivalent Shader Graph setup (URP Lit, Opaque)

Use **World Position** XZ → Multiply `_PatternScale` → subtract normalized FlowDirection XY
× Time × FlowSpeed × FlowStrength → Sample PatternMap (or Gradient Noise). R → Smoothstep
(Threshold-Softness, Threshold+Softness) gives Colony. World Position minus ObserverWS →
Length → Divide Radius → One Minus → Saturate → Multiply ProximityStrength gives NearHead.
World Normal dot normalized World View Direction → Saturate → One Minus → Power(3) gives
Fresnel. Add Fresnel + G×0.15 to Vector3(0,0.33,0.67), multiply 2π, Cosine, ×0.5+0.5 for
iridescence. Lerp GlowColor to GlowColor×(0.35+IridescenceRGB) by `_Iridescence`; multiply
by Colony × EmissionStrength × (0.12+NearHead+0.8×FlowStrength) for **Emission**. G can modulate
Base Color by Lerp(1,0.7+0.6×G,BrushStrength). Use the supplied HLSL shader when quantized
main-light bands are required; the standard Lit Graph lights continuously.

For a Graph diagnostic palette, lerp blue→cyan over Saturate(t×3), yellow→red over
Saturate(t×3-2), then lerp those pairs by Saturate(t×3-1). Lerp normal BaseColor to that
palette by ThermalBlend and multiply lit contribution by OneMinus(ThermalBlend), or use
an Unlit Graph for an exact lighting-independent palette. The supplied shader implements
this directly after lighting. Do not use screen-position offsets or a shared mono
projection for eye-dependent view vectors.

## Grading

Add a **dedicated global Volume** (isGlobal=true, Weight=1, priority above the base grade)
with `PainterlyGradeController`. Assign QuestManager. Its runtime profile and overrides
are cloned and destroyed on disable; the source asset remains editable and unchanged.
Enable **Post Processing** on the XR Camera's Universal Additional Camera Data. The
controller uses ColorAdjustments (contrast +10, saturation -8), WhiteBalance (twilight
-12 through candlelight +16), and a gentle 0.08 vignette. Bloom is off by default; enable
it only with an HDR pipeline/camera configuration and after GPU profiling. Configure
Tonemapping=ACES or Neutral in the base Volume if desired. The controller's warmth follows
CleansedCount / 5, not simply visiting a damaged artifact; SetWarmth allows other cues.

For Quest, start with single-pass instanced/multiview, Vulkan, MSAA 4x, a modest render
scale, one directional main light, baked world lighting where ordinary Lit materials are
used, short shadows, and no HDR/bloom, SSAO, motion blur, depth of field or TAA. Retain
emissive surface colors without bloom. PCVR can enable HDR and low-intensity bloom (0.18,
threshold 1.1), but judge text contrast and comfort inside the headset. Exact frame budget
depends on headset and refresh rate; measure CPU/GPU with a standalone headset build.

The shader carries instance and stereo macros, initializes stereo outputs in forward and
depth passes, and sets the fragment eye before `GetWorldSpaceNormalizeViewDir`. Its
iridescence is intentionally view dependent; proximity response remains eye independent.
