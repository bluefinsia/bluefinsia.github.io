# Quest and consequence architecture

`QuestManager` owns a deterministic `QuestState`; its references are explicit scene dependencies. Add one manager and assign authored `ArtifactDefinition` assets, or leave its array empty to use the complete five-artifact default catalog. `ArtifactDefinition.CreateDefault(id)` produces the same assets for editor generation. Every choice has a stable save ID, label, consequence text, restoration flag, and signed ecological deltas. Keep existing IDs stable across updates or migrate saved records deliberately.

Attach `ArtifactNode` to each artifact beside its collider and XR interactable; assign the manager and artifact enum. `ArtifactInteractor` reads `Definition.Choices` and calls `TryChoose`. The manager rejects invalid, repeated, and reentrant choices. All four binary artifacts may be visited in any order, and either branch resolves its artifact. Resolving two advances ISO to Act II; resolving four advances ISO to Act III. These thresholds measure experience rather than a moral score.

`StateChanged` reconstructs world state, UI, ambient audio and visuals, including immediately after a load. Subscribe in `OnEnable`, read `Snapshot` once there, and unsubscribe in `OnDisable`. A subscriber enabled before the manager has a snapshot receives the manager's initial `Start` event. `ChoiceCommitted` carries a live `ChoiceOutcome` for dialogue, one-shot audio and haptics. It is never replayed on load. `FinalMemoryUnlocked` is a one-shot live unlock event; `Snapshot.FinalMemoryUnlocked` restores already-unlocked content. Each state mutation completes before notification; listener failures are logged independently and cannot prevent other listeners receiving the committed state.

## Consequences and the final pool

Use `ArtifactConsequenceView` to enable a branch's object group and hide unresolved props. Examples: crushed reed geometry for `force_entrance`, flowing passage and restored reeds for `restore_passage`; removed surface waste versus a sealed upstream outlet; cell leakage versus a solar collector; visibly flooded field edges versus a wetland route with sparser nutrient-dependent plants. Groups must contain distinct scene objects and must not disable the component that listens for changes.

Ecological values are signed **game-unit deltas**, not physical simulations or percentages:

| Choice ID | Habitat | Pollution | Toxicity | Flood risk | Nutrients |
|---|---:|---:|---:|---:|---:|
| force_entrance | -2 | 0 | 0 | 0 | 0 |
| restore_passage | +2 | 0 | 0 | 0 | 0 |
| remove_rubbish | 0 | -1 | 0 | 0 | 0 |
| stop_source | 0 | -3 | 0 | 0 | 0 |
| old_cell | 0 | 0 | +2 | 0 | 0 |
| sunlight | 0 | 0 | 0 | 0 | 0 |
| direct_gate | 0 | 0 | 0 | +2 | +2 |
| wetland_route | +1 | 0 | 0 | -1 | -1 |

`ResolvedCount` counts either branch plus the final memory (0–5). `CleansedCount` counts restorative branches plus the final memory (0–5). This distinction lets audio reward discovery through every route while ecological recovery remains meaningful. `FourYoungMaidens` has no binary choice: its four valves call `TryConnectChannel` individually. Lotus requires The Lotus, Lantern requires The Lamplight, Rice requires The Rice Field, and Water requires The Pagoda, each resolved through either branch. Channels may reconnect as each prerequisite is resolved. With all four connected, the pool fills over the serialized duration and resolves the final artifact at 1.0. No branch blocks an ending.

`CentralPoolView` interpolates a separate water surface's local Y, reports fill to UnityEvents and enables the final-memory root. Put this component on a manager object outside the root that it controls. `WaterChannelValve` exposes `Connect()` for an XRSimpleInteractable `selectEntered` UnityEvent, with connected-state and rejection events for feedback.

## Persistence

The manager stores `rivers-quest.json` beneath `Application.persistentDataPath`; use a distinct filename per save slot. JSON stores only schema version, chosen IDs, connected channels and pool fill. Counters, acts and ecology are recomputed, which prevents duplicate application. Invalid and duplicate records are ignored, impossible channel links are removed, and pool fill requires all prerequisites. A future schema disables writes to preserve that save. Corrupt primary files fall back to a `.bak` file; writes stage a `.tmp` file before replacement. Pool progress saves at most once per second and on final completion, pause or disable. Turn `loadOnAwake`/`autoSave` off for isolated scenes and tests. Assets are never mutated to track progress.

`QuestStateTests` covers repeated decisions, every one of the 16 branch combinations reaching the ending, partial pool round trips, impossible saved progress, future schema rejection, ISO act progression, and the rice nutrient tradeoff. Run these in Unity's EditMode test runner; they have not been executed by the cloud source-generation environment.
