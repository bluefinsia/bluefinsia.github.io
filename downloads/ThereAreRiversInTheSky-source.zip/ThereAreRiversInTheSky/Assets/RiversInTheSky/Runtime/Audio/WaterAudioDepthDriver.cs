using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>Drives the ambience crossfade from the view camera's depth below a water plane.</summary>
    [DisallowMultipleComponent]
    public sealed class WaterAudioDepthDriver : MonoBehaviour
    {
        [SerializeField] private AudioLandscapeManager landscape;
        [SerializeField] private Transform playerHead;
        [SerializeField] private Transform waterSurface;
        [Tooltip("Optional box/sphere/capsule or convex mesh defining this water region.")]
        [SerializeField] private Collider waterRegion;
        [SerializeField, Min(0.01f)] private float transitionDepth = 0.25f;

        private void Update()
        {
            if (landscape == null || playerHead == null || waterSurface == null) return;
            Vector3 head = playerHead.position;
            // ClosestPoint returns the supplied point when it is inside a supported volume.
            bool insideRegion = waterRegion == null ||
                (waterRegion.ClosestPoint(head) - head).sqrMagnitude < 0.0001f;
            float depth = waterSurface.position.y - head.y;
            landscape.SetUnderwaterBlend(insideRegion
                ? Mathf.InverseLerp(-transitionDepth, transitionDepth, depth) : 0f);
        }

        private void OnDisable()
        {
            if (landscape != null) landscape.SetUnderwaterBlend(0f);
        }
    }
}
