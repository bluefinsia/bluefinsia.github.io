using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Audio;

namespace RiversInTheSky
{
    /// <summary>
    /// Keeps every folk-song stem on one DSP timeline. Quest changes affect gain,
    /// never playback position, so revealing a layer cannot restart the song.
    /// Audio media is authored separately; assign licensed/owned performances of Đi Cấy.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class AudioLandscapeManager : MonoBehaviour
    {
        [Header("State and routing")]
        [SerializeField] private QuestManager quests;
        [SerializeField] private AudioMixerGroup ambienceBus;
        [SerializeField] private AudioMixerGroup musicBus;

        [Header("Looped soundscapes")]
        [SerializeField] private AudioClip wind;
        [SerializeField] private AudioClip underwater;
        [SerializeField, Range(0f, 1f)] private float ambienceGain = 0.45f;
        [SerializeField, Range(0f, 1f)] private float underwaterBlend;

        [Header("Five aligned Đi Cấy stems, one revealed per artifact")]
        [Tooltip("Export all stems from the same bar range, with matching duration and sample rate. Include silence before each fragment where appropriate.")]
        [SerializeField] private AudioClip[] folkStems = new AudioClip[5];
        [SerializeField, Range(0f, 1f)] private float musicGain = 0.4f;
        [SerializeField, Min(0.05f)] private float fadeSeconds = 2f;
        [SerializeField, Min(0.05f)] private float scheduleLeadSeconds = 0.2f;

        private GameObject ownedRoot;
        private AudioSource windSource;
        private AudioSource underwaterSource;
        private AudioSource[] stemSources;
        private Coroutine preparation;
        private QuestManager subscribedQuests;
        private int resolvedCount;
        private int cleansedCount;
        private bool ready;
        private bool applicationPaused;
        private bool scheduled;
        private double scheduledStart;
        private double remainingLeadOnPause;
        private float smoothedWaterBlend;

        public bool IsReady => ready;

        private void Awake()
        {
            // This component owns only these generated children, never scene-authored sources.
            ownedRoot = new GameObject("Audio Landscape Sources");
            ownedRoot.transform.SetParent(transform, false);
            windSource = CreateSource("Wind", wind, ambienceBus);
            underwaterSource = CreateSource("Underwater", underwater, ambienceBus);
            stemSources = new AudioSource[5];
            for (int i = 0; i < stemSources.Length; i++)
            {
                AudioClip clip = folkStems != null && i < folkStems.Length ? folkStems[i] : null;
                stemSources[i] = CreateSource("Đi Cấy Stem " + (i + 1), clip, musicBus);
            }
            smoothedWaterBlend = Mathf.Clamp01(underwaterBlend);
        }

        private void OnEnable()
        {
            BindQuest();
            preparation = StartCoroutine(PrepareAndSchedule());
        }

        private void OnDisable()
        {
            UnbindQuest();
            if (preparation != null) StopCoroutine(preparation);
            preparation = null;
            ForEachSource(source => { source.Stop(); source.volume = 0f; });
            ready = scheduled = false;
        }

        private void OnDestroy()
        {
            if (ownedRoot != null) Destroy(ownedRoot);
        }

        /// <summary>Rebinds state without disturbing the current music timeline.</summary>
        public void Configure(QuestManager manager)
        {
            UnbindQuest();
            quests = manager;
            if (isActiveAndEnabled) BindQuest();
        }

        /// <summary>Drive with a water-volume sensor, swim depth, or an authored trigger.</summary>
        public void SetUnderwaterBlend(float blend) => underwaterBlend = Mathf.Clamp01(blend);

        private void BindQuest()
        {
            if (quests == null) return;
            subscribedQuests = quests;
            subscribedQuests.StateChanged += OnStateChanged;
            OnStateChanged(subscribedQuests.Snapshot);
        }

        private void UnbindQuest()
        {
            if (subscribedQuests != null) subscribedQuests.StateChanged -= OnStateChanged;
            subscribedQuests = null;
        }

        private void OnStateChanged(QuestSnapshot snapshot)
        {
            if (snapshot == null) return;
            resolvedCount = Mathf.Clamp(snapshot.ResolvedCount, 0, 5);
            cleansedCount = Mathf.Clamp(snapshot.CleansedCount, 0, resolvedCount);
        }

        private AudioSource CreateSource(string sourceName, AudioClip clip, AudioMixerGroup bus)
        {
            var child = new GameObject(sourceName);
            child.transform.SetParent(ownedRoot.transform, false);
            var source = child.AddComponent<AudioSource>();
            source.clip = clip;
            source.playOnAwake = false;
            source.loop = true;
            source.spatialBlend = 0f; // An encompassing landscape; positional sound belongs elsewhere.
            source.dopplerLevel = 0f;
            source.volume = 0f;
            source.outputAudioMixerGroup = bus;
            return source;
        }

        private IEnumerator PrepareAndSchedule()
        {
            // Unloaded clips cannot be scheduled reliably. Loading is asynchronous on platforms
            // that support it; a bad asset cannot hold the entire landscape indefinitely.
            ForEachSource(source =>
            {
                if (source.clip != null && source.clip.loadState == AudioDataLoadState.Unloaded)
                    source.clip.LoadAudioData();
            });
            float deadline = Time.realtimeSinceStartup + 15f;
            bool loading;
            do
            {
                loading = false;
                ForEachSource(source =>
                {
                    if (source.clip != null && source.clip.loadState == AudioDataLoadState.Loading)
                        loading = true;
                });
                if (loading) yield return null;
            } while (loading && Time.realtimeSinceStartup < deadline);

            ForEachSource(source =>
            {
                if (source.clip != null && source.clip.loadState != AudioDataLoadState.Loaded)
                {
                    Debug.LogWarning("Landscape clip could not load: " + source.clip.name, this);
                    source.clip = null;
                }
            });
            ValidateStemTiming();
            while (applicationPaused) yield return null;
            ScheduleAll();
            ready = true;
            preparation = null;
        }

        private void ScheduleAll()
        {
            scheduledStart = AudioSettings.dspTime + Math.Max(0.05, scheduleLeadSeconds);
            ForEachSource(source =>
            {
                if (source.clip == null) return;
                source.Stop();
                source.timeSamples = 0;
                source.PlayScheduled(scheduledStart);
            });
            scheduled = true;
        }

        private void ValidateStemTiming()
        {
            AudioClip reference = null;
            foreach (AudioSource source in stemSources)
            {
                if (source.clip == null) continue;
                if (reference == null) { reference = source.clip; continue; }
                if (source.clip.samples != reference.samples || source.clip.frequency != reference.frequency)
                {
                    Debug.LogWarning("Đi Cấy stems need identical sample counts and sample rates for seamless repeating alignment. Re-export the stems from one timeline.", this);
                    break;
                }
            }
        }

        private void Update()
        {
            if (!ready || applicationPaused) return;
            float step = Time.unscaledDeltaTime / Mathf.Max(0.05f, fadeSeconds);
            smoothedWaterBlend = Mathf.MoveTowards(smoothedWaterBlend, underwaterBlend, step);
            // Equal-power environmental crossfade, with independent master headroom.
            Fade(windSource, ambienceGain * Mathf.Sqrt(1f - smoothedWaterBlend), step);
            Fade(underwaterSource, ambienceGain * Mathf.Sqrt(smoothedWaterBlend), step);

            int audibleStemCount = 0;
            for (int i = 0; i < resolvedCount; i++)
                if (stemSources[i].clip != null) audibleStemCount++;
            // Normalize the sum of target stem gains. Restoration subtly opens the music,
            // while every branch still reveals a fragment and reaches the final arrangement.
            float restoration = resolvedCount == 0 ? 0f : (float)cleansedCount / resolvedCount;
            float perStem = musicGain * Mathf.Lerp(0.7f, 1f, restoration) / Mathf.Max(1, audibleStemCount);
            for (int i = 0; i < stemSources.Length; i++)
                Fade(stemSources[i], i < resolvedCount ? perStem : 0f, step);
        }

        private static void Fade(AudioSource source, float target, float step)
        {
            source.volume = Mathf.MoveTowards(source.volume, Mathf.Clamp01(target), step);
        }

        private void OnApplicationPause(bool paused)
        {
            applicationPaused = paused;
            if (!scheduled || !isActiveAndEnabled) return;
            if (paused)
            {
                // A scheduled start that has not happened needs to be scheduled again after
                // resume; an already-playing loop preserves its exact sample cursor.
                remainingLeadOnPause = Math.Max(0.0, scheduledStart - AudioSettings.dspTime);
                if (remainingLeadOnPause > 0.0) ForEachSource(source => source.Stop());
                else ForEachSource(source => source.Pause());
            }
            else if (remainingLeadOnPause > 0.0)
            {
                ScheduleAll();
                remainingLeadOnPause = 0.0;
            }
            else ForEachSource(source => source.UnPause());
        }

        private void ForEachSource(Action<AudioSource> action)
        {
            if (windSource != null) action(windSource);
            if (underwaterSource != null) action(underwaterSource);
            if (stemSources == null) return;
            foreach (AudioSource source in stemSources)
                if (source != null) action(source);
        }

        private void OnValidate()
        {
            fadeSeconds = Mathf.Max(0.05f, fadeSeconds);
            scheduleLeadSeconds = Mathf.Max(0.05f, scheduleLeadSeconds);
            if (folkStems == null) folkStems = new AudioClip[5];
            else if (folkStems.Length != 5) Array.Resize(ref folkStems, 5);
        }
    }
}
