using UnityEngine;
using UnityEngine.Events;

namespace RiversInTheSky
{
    /// <summary>Wire XRSimpleInteractable.selectEntered to Connect(), or call it from a UI button.</summary>
    public sealed class WaterChannelValve : MonoBehaviour
    {
        [SerializeField] private QuestManager quests;
        [SerializeField] private WaterChannel channel = WaterChannel.Lotus;
        [SerializeField] private UnityEvent<bool> onConnectedState = new UnityEvent<bool>();
        [SerializeField] private UnityEvent<string> onRejected = new UnityEvent<string>();
        private bool initialized, lastConnected;

        public void Configure(QuestManager manager, WaterChannel value)
        {
            if (isActiveAndEnabled && quests != null) quests.StateChanged -= Refresh;
            quests = manager; channel = value; initialized = false;
            if (isActiveAndEnabled && quests != null) { quests.StateChanged += Refresh; Refresh(quests.Snapshot); }
        }

        public void Connect()
        {
            if (quests == null) { onRejected.Invoke("No quest service is assigned."); return; }
            if (!quests.TryConnectChannel(channel, out string error)) onRejected.Invoke(error);
        }
        private void OnEnable()
        {
            if (quests == null) return;
            quests.StateChanged += Refresh;
            Refresh(quests.Snapshot);
        }
        private void OnDisable() { if (quests != null) quests.StateChanged -= Refresh; }
        private void Refresh(QuestSnapshot snapshot)
        {
            if (snapshot == null) return;
            bool connected = (snapshot.ConnectedChannels & channel) == channel && channel != WaterChannel.None;
            if (!initialized || connected != lastConnected) onConnectedState.Invoke(connected);
            initialized = true; lastConnected = connected;
        }
    }
}
