using System;
using UnityEngine;
using UnityEngine.Events;

namespace RiversInTheSky
{
    /// <summary>
    /// Reconstructs persistent scene changes from a chosen ID. Author an object group for each branch
    /// (damaged reeds, closed waste outlet, leakage particles, wetland route, reduced-nutrient crops).
    /// The group remains enabled on save restoration; one-shot narrative belongs to ChoiceCommitted.
    /// </summary>
    public sealed class ArtifactConsequenceView : MonoBehaviour
    {
        [Serializable]
        private sealed class Branch
        {
            public string choiceId;
            public GameObject[] objects = Array.Empty<GameObject>();
        }
        [SerializeField] private ArtifactNode artifact;
        [SerializeField] private GameObject[] unresolvedObjects = Array.Empty<GameObject>();
        [SerializeField] private Branch[] branches = Array.Empty<Branch>();
        [SerializeField] private UnityEvent<string> onConsequenceText = new UnityEvent<string>();
        private bool initialized;
        private string appliedId;
        private QuestManager bound;

        private void OnEnable()
        {
            bound = artifact != null ? artifact.Quests : null;
            if (bound == null) return;
            bound.StateChanged += Refresh;
            initialized = false;
            Refresh(bound.Snapshot);
        }
        private void OnDisable() { if (bound != null) bound.StateChanged -= Refresh; bound = null; }
        private void Refresh(QuestSnapshot snapshot)
        {
            if (snapshot == null || artifact == null) return;
            string chosen = bound.GetChoiceId(artifact.Id);
            if (initialized && chosen == appliedId) return;
            initialized = true; appliedId = chosen;
            foreach (GameObject item in unresolvedObjects) if (item != null) item.SetActive(chosen == null);
            foreach (Branch branch in branches)
                if (branch != null && branch.objects != null)
                    foreach (GameObject item in branch.objects)
                        if (item != null) item.SetActive(!string.IsNullOrEmpty(chosen) && branch.choiceId == chosen);
            ChoiceDefinition choice = artifact.Definition != null ? artifact.Definition.FindChoice(chosen) : null;
            onConsequenceText.Invoke(choice != null ? choice.ConsequenceText : string.Empty);
        }
    }
}
