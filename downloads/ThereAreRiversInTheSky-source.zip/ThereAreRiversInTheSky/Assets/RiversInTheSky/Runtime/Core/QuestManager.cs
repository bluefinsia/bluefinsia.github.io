using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>
    /// Scene-owned quest service. Reference explicitly from other systems; no global singleton or
    /// scene search is needed. Save restoration emits state, never the player's live-choice event.
    /// </summary>
    [DefaultExecutionOrder(-200)]
    [DisallowMultipleComponent]
    public sealed class QuestManager : MonoBehaviour
    {
        [SerializeField] private ArtifactDefinition[] definitions = Array.Empty<ArtifactDefinition>();
        [SerializeField, Min(.1f)] private float poolFillDuration = 8f;
        [SerializeField] private bool loadOnAwake = true;
        [SerializeField] private bool autoSave = true;
        [SerializeField] private string saveFileName = "rivers-quest.json";

        private readonly Dictionary<ArtifactId, ArtifactDefinition> catalog = new Dictionary<ArtifactId, ArtifactDefinition>();
        private readonly List<ArtifactDefinition> generatedDefinitions = new List<ArtifactDefinition>();
        private QuestState state;
        private bool publishing;
        private bool persistenceAllowed = true;
        private float nextPoolSaveTime;

        public QuestSnapshot Snapshot { get; private set; }
        public event Action<QuestSnapshot> StateChanged;
        public event Action<ChoiceOutcome> ChoiceCommitted;
        public event Action FinalMemoryUnlocked;

        private string SavePath => Path.Combine(Application.persistentDataPath,
            string.IsNullOrWhiteSpace(saveFileName) ? "rivers-quest.json" : Path.GetFileName(saveFileName));

        private void Awake()
        {
            BuildCatalog();
            state = new QuestState(catalog);
            if (loadOnAwake) Load();
            Snapshot = state.Snapshot;
        }

        // Initial scene consumers may subscribe in OnEnable and always also read Snapshot there.
        private void Start() => PublishState();

        private void Update()
        {
            if (!state.AdvancePool(Time.deltaTime, poolFillDuration, out bool unlocked)) return;
            Snapshot = state.Snapshot;
            if (autoSave && (unlocked || Time.unscaledTime >= nextPoolSaveTime))
            { Save(); nextPoolSaveTime = Time.unscaledTime + 1f; }
            PublishState();
            if (unlocked) InvokeSafely(FinalMemoryUnlocked);
        }

        public ArtifactDefinition GetDefinition(ArtifactId id) => catalog.TryGetValue(id, out ArtifactDefinition definition) ? definition : null;
        public bool IsResolved(ArtifactId id) => state != null && state.IsResolved(id);
        public bool IsAvailable(ArtifactId id) => state != null && state.IsAvailable(id);
        public string GetChoiceId(ArtifactId id) => state?.GetChoiceId(id);

        public bool TryChoose(ArtifactId id, string choiceId, out string error)
        {
            if (state == null || publishing) { error = "The quest service is not ready for a new interaction."; return false; }
            if (!state.TryChoose(id, choiceId, out ChoiceOutcome outcome, out error)) return false;
            Snapshot = state.Snapshot;
            if (autoSave) Save();
            PublishState();
            // Narrative, one-shot sounds and haptics subscribe here, not to state reconstruction.
            publishing = true;
            try { InvokeSafely(ChoiceCommitted, outcome); }
            finally { publishing = false; }
            return true;
        }

        public bool TryConnectChannel(WaterChannel channel, out string error)
        {
            if (state == null || publishing) { error = "The quest service is not ready for a new interaction."; return false; }
            if (!state.TryConnectChannel(channel, out error)) return false;
            Snapshot = state.Snapshot;
            if (autoSave) Save();
            PublishState();
            return true;
        }

        public void Save()
        {
            if (state == null || !persistenceAllowed) return;
            string path = SavePath;
            string temporary = path + ".tmp";
            string backup = path + ".bak";
            try
            {
                Directory.CreateDirectory(Application.persistentDataPath);
                File.WriteAllText(temporary, JsonUtility.ToJson(state.Export(), true));
                if (!File.Exists(path)) File.Move(temporary, path);
                else
                {
                    try { File.Replace(temporary, path, backup); }
                    catch (PlatformNotSupportedException)
                    {
                        // Preserve the previous state even on platforms without atomic replacement.
                        File.Copy(path, backup, true);
                        File.Copy(temporary, path, true);
                        File.Delete(temporary);
                    }
                }
            }
            catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException || exception is ArgumentException)
            { Debug.LogError($"Quest save failed: {exception.Message}", this); }
        }

        private void Load()
        {
            string path = SavePath;
            foreach (string candidate in new[] { path, path + ".bak" })
            {
                if (!File.Exists(candidate)) continue;
                try
                {
                    QuestSaveData data = JsonUtility.FromJson<QuestSaveData>(File.ReadAllText(candidate));
                    if (data != null && data.version > 1)
                    {
                        persistenceAllowed = false;
                        Debug.LogError("This save belongs to a newer game version; writes are disabled to preserve it.", this);
                        return;
                    }
                    state.Restore(data);
                    return;
                }
                catch (Exception exception) when (exception is IOException || exception is InvalidDataException ||
                    exception is UnauthorizedAccessException || exception is ArgumentException)
                { Debug.LogWarning($"Could not load {Path.GetFileName(candidate)}: {exception.Message}", this); }
            }
        }

        private void BuildCatalog()
        {
            if (definitions != null)
                foreach (ArtifactDefinition definition in definitions)
                {
                    if (definition == null) continue;
                    if (!definition.Validate(out string error)) { Debug.LogError(error, definition); continue; }
                    if (!catalog.TryAdd(definition.Id, definition))
                        Debug.LogError($"Duplicate artifact ID {definition.Id}; the first definition is used.", definition);
                }
            foreach (ArtifactId id in Enum.GetValues(typeof(ArtifactId)))
                if (!catalog.ContainsKey(id))
                {
                    ArtifactDefinition generated = ArtifactDefinition.CreateDefault(id);
                    generated.hideFlags = HideFlags.HideAndDontSave;
                    generatedDefinitions.Add(generated);
                    catalog.Add(id, generated);
                }
        }

        private void PublishState()
        {
            publishing = true;
            try { InvokeSafely(StateChanged, Snapshot); }
            finally { publishing = false; }
        }

        // A broken scene listener must not prevent other listeners from observing committed state.
        private void InvokeSafely<T>(Action<T> handlers, T value)
        {
            if (handlers == null) return;
            foreach (Action<T> handler in handlers.GetInvocationList())
                try { handler(value); } catch (Exception exception) { Debug.LogException(exception, this); }
        }
        private void InvokeSafely(Action handlers)
        {
            if (handlers == null) return;
            foreach (Action handler in handlers.GetInvocationList())
                try { handler(); } catch (Exception exception) { Debug.LogException(exception, this); }
        }

        private void OnApplicationPause(bool paused) { if (paused && autoSave) Save(); }
        private void OnDisable() { if (autoSave) Save(); }
        private void OnDestroy()
        {
            foreach (ArtifactDefinition generated in generatedDefinitions)
                if (generated != null) Destroy(generated);
        }
    }
}
