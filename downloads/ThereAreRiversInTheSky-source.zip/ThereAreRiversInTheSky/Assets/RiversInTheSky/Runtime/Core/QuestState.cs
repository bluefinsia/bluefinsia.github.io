using System;
using System.Collections.Generic;
using System.IO;

namespace RiversInTheSky
{
    public sealed class ChoiceOutcome
    {
        public ArtifactId Artifact { get; }
        public ChoiceDefinition Choice { get; }
        public IsoAct Act { get; }
        public ChoiceOutcome(ArtifactId artifact, ChoiceDefinition choice, IsoAct act)
        { Artifact = artifact; Choice = choice; Act = act; }
    }

    /// <summary>Immutable event payload: listeners cannot change the quest underneath other listeners.</summary>
    public sealed class QuestSnapshot
    {
        public int ResolvedCount { get; }
        public int CleansedCount { get; }
        public WaterChannel ConnectedChannels { get; }
        public float PoolFill01 { get; }
        public bool FinalMemoryUnlocked { get; }
        public IsoAct Act { get; }
        public int Habitat { get; }
        public int Pollution { get; }
        public int Toxicity { get; }
        public int FloodRisk { get; }
        public int Nutrients { get; }

        internal QuestSnapshot(int resolved, int cleansed, WaterChannel channels, float fill,
            int habitat, int pollution, int toxicity, int floodRisk, int nutrients)
        {
            FinalMemoryUnlocked = fill >= 1f;
            ResolvedCount = resolved + (FinalMemoryUnlocked ? 1 : 0);
            CleansedCount = cleansed + (FinalMemoryUnlocked ? 1 : 0);
            ConnectedChannels = channels;
            PoolFill01 = fill;
            Act = resolved < 2 ? IsoAct.AnalyticalCurious : resolved < 4
                ? IsoAct.QuestionAndLearn : IsoAct.UnderstandingEmpathetic;
            Habitat = habitat; Pollution = pollution; Toxicity = toxicity;
            FloodRisk = floodRisk; Nutrients = nutrients;
        }
    }

    [Serializable]
    public sealed class QuestSaveData
    {
        public int version = 1;
        public List<ArtifactChoiceRecord> choices = new List<ArtifactChoiceRecord>();
        public int connectedChannels;
        public float poolFill;
    }

    [Serializable]
    public sealed class ArtifactChoiceRecord
    {
        public ArtifactId artifact;
        public string choiceId;
        public ArtifactChoiceRecord(ArtifactId artifact, string choiceId)
        { this.artifact = artifact; this.choiceId = choiceId; }
    }

    /// <summary>
    /// Deterministic domain model. Choices are the source of truth: counters and ecology are derived,
    /// so replaying saves or enabling scene objects cannot increment rewards twice.
    /// </summary>
    public sealed class QuestState
    {
        private readonly IReadOnlyDictionary<ArtifactId, ArtifactDefinition> catalog;
        private readonly Dictionary<ArtifactId, string> selected = new Dictionary<ArtifactId, string>();
        private WaterChannel channels;
        private float poolFill;

        public QuestState(IReadOnlyDictionary<ArtifactId, ArtifactDefinition> catalog)
        { this.catalog = catalog ?? throw new ArgumentNullException(nameof(catalog)); }

        public string GetChoiceId(ArtifactId id) => selected.TryGetValue(id, out string value) ? value : null;
        public bool IsResolved(ArtifactId id) => id == ArtifactId.FourYoungMaidens ? poolFill >= 1f : selected.ContainsKey(id);
        public bool IsAvailable(ArtifactId id) => catalog.ContainsKey(id) && !IsResolved(id) &&
            (id != ArtifactId.FourYoungMaidens || selected.Count == 4);

        public QuestSnapshot Snapshot
        {
            get
            {
                int clean = 0, habitat = 0, pollution = 0, toxicity = 0, flood = 0, nutrients = 0;
                foreach (KeyValuePair<ArtifactId, string> entry in selected)
                {
                    ChoiceDefinition choice = catalog[entry.Key].FindChoice(entry.Value);
                    if (choice.IsRestorative) clean++;
                    habitat += choice.HabitatDelta; pollution += choice.PollutionDelta;
                    toxicity += choice.ToxicityDelta; flood += choice.FloodRiskDelta; nutrients += choice.NutrientDelta;
                }
                return new QuestSnapshot(selected.Count, clean, channels, poolFill,
                    habitat, pollution, toxicity, flood, nutrients);
            }
        }

        public bool TryChoose(ArtifactId id, string choiceId, out ChoiceOutcome outcome, out string error)
        {
            outcome = null;
            if (!catalog.TryGetValue(id, out ArtifactDefinition definition))
            { error = "This artifact is not in the quest catalog."; return false; }
            if (id == ArtifactId.FourYoungMaidens)
            { error = "Reconnect the four channels to reveal this memory."; return false; }
            if (selected.ContainsKey(id))
            { error = "This artifact's choice has already been committed."; return false; }
            ChoiceDefinition choice = definition.FindChoice(choiceId);
            if (choice == null) { error = "Unknown choice for this artifact."; return false; }
            selected.Add(id, choiceId);
            outcome = new ChoiceOutcome(id, choice, Snapshot.Act);
            error = null;
            return true;
        }

        public bool TryConnectChannel(WaterChannel channel, out string error)
        {
            if (!TryGetPrerequisite(channel, out ArtifactId prerequisite))
            { error = "Choose exactly one of the four channels."; return false; }
            if ((channels & channel) != 0) { error = "This channel is already connected."; return false; }
            if (!IsResolved(prerequisite))
            { error = $"Resolve {catalog[prerequisite].DisplayName} before connecting this channel."; return false; }
            channels |= channel;
            error = null;
            return true;
        }

        // Call only from the manager's clock. No branch can permanently prevent final completion.
        public bool AdvancePool(float deltaTime, float fillDuration, out bool unlockedNow)
        {
            unlockedNow = false;
            if (channels != WaterChannel.All || selected.Count != 4 || poolFill >= 1f ||
                float.IsNaN(deltaTime) || float.IsInfinity(deltaTime) || deltaTime <= 0) return false;
            float duration = float.IsNaN(fillDuration) || float.IsInfinity(fillDuration) ? 8f : Math.Max(.01f, fillDuration);
            poolFill = Math.Min(1f, poolFill + deltaTime / duration);
            unlockedNow = poolFill >= 1f;
            return true;
        }

        public QuestSaveData Export()
        {
            var data = new QuestSaveData { connectedChannels = (int)channels, poolFill = poolFill };
            // Explicit order keeps saves and source control diffs stable across runtimes.
            for (int i = 0; i < 4; i++)
                if (selected.TryGetValue((ArtifactId)i, out string choice))
                    data.choices.Add(new ArtifactChoiceRecord((ArtifactId)i, choice));
            return data;
        }

        public void Restore(QuestSaveData data)
        {
            if (data == null || data.version != 1) throw new InvalidDataException("Unsupported quest save version.");
            selected.Clear();
            // Invalid IDs, removed authored choices, and duplicate records never create phantom progress.
            if (data.choices != null)
                foreach (ArtifactChoiceRecord record in data.choices)
                    if (record != null && record.artifact != ArtifactId.FourYoungMaidens &&
                        !selected.ContainsKey(record.artifact) && catalog.TryGetValue(record.artifact, out ArtifactDefinition def) &&
                        def.FindChoice(record.choiceId) != null) selected.Add(record.artifact, record.choiceId);
            channels = WaterChannel.None;
            foreach (WaterChannel channel in new[] { WaterChannel.Lotus, WaterChannel.Lantern, WaterChannel.Rice, WaterChannel.Water })
                if ((((WaterChannel)data.connectedChannels) & channel) != 0 &&
                    TryGetPrerequisite(channel, out ArtifactId prerequisite) && IsResolved(prerequisite)) channels |= channel;
            poolFill = channels == WaterChannel.All && selected.Count == 4 &&
                !float.IsNaN(data.poolFill) && !float.IsInfinity(data.poolFill) ? Math.Max(0, Math.Min(1, data.poolFill)) : 0;
        }

        private static bool TryGetPrerequisite(WaterChannel channel, out ArtifactId prerequisite)
        {
            switch (channel)
            {
                case WaterChannel.Lotus: prerequisite = ArtifactId.Lotus; return true;
                case WaterChannel.Lantern: prerequisite = ArtifactId.Lamplight; return true;
                case WaterChannel.Rice: prerequisite = ArtifactId.RiceField; return true;
                case WaterChannel.Water: prerequisite = ArtifactId.Pagoda; return true;
                default: prerequisite = default; return false;
            }
        }
    }
}
