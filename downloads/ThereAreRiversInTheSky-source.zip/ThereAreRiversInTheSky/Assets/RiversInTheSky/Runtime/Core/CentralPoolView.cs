using UnityEngine;
using UnityEngine.Events;

namespace RiversInTheSky
{
    /// <summary>Drive a separate visual water surface; keep this listener outside the final-memory root.</summary>
    public sealed class CentralPoolView : MonoBehaviour
    {
        [SerializeField] private QuestManager quests;
        [SerializeField] private Transform waterSurface;
        [SerializeField] private float emptyLocalY;
        [SerializeField] private float fullLocalY = 1f;
        [SerializeField] private GameObject finalMemoryRoot;
        [SerializeField] private UnityEvent<float> onFillChanged = new UnityEvent<float>();

        private void OnEnable()
        {
            if (quests == null) return;
            quests.StateChanged += Refresh;
            Refresh(quests.Snapshot);
        }
        private void OnDisable() { if (quests != null) quests.StateChanged -= Refresh; }
        private void Refresh(QuestSnapshot snapshot)
        {
            if (snapshot == null) return;
            if (waterSurface != null)
            {
                Vector3 position = waterSurface.localPosition;
                position.y = Mathf.Lerp(emptyLocalY, fullLocalY, snapshot.PoolFill01);
                waterSurface.localPosition = position;
            }
            if (finalMemoryRoot != null && finalMemoryRoot != gameObject)
                finalMemoryRoot.SetActive(snapshot.FinalMemoryUnlocked);
            onFillChanged.Invoke(snapshot.PoolFill01);
        }
    }
}
