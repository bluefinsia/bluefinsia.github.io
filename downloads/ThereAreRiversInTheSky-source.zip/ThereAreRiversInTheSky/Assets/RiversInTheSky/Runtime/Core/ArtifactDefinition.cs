using System;
using System.Collections.Generic;
using UnityEngine;

namespace RiversInTheSky
{
    public enum ArtifactId { Pagoda, Lotus, Lamplight, RiceField, FourYoungMaidens }

    [Flags]
    public enum WaterChannel { None = 0, Lotus = 1, Lantern = 2, Rice = 4, Water = 8, All = 15 }

    public enum IsoAct { AnalyticalCurious, QuestionAndLearn, UnderstandingEmpathetic }

    /// <summary>Authored consequences, never mutable runtime progress. Deltas are illustrative game units.</summary>
    [Serializable]
    public sealed class ChoiceDefinition
    {
        [SerializeField] private string id;
        [SerializeField] private string label;
        [SerializeField, TextArea(2, 5)] private string consequenceText;
        [SerializeField] private bool isRestorative;
        [SerializeField] private int habitatDelta;
        [SerializeField] private int pollutionDelta;
        [SerializeField] private int toxicityDelta;
        [SerializeField] private int floodRiskDelta;
        [SerializeField] private int nutrientDelta;

        public string Id => id;
        public string Label => label;
        public string ConsequenceText => consequenceText;
        public bool IsRestorative => isRestorative;
        public int HabitatDelta => habitatDelta;
        public int PollutionDelta => pollutionDelta;
        public int ToxicityDelta => toxicityDelta;
        public int FloodRiskDelta => floodRiskDelta;
        public int NutrientDelta => nutrientDelta;

        public ChoiceDefinition(string id, string label, string consequenceText, bool restorative,
            int habitat = 0, int pollution = 0, int toxicity = 0, int floodRisk = 0, int nutrients = 0)
        {
            this.id = id;
            this.label = label;
            this.consequenceText = consequenceText;
            isRestorative = restorative;
            habitatDelta = habitat;
            pollutionDelta = pollution;
            toxicityDelta = toxicity;
            floodRiskDelta = floodRisk;
            nutrientDelta = nutrients;
        }
    }

    [CreateAssetMenu(menuName = "Rivers in the Sky/Artifact Definition")]
    public sealed class ArtifactDefinition : ScriptableObject
    {
        [SerializeField] private ArtifactId id;
        [SerializeField] private string displayName;
        [SerializeField, TextArea(2, 6)] private string description;
        [SerializeField] private ChoiceDefinition[] choices = Array.Empty<ChoiceDefinition>();

        public ArtifactId Id => id;
        public string DisplayName => displayName;
        public string Description => description;
        public IReadOnlyList<ChoiceDefinition> Choices => Array.AsReadOnly(choices ?? Array.Empty<ChoiceDefinition>());

        // Used by the editor bootstrap and runtime fallback catalog; choice IDs are stable save keys.
        public void Initialize(ArtifactId artifact, string title, string body, params ChoiceDefinition[] options)
        {
            id = artifact;
            displayName = title;
            description = body;
            choices = options == null ? Array.Empty<ChoiceDefinition>() : (ChoiceDefinition[])options.Clone();
        }

        public ChoiceDefinition FindChoice(string choiceId)
        {
            if (choices == null) return null;
            foreach (ChoiceDefinition choice in choices)
                if (choice != null && string.Equals(choice.Id, choiceId, StringComparison.Ordinal)) return choice;
            return null;
        }

        public bool Validate(out string error)
        {
            if (!Enum.IsDefined(typeof(ArtifactId), id) || string.IsNullOrWhiteSpace(displayName))
            { error = "Artifact needs a valid ID and display name."; return false; }
            if (id == ArtifactId.FourYoungMaidens)
            {
                error = null;
                return true; // Its interactions are the four channel valves, not a binary choice.
            }
            var seen = new HashSet<string>(StringComparer.Ordinal);
            if (choices == null || choices.Length < 2)
            { error = $"{displayName} requires at least two choices."; return false; }
            foreach (ChoiceDefinition choice in choices)
            {
                if (choice == null || string.IsNullOrWhiteSpace(choice.Id) ||
                    string.IsNullOrWhiteSpace(choice.Label) || !seen.Add(choice.Id))
                { error = $"{displayName} has a blank or duplicate choice ID/label."; return false; }
            }
            error = null;
            return true;
        }

        /// <summary>Complete playable defaults. Replace with assets to author/localize the narrative.</summary>
        public static ArtifactDefinition CreateDefault(ArtifactId artifact)
        {
            var result = CreateInstance<ArtifactDefinition>();
            switch (artifact)
            {
                case ArtifactId.Pagoda:
                    result.Initialize(artifact, "The Pagoda", "A flooded threshold shelters a living wetland.",
                        new ChoiceDefinition("force_entrance", "Force Entrance (Habitat Damage)",
                            "The stone door opens, but the nesting reeds are crushed.", false, habitat: -2),
                        new ChoiceDefinition("restore_passage", "Restore Water Passage (Connect Wetland)",
                            "Water returns through the passage and reconnects the wetland.", true, habitat: 2));
                    break;
                case ArtifactId.Lotus:
                    result.Initialize(artifact, "The Lotus", "Waste drifts through a luminous lotus pond.",
                        new ChoiceDefinition("remove_rubbish", "Remove Visible Rubbish",
                            "The surface clears. The upstream outlet continues to bring waste.", false, pollution: -1),
                        new ChoiceDefinition("stop_source", "Stop Waste at Source",
                            "The waste outlet closes. The pond can recover beyond its visible surface.", true, pollution: -3));
                    break;
                case ArtifactId.Lamplight:
                    result.Initialize(artifact, "The Lamplight", "An old lantern waits for energy.",
                        new ChoiceDefinition("old_cell", "Use Old Energy Cell (Toxic Leakage)",
                            "The lantern glows; the damaged cell leaks into the water below.", false, toxicity: 2),
                        new ChoiceDefinition("sunlight", "Harness Sunlight (Sustainable Illumination)",
                            "A sun collector stores enough light to keep the lantern glowing after twilight.", true));
                    break;
                case ArtifactId.RiceField:
                    result.Initialize(artifact, "The Rice Field", "The terraces need water, with consequences downstream.",
                        new ChoiceDefinition("direct_gate", "Open Direct Irrigation Gate (Flood Risk)",
                            "Nutrient-rich water reaches the field quickly; downstream flood risk rises.", false,
                            floodRisk: 2, nutrients: 2),
                        new ChoiceDefinition("wetland_route", "Redirect Through Wetland (Reduced Nutrients)",
                            "The wetland slows the flow and reduces flood risk, while retaining some nutrients.", true,
                            habitat: 1, floodRisk: -1, nutrients: -1));
                    break;
                case ArtifactId.FourYoungMaidens:
                    result.Initialize(artifact, "The Four Young Maidens",
                        "Reconnect Lotus, Lantern, Rice, and Water. Their joined current fills the central pool.");
                    break;
                default: DestroyImmediate(result); throw new ArgumentOutOfRangeException(nameof(artifact));
            }
            result.name = artifact + " Definition";
            return result;
        }
    }
}
