using UnityEngine;
using UnityEngine.Events;

namespace RiversInTheSky
{
    /// <summary>Attach beside the artifact's collider; ArtifactInteractor opens its choice UI.</summary>
    [DisallowMultipleComponent]
    public sealed class ArtifactNode : MonoBehaviour
    {
        [SerializeField] private QuestManager quests;
        [SerializeField] private ArtifactId id;
        [SerializeField] private UnityEvent<bool> onAvailabilityChanged = new UnityEvent<bool>();
        [SerializeField] private UnityEvent<bool> onResolvedChanged = new UnityEvent<bool>();
        private bool initialized, lastAvailable, lastResolved;

        public ArtifactId Id => id;
        public ArtifactDefinition Definition => quests != null ? quests.GetDefinition(id) : null;
        public QuestManager Quests => quests;
        public bool IsAvailable => quests != null && quests.IsAvailable(id);
        public bool IsResolved => quests != null && quests.IsResolved(id);

        public void Configure(QuestManager manager, ArtifactId artifact)
        {
            if (isActiveAndEnabled && quests != null) quests.StateChanged -= Refresh;
            quests = manager; id = artifact; initialized = false;
            if (isActiveAndEnabled && quests != null) { quests.StateChanged += Refresh; Refresh(quests.Snapshot); }
        }

        private void OnEnable()
        {
            if (quests == null) return;
            quests.StateChanged += Refresh;
            Refresh(quests.Snapshot);
        }
        private void OnDisable() { if (quests != null) quests.StateChanged -= Refresh; }
        private void Refresh(QuestSnapshot snapshot)
        {
            if (snapshot == null) return;
            bool available = IsAvailable, resolved = IsResolved;
            if (!initialized || available != lastAvailable) onAvailabilityChanged.Invoke(available);
            if (!initialized || resolved != lastResolved) onResolvedChanged.Invoke(resolved);
            lastAvailable = available; lastResolved = resolved; initialized = true;
        }
    }
}
