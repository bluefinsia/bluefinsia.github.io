using UnityEngine;
using UnityEngine.UI;

namespace RiversInTheSky
{
    /// <summary>Connects ISO's queued dialogue to an existing world-space uGUI text panel.</summary>
    [DisallowMultipleComponent]
    public sealed class IsoSubtitlePresenter : MonoBehaviour
    {
        [SerializeField] private IsoCompanion iso;
        [SerializeField] private Text subtitle;
        [Tooltip("Optional CanvasGroup; keep the presenter enabled while the text is hidden.")]
        [SerializeField] private CanvasGroup visibility;

        private void OnEnable()
        {
            if (iso != null) iso.SubtitleChanged += Present;
            Present(iso != null ? iso.CurrentSubtitle : string.Empty);
        }

        private void OnDisable()
        {
            if (iso != null) iso.SubtitleChanged -= Present;
        }

        private void Present(string message)
        {
            if (subtitle != null) subtitle.text = message;
            if (visibility == null) return;
            visibility.alpha = string.IsNullOrEmpty(message) ? 0f : 1f;
            visibility.interactable = false;
            visibility.blocksRaycasts = false;
        }
    }
}
