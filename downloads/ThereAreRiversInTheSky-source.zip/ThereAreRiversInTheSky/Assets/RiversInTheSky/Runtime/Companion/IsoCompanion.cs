using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace RiversInTheSky
{
    /// <summary>
    /// A flying companion driven by authoritative quest state. Restoration updates its act,
    /// but only live decisions enqueue speech, so loading never repeats a conversation.
    /// This component moves ISO only; it never changes the player or view camera pose.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class IsoCompanion : MonoBehaviour
    {
        [Serializable] public sealed class SubtitleEvent : UnityEvent<string> { }
        [Serializable] public sealed class ActEvent : UnityEvent<IsoAct> { }

        [Serializable]
        private sealed class DialogueOverride
        {
            [SerializeField] internal ArtifactId artifact;
            [SerializeField] internal bool restorative;
            [SerializeField] internal IsoAct act;
            [SerializeField, TextArea(2, 6)] internal string subtitle;
            [SerializeField] internal AudioClip voice;
            [SerializeField, Min(0.5f)] internal float minimumSeconds = 4f;
        }

        [Header("Explicit scene references")]
        [SerializeField] private QuestManager quests;
        [SerializeField] private Transform playerHead;
        [Tooltip("Optional spatial AudioSource on ISO, exclusively owned by this component.")]
        [SerializeField] private AudioSource voiceSource;

        [Header("Head-relative position; world gravity remains upright")]
        [SerializeField] private Vector3 localOffset = new Vector3(0.8f, -0.1f, 1.3f);
        [SerializeField] private Vector3 axisSmoothTimes = new Vector3(0.45f, 0.65f, 0.45f);
        [SerializeField, Min(0.1f)] private float maximumSpeed = 3f;
        [SerializeField, Min(0.1f)] private float teleportThreshold = 4f;
        [SerializeField, Min(0f)] private float bobAmplitude = 0.06f;
        [SerializeField, Min(0f)] private float bobFrequency = 0.45f;
        [SerializeField, Min(0f)] private float rotationSharpness = 5f;

        [Header("Optional obstacle avoidance")]
        [Tooltip("Static environment layers only. Exclude player, ISO and trigger volumes.")]
        [SerializeField] private LayerMask obstacleMask;
        [SerializeField, Min(0.01f)] private float collisionRadius = 0.12f;
        [SerializeField, Min(0f)] private float wallMargin = 0.03f;

        [Header("Dialogue; overrides replace the included original English lines")]
        [SerializeField] private DialogueOverride[] dialogueOverrides = Array.Empty<DialogueOverride>();
        [SerializeField, TextArea(2, 6)] private string finalMemorySubtitle =
            "Four streams, one home. I thought these waters were something to take. Now I understand why you stayed to care for them.";
        [SerializeField] private AudioClip finalMemoryVoice;
        [SerializeField, Min(0.5f)] private float secondsPerLine = 5f;
        [SerializeField] private SubtitleEvent onSubtitleChanged = new SubtitleEvent();
        [SerializeField] private ActEvent onActChanged = new ActEvent();

        public IsoAct Act { get; private set; } = IsoAct.AnalyticalCurious;
        public string CurrentSubtitle { get; private set; } = string.Empty;
        public event Action<string> SubtitleChanged;
        public event Action<IsoAct> ActChanged;

        private readonly Queue<Line> lines = new Queue<Line>();
        private QuestManager subscribedQuests;
        private Coroutine speech;
        private Vector3 dampingVelocity;
        private Vector3 previousHeadPosition;
        private Vector3 lastFlatForward = Vector3.forward;
        private bool hasTrackedTarget;

        private readonly struct Line
        {
            internal readonly string Text;
            internal readonly AudioClip Voice;
            internal readonly float MinimumSeconds;
            internal Line(string text, AudioClip voice, float seconds)
            { Text = text; Voice = voice; MinimumSeconds = seconds; }
        }

        /// <summary>May be called by a scene bootstrapper before or after enabling ISO.</summary>
        public void Configure(QuestManager manager, Transform head)
        {
            Unsubscribe();
            quests = manager;
            playerHead = head;
            hasTrackedTarget = false;
            if (isActiveAndEnabled) Subscribe();
        }

        private void OnEnable()
        {
            hasTrackedTarget = false;
            if (voiceSource != null)
            {
                voiceSource.playOnAwake = false;
                voiceSource.loop = false;
            }
            Subscribe();
        }

        private void OnDisable()
        {
            Unsubscribe();
            if (speech != null) StopCoroutine(speech);
            speech = null;
            lines.Clear();
            if (voiceSource != null) voiceSource.Stop();
            SetSubtitle(string.Empty);
        }

        private void Subscribe()
        {
            if (quests == null || subscribedQuests == quests) return;
            subscribedQuests = quests;
            subscribedQuests.StateChanged += RestoreAct;
            subscribedQuests.ChoiceCommitted += ReactToChoice;
            subscribedQuests.FinalMemoryUnlocked += ReactToFinalMemory;
            RestoreAct(subscribedQuests.Snapshot);
        }

        private void Unsubscribe()
        {
            if (subscribedQuests == null) return;
            subscribedQuests.StateChanged -= RestoreAct;
            subscribedQuests.ChoiceCommitted -= ReactToChoice;
            subscribedQuests.FinalMemoryUnlocked -= ReactToFinalMemory;
            subscribedQuests = null;
        }

        private void RestoreAct(QuestSnapshot state)
        {
            if (state == null || Act == state.Act) return;
            Act = state.Act;
            onActChanged.Invoke(Act);
            ActChanged?.Invoke(Act);
        }

        private void LateUpdate()
        {
            if (playerHead == null) return;
            float dt = Time.deltaTime;
            // A vertical gaze has no reliable yaw; preserve the last valid horizontal heading.
            Vector3 flatForward = Vector3.ProjectOnPlane(playerHead.forward, Vector3.up);
            if (flatForward.sqrMagnitude > 0.001f) lastFlatForward = flatForward.normalized;
            Vector3 right = Vector3.Cross(Vector3.up, lastFlatForward);
            Vector3 desired = playerHead.position + right * localOffset.x +
                Vector3.up * localOffset.y + lastFlatForward * localOffset.z;
            desired.y += Mathf.Sin(Time.time * bobFrequency * Mathf.PI * 2f) * bobAmplitude;
            desired = ConstrainSegment(playerHead.position, desired);

            bool teleported = hasTrackedTarget &&
                (playerHead.position - previousHeadPosition).sqrMagnitude > teleportThreshold * teleportThreshold;
            if (!hasTrackedTarget || teleported)
            {
                // Do not fly rapidly across the map after teleport locomotion.
                transform.position = desired;
                dampingVelocity = Vector3.zero;
            }
            else if (dt > 0f)
            {
                Vector3 current = transform.position;
                Vector3 next = new Vector3(
                    Mathf.SmoothDamp(current.x, desired.x, ref dampingVelocity.x,
                        Mathf.Max(0.01f, axisSmoothTimes.x), maximumSpeed, dt),
                    Mathf.SmoothDamp(current.y, desired.y, ref dampingVelocity.y,
                        Mathf.Max(0.01f, axisSmoothTimes.y), maximumSpeed, dt),
                    Mathf.SmoothDamp(current.z, desired.z, ref dampingVelocity.z,
                        Mathf.Max(0.01f, axisSmoothTimes.z), maximumSpeed, dt));
                Vector3 constrained = ConstrainSegment(current, next);
                if ((constrained - next).sqrMagnitude > 0.000001f) dampingVelocity = Vector3.zero;
                transform.position = constrained;
            }

            Vector3 towardPlayer = playerHead.position - transform.position;
            if (towardPlayer.sqrMagnitude > 0.0001f)
                transform.rotation = Quaternion.Slerp(transform.rotation,
                    Quaternion.LookRotation(towardPlayer, Vector3.up),
                    1f - Mathf.Exp(-rotationSharpness * dt));
            previousHeadPosition = playerHead.position;
            hasTrackedTarget = true;
        }

        private Vector3 ConstrainSegment(Vector3 start, Vector3 end)
        {
            Vector3 delta = end - start;
            float distance = delta.magnitude;
            if (obstacleMask.value != 0 && distance > 0.0001f &&
                Physics.SphereCast(start, collisionRadius, delta / distance, out RaycastHit hit,
                    distance, obstacleMask, QueryTriggerInteraction.Ignore))
                return start + delta / distance * Mathf.Max(0f, hit.distance - wallMargin);
            return end;
        }

        private void ReactToChoice(ChoiceOutcome outcome)
        {
            // Act is derived from committed state, never advanced by the animation or dialogue queue.
            if (subscribedQuests != null) RestoreAct(subscribedQuests.Snapshot);
            foreach (DialogueOverride entry in dialogueOverrides)
            {
                if (entry == null || entry.artifact != outcome.Artifact ||
                    entry.restorative != outcome.Choice.IsRestorative || entry.act != outcome.Act) continue;
                string text = string.IsNullOrWhiteSpace(entry.subtitle)
                    ? DefaultLine(outcome.Artifact, outcome.Choice.IsRestorative, outcome.Act) : entry.subtitle;
                Enqueue(new Line(text, entry.voice, entry.minimumSeconds));
                return;
            }
            Enqueue(new Line(DefaultLine(outcome.Artifact, outcome.Choice.IsRestorative, outcome.Act), null, secondsPerLine));
        }

        private void ReactToFinalMemory()
        {
            Enqueue(new Line(finalMemorySubtitle, finalMemoryVoice, Mathf.Max(secondsPerLine, 7f)));
        }

        private void Enqueue(Line line)
        {
            if (!isActiveAndEnabled) return;
            lines.Enqueue(line);
            if (speech == null) speech = StartCoroutine(Speak());
        }

        private IEnumerator Speak()
        {
            while (lines.Count > 0)
            {
                Line line = lines.Dequeue();
                SetSubtitle(line.Text);
                float duration = Mathf.Max(0.5f, line.MinimumSeconds);
                if (voiceSource != null && line.Voice != null)
                {
                    voiceSource.clip = line.Voice;
                    voiceSource.Play();
                    duration = Mathf.Max(duration, line.Voice.length / Mathf.Max(0.01f, Mathf.Abs(voiceSource.pitch)));
                }
                // Unscaled wait avoids losing a subtitle when a comfort/menu pause stops world time.
                yield return new WaitForSecondsRealtime(duration);
                if (voiceSource != null) voiceSource.Stop();
                SetSubtitle(string.Empty);
                if (lines.Count > 0) yield return new WaitForSecondsRealtime(0.2f);
            }
            speech = null;
        }

        private void SetSubtitle(string text)
        {
            CurrentSubtitle = text ?? string.Empty;
            onSubtitleChanged.Invoke(CurrentSubtitle);
            SubtitleChanged?.Invoke(CurrentSubtitle);
        }

        private static string DefaultLine(ArtifactId artifact, bool restorative, IsoAct act)
        {
            // Artifacts may be visited in any order. The act selects ISO's interpretation,
            // while the branch selects the observed consequence; location never advances its arc.
            switch (artifact)
            {
                case ArtifactId.Pagoda:
                    return restorative
                        ? ForAct(act,
                            "The passage is restored. The connected wetland should improve water access. I will map its capacity.",
                            "The wetland is connected again. I wonder how many lives depend on this passage staying open.",
                            "You reopened the water's path. The wetland and pagoda can share it again. This is how we care for a living home.")
                        : ForAct(act,
                            "The entrance is open. Habitat damage recorded. I need to include that cost in the access calculation.",
                            "We opened the entrance, but broke a habitat. What lived there before we arrived? I am concerned about what we displaced.",
                            "We can enter now, and a shelter has been damaged. This place is home to others too. I want us to remember that loss.");
                case ArtifactId.Lotus:
                    return restorative
                        ? ForAct(act,
                            "The waste source is stopped. That should reduce repeated cleanup work and preserve the pond's usable water.",
                            "The waste has stopped arriving. Looking upstream helped us protect what was struggling here. I am learning to ask where harm begins.",
                            "The pond can recover without more waste arriving. The lotus has a chance to flourish in its own home. I am glad we stayed to help.")
                        : ForAct(act,
                            "Visible rubbish removed. The upstream source remains active, so I predict another cleanup will be necessary.",
                            "The surface is clearer, but waste still comes downstream. Will the lotus keep struggling after we leave?",
                            "We cleared space around the lotus. Waste is still arriving, and this living pond needs lasting care. I will remember what remains upstream.");
                case ArtifactId.Lamplight:
                    return restorative
                        ? ForAct(act,
                            "Solar light is available. A renewable input should extend the lantern's operating life without consuming stored cells.",
                            "The lantern holds a little sunlight. The water stays free of a leaking cell. I am beginning to understand why you waited.",
                            "The lantern keeps a little of the sun, and the water beneath it stays safe. Its warmth belongs in this home.")
                        : ForAct(act,
                            "The old cell powers the lantern. Toxic leakage detected. Immediate energy yield carries a contamination cost.",
                            "The lantern is lit, but the old cell is leaking. What will that light cost the life in this water?",
                            "The light is warm, but the cell is leaking into a living home. I feel the cost reaching beyond the lantern.");
                case ArtifactId.RiceField:
                    return restorative
                        ? ForAct(act,
                            "The wetland reduces flood risk and nutrient delivery. I will record the tradeoff between water control and rice productivity.",
                            "The wetland slows the flood, though fewer nutrients reach the rice. How can we help the field without putting its neighbours at risk?",
                            "The wetland shelters the field from flooding. Fewer nutrients reach the rice, so it will need continuing care. A home asks us to keep listening.")
                        : ForAct(act,
                            "Direct irrigation is active. Water reaches the rice quickly, with an increased flood risk. Both outcomes belong in the model.",
                            "The field receives water directly, and the flood risk rises. I am starting to see how one useful flow can threaten another life.",
                            "The gate brings water and flood risk to the rice. These lives share one stream with us. I want us to care for everyone it reaches.");
                default:
                    return ForAct(act,
                        "Water connections recorded. I will compare their resource flows.",
                        "These connected waters hold consequences I am still learning to see.",
                        "These waters carry the choices we made. I will remember what they have taught us about home.");
            }
        }

        private static string ForAct(IsoAct act, string analytical, string questioning, string empathetic)
        {
            switch (act)
            {
                case IsoAct.QuestionAndLearn: return questioning;
                case IsoAct.UnderstandingEmpathetic: return empathetic;
                default: return analytical;
            }
        }
    }
}
