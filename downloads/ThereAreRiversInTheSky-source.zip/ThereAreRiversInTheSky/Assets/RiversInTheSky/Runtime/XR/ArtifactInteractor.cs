using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

namespace RiversInTheSky
{
    /// <summary>A ray or direct XRI selection opens the shared world-space choice panel.</summary>
    [RequireComponent(typeof(XRSimpleInteractable), typeof(ArtifactNode))]
    public sealed class ArtifactInteractor : MonoBehaviour
    {
        [SerializeField] private ArtifactNode node;
        [SerializeField] private ArtifactChoicePanel choicePanel;
        [SerializeField] private Transform playerHead;
        [SerializeField, Min(0.1f)] private float interactionDistance = 4f;
        private XRSimpleInteractable interactable;
        public bool IsInRange => playerHead != null &&
            (playerHead.position - transform.position).sqrMagnitude <= interactionDistance * interactionDistance;

        private void Awake()
        {
            interactable = GetComponent<XRSimpleInteractable>();
            if (node == null) node = GetComponent<ArtifactNode>();
            if (playerHead == null && Camera.main != null) playerHead = Camera.main.transform;
        }
        private void OnEnable()
        {
            if (interactable == null) interactable = GetComponent<XRSimpleInteractable>();
            interactable.selectEntered.AddListener(OnSelected);
        }
        private void OnDisable()
        {
            if (interactable != null) interactable.selectEntered.RemoveListener(OnSelected);
            if (choicePanel != null) choicePanel.CloseIfOwner(this);
        }
        private void OnSelected(SelectEnterEventArgs args)
        {
            if (IsInRange && node != null && choicePanel != null) choicePanel.Open(node, this, playerHead);
        }
        public void Configure(ArtifactNode artifact, ArtifactChoicePanel panel, Transform head)
        { node = artifact; choicePanel = panel; playerHead = head; }
    }
}
