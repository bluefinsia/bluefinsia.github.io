using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Locomotion.Movement;
using UnityEngine.XR.Interaction.Toolkit.Locomotion.Turning;

namespace RiversInTheSky
{
    /// <summary>
    /// Changes comfort settings on XRI's collision-aware locomotion providers.
    /// InputActionManager must keep the referenced move, turn and snap-turn actions enabled.
    /// Disable Starter Assets ControllerInputActionManager components before Play: those sample
    /// components independently disable locomotion actions and would prevent mode switching here.
    /// This component owns provider enablement only; it never owns shared action-map lifetimes.
    /// </summary>
    public sealed class XRPlayerSettings : MonoBehaviour
    {
        public enum TurnMode { Snap, Continuous, Disabled }
        [SerializeField] private ContinuousMoveProvider moveProvider;
        [SerializeField] private SnapTurnProvider snapTurnProvider;
        [SerializeField] private ContinuousTurnProvider continuousTurnProvider;
        [SerializeField, Range(0.1f, 4f)] private float moveSpeed = 1.5f;
        [SerializeField] private TurnMode turnMode = TurnMode.Snap;
        [SerializeField, Range(15f, 90f)] private float snapDegrees = 30f;
        [SerializeField, Range(15f, 120f)] private float turnDegreesPerSecond = 45f;
        private bool locomotionAllowed = true;

        private void OnEnable() => Apply();
        public void SetTurnMode(int mode)
        {
            turnMode = (TurnMode)Mathf.Clamp(mode, 0, 2);
            Apply();
        }
        public void SetMoveSpeed(float metresPerSecond)
        {
            moveSpeed = Mathf.Clamp(metresPerSecond, 0.1f, 4f);
            Apply();
        }
        // Useful for seated story moments. Never disable the tracked camera or the XR Origin.
        public void SetLocomotionAllowed(bool allowed) { locomotionAllowed = allowed; Apply(); }
        private void Apply()
        {
            if (moveProvider != null) { moveProvider.moveSpeed = moveSpeed; moveProvider.enabled = locomotionAllowed; }
            if (snapTurnProvider != null)
            {
                snapTurnProvider.turnAmount = snapDegrees;
                snapTurnProvider.enabled = locomotionAllowed && turnMode == TurnMode.Snap;
            }
            if (continuousTurnProvider != null)
            {
                continuousTurnProvider.turnSpeed = turnDegreesPerSecond;
                continuousTurnProvider.enabled = locomotionAllowed && turnMode == TurnMode.Continuous;
            }
        }
    }
}
