using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace RiversInTheSky
{
    /// <summary>One persistent world-space canvas; listeners are created once for each displayed choice.</summary>
    public sealed class ArtifactChoicePanel : MonoBehaviour
    {
        [SerializeField] private GameObject panelRoot;
        [SerializeField] private Text title;
        [SerializeField] private Text description;
        [SerializeField] private Text status;
        [SerializeField] private Transform buttonContainer;
        [SerializeField] private Button buttonPrefab;
        [SerializeField, Min(0.5f)] private float viewingDistance = 1.5f;
        private readonly List<Button> buttons = new List<Button>();
        private ArtifactNode node;
        private ArtifactInteractor owner;
        private bool committing;

        private void Awake() { if (panelRoot != null) panelRoot.SetActive(false); }
        private void Update()
        {
            // A player cannot open a panel, walk to the other side of the level and commit remotely.
            if (owner != null && !owner.IsInRange) Close();
        }
        public void Open(ArtifactNode artifact, ArtifactInteractor source, Transform head)
        {
            if (artifact == null || artifact.Quests == null || head == null || source == null || !source.IsInRange) return;
            Close();
            node = artifact; owner = source;
            if (panelRoot == null || buttonPrefab == null || buttonContainer == null) { Close(); return; }
            panelRoot.SetActive(true);
            var horizontal = Vector3.ProjectOnPlane(head.forward, Vector3.up);
            if (horizontal.sqrMagnitude < 0.001f) horizontal = Vector3.forward;
            panelRoot.transform.position = head.position + horizontal.normalized * viewingDistance;
            // Canvas forward points away from the viewer; its front face is toward the camera.
            panelRoot.transform.rotation = Quaternion.LookRotation(horizontal.normalized, Vector3.up);
            var definition = artifact.Quests.GetDefinition(artifact.Id);
            if (definition == null) { Close(); return; }
            if (title != null) title.text = definition.DisplayName;
            if (description != null) description.text = definition.Description;
            if (status != null) status.text = artifact.Quests.IsResolved(artifact.Id)
                ? "This memory is already restored."
                : artifact.Id == ArtifactId.FourYoungMaidens ? "Reconnect the Lotus, Lantern, Rice and Water channels." : string.Empty;
            foreach (var choice in definition.Choices)
            {
                var capturedId = choice.Id; // Capture a stable value, never a mutable loop index.
                var button = Instantiate(buttonPrefab, buttonContainer);
                button.gameObject.SetActive(true);
                var label = button.GetComponentInChildren<Text>(true);
                if (label != null) label.text = choice.Label;
                button.interactable = !artifact.Quests.IsResolved(artifact.Id) && artifact.Quests.IsAvailable(artifact.Id);
                button.onClick.AddListener(() => Commit(capturedId));
                buttons.Add(button);
            }
        }
        private void Commit(string choiceId)
        {
            if (committing || node == null || owner == null || !owner.IsInRange) { Close(); return; }
            committing = true;
            foreach (var button in buttons) button.interactable = false;
            var accepted = node.Quests.TryChoose(node.Id, choiceId, out var error);
            committing = false;
            if (accepted) { Close(); return; }
            if (status != null) status.text = error;
            foreach (var button in buttons) button.interactable = node.Quests.IsAvailable(node.Id) && !node.Quests.IsResolved(node.Id);
        }
        public void CloseIfOwner(ArtifactInteractor source) { if (owner == source) Close(); }
        public void Close()
        {
            foreach (var button in buttons)
            {
                if (button == null) continue;
                button.onClick.RemoveAllListeners();
                button.gameObject.SetActive(false);
                Destroy(button.gameObject);
            }
            buttons.Clear(); owner = null; node = null; committing = false;
            if (panelRoot != null) panelRoot.SetActive(false);
        }
        private void OnDisable() => Close();
    }
}
