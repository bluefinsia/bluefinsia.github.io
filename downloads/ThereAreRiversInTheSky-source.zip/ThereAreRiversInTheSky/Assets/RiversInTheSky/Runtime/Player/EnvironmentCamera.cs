using System;
using System.IO;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;
using UnityEngine.Rendering;

namespace RiversInTheSky
{
    /// <summary>Photographs the closest-to-centre eligible memory with a clear line of sight.</summary>
    public sealed class EnvironmentCamera : MonoBehaviour
    {
        [SerializeField] private Transform viewfinder;
        [SerializeField] private JournalManager journal;
        [SerializeField] private InputActionReference shutterAction;
        [SerializeField, Min(0.1f)] private float maxDistance = 20f;
        [SerializeField, Range(1f, 80f)] private float framingHalfAngle = 25f;
        [SerializeField] private LayerMask visibilityMask = ~0;
        [SerializeField, Min(0f)] private float shutterCooldown = 0.5f;
        [Header("Optional image capture: a separate, disabled camera")]
        [SerializeField] private Camera captureCamera;
        [SerializeField, Range(128, 1024)] private int imageResolution = 512;
        [SerializeField] private UnityEvent<string> onPhotographed = new UnityEvent<string>();
        [SerializeField] private UnityEvent onNoNewMemory = new UnityEvent();
        private float nextShutterTime;
        private void Awake() { if (viewfinder == null && Camera.main != null) viewfinder = Camera.main.transform; }
        private void OnEnable()
        {
            // Optional external actions belong to their Input System owner; observe without changing map enablement.
            if (shutterAction != null && shutterAction.action != null) shutterAction.action.performed += OnShutter;
        }
        private void OnDisable()
        {
            if (shutterAction != null && shutterAction.action != null) shutterAction.action.performed -= OnShutter;
        }
        private void OnShutter(InputAction.CallbackContext context) => TryPhotograph();
        // UnityEvent's Inspector binds void methods; this also supports a diegetic shutter button.
        public void Photograph() => TryPhotograph();
        public bool TryPhotograph()
        {
            if (journal == null || viewfinder == null || Time.unscaledTime < nextShutterTime) return false;
            nextShutterTime = Time.unscaledTime + shutterCooldown;
            Photographable best = null;
            var bestAlignment = -1f;
            var nearest = float.PositiveInfinity;
            var minimumAlignment = Mathf.Cos(framingHalfAngle * Mathf.Deg2Rad);
            foreach (var target in Photographable.Active)
            {
                if (target == null || string.IsNullOrWhiteSpace(target.MemoryId) || journal.ContainsPhoto(target.MemoryId)) continue;
                var offset = target.FramingPosition - viewfinder.position;
                var distance = offset.magnitude;
                if (distance < 0.01f || distance > maxDistance) continue;
                var direction = offset / distance;
                var alignment = Vector3.Dot(viewfinder.forward, direction);
                if (alignment < minimumAlignment) continue;
                // The first blocker must be this target (including its child colliders), or there must be no blocker.
                if (Physics.Raycast(viewfinder.position, direction, out var hit, distance, visibilityMask, QueryTriggerInteraction.Ignore) &&
                    hit.collider.GetComponentInParent<Photographable>() != target) continue;
                if (alignment > bestAlignment || (Mathf.Approximately(alignment, bestAlignment) && distance < nearest))
                { best = target; bestAlignment = alignment; nearest = distance; }
            }
            if (best == null) { onNoNewMemory.Invoke(); return false; }
            var imageFileName = TryCaptureImage();
            var accepted = journal.TryRecordPhoto(new PhotoMemory
            {
                memoryId = best.MemoryId, displayName = best.DisplayName,
                playerPosition = viewfinder.position, playerRotation = viewfinder.rotation, relatedToArtifact = best.RelatedToArtifact,
                artifact = best.Artifact, imageFileName = imageFileName
            });
            if (accepted) onPhotographed.Invoke(best.MemoryId);
            return accepted;
        }
        private string TryCaptureImage()
        {
            if (captureCamera == null) return string.Empty;
            if (captureCamera.enabled || captureCamera.transform == viewfinder)
            {
                Debug.LogWarning("Photo capture needs a separate disabled Camera; metadata was still recorded.", this);
                return string.Empty;
            }
            RenderTexture renderTarget = null;
            Texture2D pixels = null;
            var oldTarget = captureCamera.targetTexture;
            var oldActive = RenderTexture.active;
            var oldPosition = captureCamera.transform.position;
            var oldRotation = captureCamera.transform.rotation;
            try
            {
                var size = Mathf.Clamp(imageResolution, 128, 1024);
                renderTarget = RenderTexture.GetTemporary(size, size, 24, RenderTextureFormat.ARGB32);
                captureCamera.transform.SetPositionAndRotation(viewfinder.position, viewfinder.rotation);
                captureCamera.targetTexture = renderTarget;
                // URP supports this explicit request; Camera.Render is not supported by every SRP version.
                if (GraphicsSettings.currentRenderPipeline != null)
                {
                    var request = new RenderPipeline.StandardRequest { destination = renderTarget };
                    if (!RenderPipeline.SupportsRenderRequest(captureCamera, request)) return string.Empty;
                    RenderPipeline.SubmitRenderRequest(captureCamera, request);
                }
                else captureCamera.Render();
                RenderTexture.active = renderTarget;
                pixels = new Texture2D(size, size, TextureFormat.RGB24, false);
                pixels.ReadPixels(new Rect(0, 0, size, size), 0, 0);
                pixels.Apply(false, false);
                Directory.CreateDirectory(journal.PhotoDirectory);
                var fileName = Guid.NewGuid().ToString("N") + ".png";
                File.WriteAllBytes(Path.Combine(journal.PhotoDirectory, fileName), pixels.EncodeToPNG());
                return fileName;
            }
            catch (Exception error) when (error is IOException || error is UnauthorizedAccessException || error is UnityException)
            { Debug.LogWarning($"Image capture failed; metadata remains available: {error.Message}", this); return string.Empty; }
            finally
            {
                captureCamera.targetTexture = oldTarget;
                captureCamera.transform.SetPositionAndRotation(oldPosition, oldRotation);
                RenderTexture.active = oldActive;
                if (pixels != null) Destroy(pixels);
                if (renderTarget != null) RenderTexture.ReleaseTemporary(renderTarget);
            }
        }
    }
}
