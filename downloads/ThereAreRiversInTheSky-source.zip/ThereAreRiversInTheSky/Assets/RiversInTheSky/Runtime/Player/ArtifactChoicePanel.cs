using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

namespace RiversInTheSky
{
    /// <summary>
    /// Shared world-space mouse UI. It releases the gameplay cursor while open and
    /// restores the previous state after closing. Keep this controller outside panelRoot.
    /// </summary>
    public sealed class ArtifactChoicePanel : MonoBehaviour
    {
        [SerializeField] private GameObject panelRoot;
        [SerializeField] private Text title;
        [SerializeField] private Text description;
        [SerializeField] private Text status;
        [SerializeField] private Transform buttonContainer;
        [SerializeField] private Button buttonPrefab;
        [SerializeField, Min(0.5f)] private float viewingDistance = 1.5f;
        private readonly List<Button> buttons = new List<Button>();
        private ArtifactNode node;
        private ArtifactInteractor owner;
        private bool committing;
        private bool ownsCursor;
        private CursorLockMode previousCursorLock;
        private bool previousCursorVisible;
        private CanvasGroup openingClickGroup;
        private bool previousBlocksRaycasts;
        private bool waitingForOpeningClickRelease;

        public bool IsOpen { get; private set; }
        public int LastClosedFrame { get; private set; } = -1;

        private void Awake()
        {
            if (panelRoot != null && transform.IsChildOf(panelRoot.transform))
            {
                Debug.LogError("ArtifactChoicePanel must be outside the panelRoot that it hides.", this);
                enabled = false;
                return;
            }
            if (panelRoot != null) panelRoot.SetActive(false);
        }

        private void Update()
        {
            // Teleporting or disabling a target must not leave a remote choice available.
            if (IsOpen && (node == null || !node.isActiveAndEnabled || node.Quests == null || owner == null || !owner.IsInRange ||
                panelRoot == null || !panelRoot.activeInHierarchy))
            { Close(); return; }
            if (waitingForOpeningClickRelease && (Mouse.current == null || !Mouse.current.leftButton.isPressed))
                RestoreOpeningClickRaycasts();
        }

        public void Open(ArtifactNode artifact, ArtifactInteractor source, Transform head)
        {
            if (!isActiveAndEnabled || artifact == null || artifact.Quests == null || head == null ||
                source == null || !source.IsInRange) return;
            Close();
            if (panelRoot == null || buttonPrefab == null || buttonContainer == null ||
                transform.IsChildOf(panelRoot.transform)) return;
            ArtifactDefinition definition = artifact.Quests.GetDefinition(artifact.Id);
            if (definition == null) return;
            node = artifact; owner = source;
            previousCursorLock = Cursor.lockState;
            previousCursorVisible = Cursor.visible;
            ownsCursor = true;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            IsOpen = true;
            panelRoot.SetActive(true);
            var horizontal = Vector3.ProjectOnPlane(head.forward, Vector3.up);
            if (horizontal.sqrMagnitude < 0.001f) horizontal = Vector3.forward;
            panelRoot.transform.position = head.position + horizontal.normalized * viewingDistance;
            // A world-space Canvas's front faces the viewer with this orientation.
            panelRoot.transform.rotation = Quaternion.LookRotation(horizontal.normalized, Vector3.up);
            if (title != null) title.text = definition.DisplayName;
            if (description != null) description.text = definition.Description;
            if (status != null) status.text = artifact.Quests.IsResolved(artifact.Id)
                ? "This memory is already restored."
                : artifact.Id == ArtifactId.FourYoungMaidens ? "Reconnect the Lotus, Lantern, Rice and Water channels." : string.Empty;
            foreach (var choice in definition.Choices)
            {
                var capturedId = choice.Id; // Capture an immutable ID, never a mutable loop index.
                var button = Instantiate(buttonPrefab, buttonContainer);
                button.gameObject.SetActive(true);
                var label = button.GetComponentInChildren<Text>(true);
                if (label != null) label.text = choice.Label;
                button.interactable = artifact.Quests.IsAvailable(artifact.Id) && !artifact.Quests.IsResolved(artifact.Id);
                button.onClick.AddListener(() => Commit(capturedId));
                buttons.Add(button);
            }
            // The click which opened the panel must not also press a newly spawned choice.
            if (Mouse.current != null && Mouse.current.leftButton.isPressed)
            {
                openingClickGroup = panelRoot.GetComponent<CanvasGroup>();
                if (openingClickGroup == null) openingClickGroup = panelRoot.AddComponent<CanvasGroup>();
                previousBlocksRaycasts = openingClickGroup.blocksRaycasts;
                openingClickGroup.blocksRaycasts = false;
                waitingForOpeningClickRelease = true;
            }
        }

        private void Commit(string choiceId)
        {
            if (committing || !IsOpen || node == null || !node.isActiveAndEnabled || node.Quests == null || owner == null || !owner.IsInRange)
            { Close(); return; }
            committing = true;
            foreach (var button in buttons) if (button != null) button.interactable = false;
            bool accepted;
            string error;
            try { accepted = node.Quests.TryChoose(node.Id, choiceId, out error); }
            finally { committing = false; }
            if (accepted) { Close(); return; }
            if (status != null) status.text = error;
            foreach (var button in buttons)
                if (button != null) button.interactable = node.Quests.IsAvailable(node.Id) && !node.Quests.IsResolved(node.Id);
        }

        public void CloseIfOwner(ArtifactInteractor source) { if (owner == source) Close(); }
        public void Close() => CloseInternal(isActiveAndEnabled);

        private void RestoreOpeningClickRaycasts()
        {
            if (openingClickGroup != null) openingClickGroup.blocksRaycasts = previousBlocksRaycasts;
            openingClickGroup = null;
            waitingForOpeningClickRelease = false;
        }

        private void CloseInternal(bool restoreGameplayCursor)
        {
            if (IsOpen) LastClosedFrame = Time.frameCount;
            RestoreOpeningClickRaycasts();
            foreach (var button in buttons)
            {
                if (button == null) continue;
                button.onClick.RemoveAllListeners();
                button.gameObject.SetActive(false);
                if (Application.isPlaying) Destroy(button.gameObject);
                else DestroyImmediate(button.gameObject);
            }
            buttons.Clear(); owner = null; node = null; committing = false; IsOpen = false;
            if (panelRoot != null && panelRoot != gameObject) panelRoot.SetActive(false);
            if (!ownsCursor) return;
            ownsCursor = false;
            // Disabling the UI/controller or losing focus must never trap the desktop cursor.
            bool restore = restoreGameplayCursor && Application.isFocused;
            Cursor.lockState = restore ? previousCursorLock : CursorLockMode.None;
            Cursor.visible = restore ? previousCursorVisible : true;
        }

        private void OnDisable() => CloseInternal(false);
    }
}
