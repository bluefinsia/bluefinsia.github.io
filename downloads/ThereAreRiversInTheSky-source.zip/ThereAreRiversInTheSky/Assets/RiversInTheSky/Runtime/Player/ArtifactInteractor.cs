using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>
    /// An artifact-side desktop interaction endpoint. DesktopInteractor performs the
    /// camera raycast; this component validates the player and opens the shared UI.
    /// </summary>
    [RequireComponent(typeof(ArtifactNode))]
    public sealed class ArtifactInteractor : MonoBehaviour
    {
        [SerializeField] private ArtifactNode node;
        [SerializeField] private ArtifactChoicePanel choicePanel;
        // Keep the field name to preserve existing Inspector references. It is the desktop camera.
        [SerializeField] private Transform playerHead;
        [SerializeField, Min(0.1f)] private float interactionDistance = 4f;

        public bool IsInRange => isActiveAndEnabled && playerHead != null &&
            (playerHead.position - transform.position).sqrMagnitude <=
            Mathf.Max(0.1f, interactionDistance) * Mathf.Max(0.1f, interactionDistance);

        private void Awake()
        {
            if (node == null) node = GetComponent<ArtifactNode>();
            if (playerHead == null && Camera.main != null) playerHead = Camera.main.transform;
        }

        /// <summary>Called only after the player's centre ray hits this artifact.</summary>
        public bool TryInteract(Transform viewer)
        {
            if (!isActiveAndEnabled || viewer == null) return false;
            playerHead = viewer;
            if (node == null) node = GetComponent<ArtifactNode>();
            if (!IsInRange || node == null || !node.isActiveAndEnabled || node.Quests == null ||
                choicePanel == null || !choicePanel.isActiveAndEnabled) return false;
            choicePanel.Open(node, this, playerHead);
            return choicePanel.IsOpen;
        }

        private void OnDisable()
        {
            if (choicePanel != null) choicePanel.CloseIfOwner(this);
        }

        public void Configure(ArtifactNode artifact, ArtifactChoicePanel panel, Transform head)
        { node = artifact; choicePanel = panel; playerHead = head; }
    }
}
