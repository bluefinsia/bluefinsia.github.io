using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEngine;

namespace RiversInTheSky
{
    [Serializable]
    public sealed class PhotoMemory
    {
        public string memoryId;
        public string displayName;
        public string photographedAtUtc;
        public Vector3 playerPosition;
        public Quaternion playerRotation = Quaternion.identity;
        public bool relatedToArtifact;
        public ArtifactId artifact;
        // Relative to JournalManager.PhotoDirectory; never contains a user-supplied absolute path.
        public string imageFileName;
    }

    /// <summary>A metadata journal that also indexes optional PNGs. IDs are unique across sessions.</summary>
    [DefaultExecutionOrder(-150)]
    public sealed class JournalManager : MonoBehaviour
    {
        [Serializable] private sealed class SaveData
        {
            public int version;
            public List<PhotoMemory> photos = new List<PhotoMemory>();
        }
        [SerializeField] private bool persistenceEnabled = true;
        [SerializeField] private string saveFileName = "rivers-journal-v1.json";
        private bool persistenceAllowed = true;
        private readonly List<PhotoMemory> photos = new List<PhotoMemory>();
        private readonly HashSet<string> ids = new HashSet<string>(StringComparer.Ordinal);
        public IReadOnlyList<PhotoMemory> Photos
        {
            get
            {
                var copies = new List<PhotoMemory>(photos.Count);
                foreach (var photo in photos) copies.Add(Copy(photo));
                return copies.AsReadOnly();
            }
        }
        public string PhotoDirectory => Path.Combine(Application.persistentDataPath, "rivers-photos");
        public event Action<PhotoMemory> PhotoRecorded;
        private string SavePath => Path.Combine(Application.persistentDataPath,
            string.IsNullOrWhiteSpace(saveFileName) ? "rivers-journal-v1.json" : Path.GetFileName(saveFileName));
        private void Awake() { if (persistenceEnabled) Load(); }
        public bool ContainsPhoto(string memoryId) => !string.IsNullOrWhiteSpace(memoryId) && ids.Contains(memoryId);
        public bool TryRecordPhoto(PhotoMemory memory)
        {
            if (memory == null || string.IsNullOrWhiteSpace(memory.memoryId) || !ids.Add(memory.memoryId)) return false;
            // Snapshot input data so subsequent caller mutations do not alter the saved entry.
            var stored = Copy(memory);
            if (string.IsNullOrWhiteSpace(stored.photographedAtUtc))
                stored.photographedAtUtc = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture);
            stored.imageFileName = string.IsNullOrEmpty(stored.imageFileName) ? string.Empty : Path.GetFileName(stored.imageFileName);
            photos.Add(stored);
            Save();
            PhotoRecorded?.Invoke(Copy(stored));
            return true;
        }
        public void Save()
        {
            if (!persistenceEnabled || !persistenceAllowed) return;
            try
            {
                Directory.CreateDirectory(Application.persistentDataPath);
                var payload = new SaveData { version = 1, photos = photos };
                var temporary = SavePath + ".tmp";
                File.WriteAllText(temporary, JsonUtility.ToJson(payload, true));
                // Keep the previous complete revision in case the application exits during a copy.
                if (File.Exists(SavePath)) File.Copy(SavePath, SavePath + ".bak", true);
                File.Copy(temporary, SavePath, true);
                File.Delete(temporary);
            }
            catch (Exception error) when (error is IOException || error is UnauthorizedAccessException || error is ArgumentException)
            { Debug.LogWarning($"Journal save failed: {error.Message}", this); }
        }
        private void Load()
        {
            // A newer primary is intentionally not replaced with an older backup. The player
            // may continue in memory, but this application version must not downgrade their data.
            if (!TryLoad(SavePath) && persistenceAllowed) TryLoad(SavePath + ".bak");
        }
        private bool TryLoad(string path)
        {
            if (!File.Exists(path)) return false;
            try
            {
                var payload = JsonUtility.FromJson<SaveData>(File.ReadAllText(path));
                if (payload != null && payload.version > 1)
                {
                    persistenceAllowed = false;
                    Debug.LogError("This journal belongs to a newer game version; writes are disabled to preserve it.", this);
                    return false;
                }
                if (payload == null || payload.version != 1 || payload.photos == null) return false;
                photos.Clear(); ids.Clear();
                foreach (var photo in payload.photos)
                {
                    if (photo == null || string.IsNullOrWhiteSpace(photo.memoryId) || !ids.Add(photo.memoryId)) continue;
                    var stored = Copy(photo);
                    stored.imageFileName = string.IsNullOrEmpty(photo.imageFileName) ? string.Empty : Path.GetFileName(photo.imageFileName);
                    photos.Add(stored);
                }
                return true;
            }
            catch (Exception error) when (error is IOException || error is UnauthorizedAccessException || error is ArgumentException)
            { Debug.LogWarning($"Journal load failed: {error.Message}", this); return false; }
        }
        private static PhotoMemory Copy(PhotoMemory source) => new PhotoMemory
        {
            memoryId = source.memoryId, displayName = source.displayName,
            photographedAtUtc = source.photographedAtUtc, playerPosition = source.playerPosition,
            playerRotation = source.playerRotation,
            relatedToArtifact = source.relatedToArtifact, artifact = source.artifact,
            imageFileName = source.imageFileName
        };
        private void OnApplicationPause(bool paused) { if (paused) Save(); }
        private void OnApplicationQuit() => Save();
    }
}
