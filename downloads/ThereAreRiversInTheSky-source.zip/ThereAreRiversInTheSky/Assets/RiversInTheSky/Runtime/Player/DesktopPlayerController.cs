using UnityEngine;
using UnityEngine.InputSystem;

namespace RiversInTheSky
{
    /// <summary>
    /// Collision-aware first-person walking and mouse look. The component owns its input
    /// map, so a desktop scene needs no action asset and no other action maps are disabled.
    /// Keep the Camera below this player root, at eye height, and the root upright.
    /// </summary>
    [RequireComponent(typeof(CharacterController)), DisallowMultipleComponent]
    public sealed class DesktopPlayerController : MonoBehaviour
    {
        [SerializeField] private Camera playerCamera;
        [SerializeField] private ArtifactChoicePanel choicePanel;
        [SerializeField, Min(0.1f)] private float moveSpeed = 1.5f;
        [Tooltip("Degrees per mouse pixel. Mouse delta already measures displacement per frame.")]
        [SerializeField, Min(0.001f)] private float lookSensitivity = 0.12f;
        [SerializeField, Range(-89f, 89f)] private float minPitch = -80f;
        [SerializeField, Range(-89f, 89f)] private float maxPitch = 80f;
        [SerializeField] private float gravity = -20f;

        private CharacterController character;
        private InputActionMap input;
        private InputAction move;
        private InputAction look;
        private float pitch;
        private float verticalSpeed;
        private CursorLockMode previousCursorLock;
        private bool previousCursorVisible;
        private bool ownsCursor;
        private bool wasAcceptingInput;

        public Camera PlayerCamera => playerCamera;

        private void Awake()
        {
            character = GetComponent<CharacterController>();
            if (playerCamera == null) playerCamera = GetComponentInChildren<Camera>(true);
            input = new InputActionMap("Rivers Desktop Movement");
            move = input.AddAction("Move", InputActionType.Value, expectedControlLayout: "Vector2");
            move.AddCompositeBinding("2DVector")
                .With("Up", "<Keyboard>/w").With("Down", "<Keyboard>/s")
                .With("Left", "<Keyboard>/a").With("Right", "<Keyboard>/d");
            move.AddCompositeBinding("2DVector")
                .With("Up", "<Keyboard>/upArrow").With("Down", "<Keyboard>/downArrow")
                .With("Left", "<Keyboard>/leftArrow").With("Right", "<Keyboard>/rightArrow");
            look = input.AddAction("Look", InputActionType.Value, "<Mouse>/delta", expectedControlLayout: "Vector2");
            ReadCameraPitch();
        }

        public void Configure(Camera view, ArtifactChoicePanel panel)
        {
            playerCamera = view;
            choicePanel = panel;
            ReadCameraPitch();
        }

        private void ReadCameraPitch()
        {
            if (playerCamera == null) return;
            float angle = playerCamera.transform.localEulerAngles.x;
            pitch = Mathf.Clamp(angle > 180f ? angle - 360f : angle, minPitch, maxPitch);
        }

        private void OnEnable()
        {
            input?.Enable();
            previousCursorLock = Cursor.lockState;
            previousCursorVisible = Cursor.visible;
            ownsCursor = true;
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
            if (playerCamera == null)
                Debug.LogWarning("Desktop player needs a child Camera assigned to Player Camera.", this);
        }

        private void Update()
        {
            if (character == null || !character.enabled || Time.deltaTime <= 0f) return;
            bool acceptingInput = Cursor.lockState == CursorLockMode.Locked &&
                (choicePanel == null || (!choicePanel.IsOpen && choicePanel.LastClosedFrame != Time.frameCount));
            Vector3 horizontalVelocity = Vector3.zero;
            if (acceptingInput)
            {
                Vector2 movement = Vector2.ClampMagnitude(move.ReadValue<Vector2>(), 1f);
                // World up is fixed. Looking vertically cannot propel the player into the air.
                Vector3 forward = Vector3.ProjectOnPlane(transform.forward, Vector3.up).normalized;
                Vector3 right = Vector3.Cross(Vector3.up, forward);
                horizontalVelocity = (forward * movement.y + right * movement.x) * moveSpeed;
                if (playerCamera != null && wasAcceptingInput)
                {
                    Vector2 delta = look.ReadValue<Vector2>() * lookSensitivity;
                    transform.Rotate(0f, delta.x, 0f, Space.World);
                    // Mouse delta is NOT multiplied by deltaTime, avoiding frame-rate-dependent look.
                    pitch = Mathf.Clamp(pitch - delta.y, minPitch, maxPitch);
                    playerCamera.transform.localRotation = Quaternion.Euler(pitch, 0f, 0f);
                }
            }
            // Ignore the first look sample after pointer capture; it can contain UI mouse motion.
            wasAcceptingInput = acceptingInput;
            // UI pauses walking/look, but gravity must still settle the player onto the floor.
            if (character.isGrounded && verticalSpeed < 0f) verticalSpeed = -2f;
            verticalSpeed = Mathf.Max(-50f, verticalSpeed - Mathf.Abs(gravity) * Time.deltaTime);
            CollisionFlags collisions = character.Move((horizontalVelocity + Vector3.up * verticalSpeed) * Time.deltaTime);
            if ((collisions & CollisionFlags.Above) != 0 && verticalSpeed > 0f) verticalSpeed = 0f;
        }

        private void OnApplicationFocus(bool focused)
        {
            if (focused) return;
            wasAcceptingInput = false;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            // Returning to the game requires a click; it must not capture the pointer unexpectedly.
        }

        private void OnDisable()
        {
            input?.Disable();
            verticalSpeed = 0f;
            wasAcceptingInput = false;
            if (!ownsCursor) return;
            Cursor.lockState = previousCursorLock;
            Cursor.visible = previousCursorVisible;
            ownsCursor = false;
        }

        private void OnDestroy() => input?.Dispose();

        private void OnValidate()
        {
            moveSpeed = Mathf.Max(0.1f, moveSpeed);
            lookSensitivity = Mathf.Max(0.001f, lookSensitivity);
            minPitch = Mathf.Clamp(minPitch, -89f, 89f);
            maxPitch = Mathf.Clamp(maxPitch, minPitch, 89f);
        }
    }
}
