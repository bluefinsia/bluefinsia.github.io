using UnityEngine;
using UnityEngine.InputSystem;

namespace RiversInTheSky
{
    /// <summary>
    /// E or left click interacts with the first solid object in the camera's centre ray.
    /// F photographs, Escape closes choices/releases the pointer, and a click resumes play.
    /// Place this on the player root so its own colliders can be excluded from the ray.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class DesktopInteractor : MonoBehaviour
    {
        [SerializeField] private Camera playerCamera;
        [SerializeField] private ArtifactChoicePanel choicePanel;
        [SerializeField] private EnvironmentCamera environmentCamera;
        [Tooltip("Optional scene surfaces whose environmental diagnostic view toggles with T.")]
        [SerializeField] private CyanobacteriaController[] diagnosticSurfaces = new CyanobacteriaController[0];
        [Tooltip("Include scenery and interaction colliders. Exclude player/tool layers where possible.")]
        [SerializeField] private LayerMask interactionMask = Physics.DefaultRaycastLayers;
        [SerializeField, Min(0.1f)] private float interactionDistance = 4f;

        private InputActionMap input;
        private InputAction interact;
        private InputAction pointerClick;
        private InputAction photograph;
        private InputAction cancel;
        private InputAction thermalView;

        private void Awake()
        {
            if (playerCamera == null) playerCamera = GetComponentInChildren<Camera>(true);
            if (environmentCamera == null) environmentCamera = GetComponent<EnvironmentCamera>();
            input = new InputActionMap("Rivers Desktop Interaction");
            interact = input.AddAction("Interact", InputActionType.Button, "<Keyboard>/e");
            pointerClick = input.AddAction("Pointer Click", InputActionType.Button, "<Mouse>/leftButton");
            photograph = input.AddAction("Photograph", InputActionType.Button, "<Keyboard>/f");
            cancel = input.AddAction("Cancel", InputActionType.Button, "<Keyboard>/escape");
            thermalView = input.AddAction("Thermal View", InputActionType.Button, "<Keyboard>/t");
        }

        public void Configure(Camera view, ArtifactChoicePanel panel, EnvironmentCamera cameraTool)
        { playerCamera = view; choicePanel = panel; environmentCamera = cameraTool; }

        private void OnEnable() => input?.Enable();
        private void OnDisable() => input?.Disable();
        private void OnDestroy() => input?.Dispose();

        private void Update()
        {
            // The panel handles cursor restoration. Do not immediately release it a second time.
            if (cancel.WasPressedThisFrame())
            {
                if (choicePanel != null && choicePanel.IsOpen) choicePanel.Close();
                else { Cursor.lockState = CursorLockMode.None; Cursor.visible = true; }
                return;
            }
            if (choicePanel != null && choicePanel.IsOpen) return;
            // EventSystem may have just closed the menu earlier in this Update cycle.
            // Its button click belongs to UI, not to the artifact behind the canvas.
            if (choicePanel != null && choicePanel.LastClosedFrame == Time.frameCount) return;
            if (Cursor.lockState != CursorLockMode.Locked)
            {
                if (pointerClick.WasPressedThisFrame())
                { Cursor.lockState = CursorLockMode.Locked; Cursor.visible = false; }
                return; // Resuming input must not also commit an interaction on that click.
            }
            if (photograph.WasPressedThisFrame())
            {
                if (environmentCamera != null) environmentCamera.Photograph();
                return;
            }
            if (thermalView.WasPressedThisFrame() && diagnosticSurfaces != null)
                foreach (CyanobacteriaController surface in diagnosticSurfaces)
                    if (surface != null) surface.ToggleThermalView();
            if (interact.WasPressedThisFrame() || pointerClick.WasPressedThisFrame()) TryInteract();
        }

        /// <summary>
        /// Performs one aim query without requiring a keyboard event. True means an interaction
        /// was delivered; a valve can still reject it through its existing prerequisite event.
        /// </summary>
        public bool TryInteract()
        {
            if (playerCamera == null || (choicePanel != null && choicePanel.IsOpen)) return false;
            Ray ray = playerCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0f));
            // ViewportPointToRay starts at the near clip plane. Start at the lens instead,
            // so even an occluder closer than that plane still blocks an interaction.
            ray.origin = playerCamera.transform.position;
            // This allocates only on a deliberate press. Filtering all hits skips our own body
            // without ignoring walls or requiring every default-layer object to be relayered.
            RaycastHit[] hits = Physics.RaycastAll(ray, interactionDistance, interactionMask, QueryTriggerInteraction.Ignore);
            int closestIndex = -1;
            float closestDistance = float.PositiveInfinity;
            for (int i = 0; i < hits.Length; i++)
            {
                if (hits[i].collider == null || hits[i].collider.transform.IsChildOf(transform)) continue;
                if (hits[i].distance >= closestDistance) continue;
                closestIndex = i;
                closestDistance = hits[i].distance;
            }
            if (closestIndex < 0) return false;
            Collider target = hits[closestIndex].collider;
            ArtifactInteractor artifact = target.GetComponentInParent<ArtifactInteractor>();
            if (artifact != null && artifact.isActiveAndEnabled) return artifact.TryInteract(playerCamera.transform);
            WaterChannelValve valve = target.GetComponentInParent<WaterChannelValve>();
            if (valve == null || !valve.isActiveAndEnabled) return false;
            valve.Connect();
            return true;
        }
    }
}
