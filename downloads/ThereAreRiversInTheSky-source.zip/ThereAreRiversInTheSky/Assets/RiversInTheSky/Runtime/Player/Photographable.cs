using System.Collections.Generic;
using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>Place on a location or artifact root. Give every memory a stable, unique authoring ID.</summary>
    public sealed class Photographable : MonoBehaviour
    {
        private static readonly HashSet<Photographable> active = new HashSet<Photographable>();
        public static IEnumerable<Photographable> Active => active;
        [SerializeField] private string memoryId;
        [SerializeField] private string displayName;
        [SerializeField] private Transform framingPoint;
        [SerializeField] private bool relatedToArtifact;
        [SerializeField] private ArtifactId artifact;
        public string MemoryId => memoryId;
        public string DisplayName => displayName;
        public Vector3 FramingPosition => framingPoint != null ? framingPoint.position : transform.position;
        public bool RelatedToArtifact => relatedToArtifact;
        public ArtifactId Artifact => artifact;
        private void OnEnable() => active.Add(this);
        private void OnDisable() => active.Remove(this);
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ClearRegistry() => active.Clear();
        public void Configure(string id, string label, bool isArtifact, ArtifactId artifactId)
        { memoryId = id; displayName = label; relatedToArtifact = isArtifact; artifact = artifactId; }
    }
}
