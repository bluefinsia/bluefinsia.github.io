using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>
    /// Supplies the painterly shader with one head position (shared by both eyes),
    /// channel flow, and an optional environmental diagnostic overlay.
    /// Owns only the named shader properties, preserving other property-block values.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class CyanobacteriaController : MonoBehaviour
    {
        [SerializeField] private QuestManager quests;
        [SerializeField] private Transform playerHead;
        [SerializeField] private Renderer[] targets = new Renderer[0];
        [SerializeField, Min(0.01f)] private float proximityRadius = 5f;
        [SerializeField, Range(0f, 1f)] private float proximityStrength = 1f;
        [SerializeField] private Vector2 flowDirection = new Vector2(1f, 0.25f);
        [SerializeField, Range(0f, 1f)] private float baseFlow = 0.08f;
        [SerializeField] private bool useQuestFlow = true;
        [SerializeField, Range(0f, 1f)] private float thermalValue = 0.5f;
        [SerializeField] private bool thermalView;

        private readonly MaterialPropertyBlock block = new MaterialPropertyBlock();
        private float flow;
        private static readonly int Observer = Shader.PropertyToID("_ObserverWS");
        private static readonly int Radius = Shader.PropertyToID("_ProximityRadius");
        private static readonly int Proximity = Shader.PropertyToID("_ProximityStrength");
        private static readonly int Flow = Shader.PropertyToID("_FlowStrength");
        private static readonly int Direction = Shader.PropertyToID("_FlowDirection");
        private static readonly int ThermalBlend = Shader.PropertyToID("_ThermalBlend");
        private static readonly int ThermalValue = Shader.PropertyToID("_ThermalValue");

        private void Awake()
        {
            if (targets == null || targets.Length == 0)
                targets = GetComponentsInChildren<Renderer>(true);
            flow = baseFlow;
        }

        private void OnEnable()
        {
            if (quests != null)
            {
                quests.StateChanged += RefreshQuest;
                RefreshQuest(quests.Snapshot);
            }
        }

        private void OnDisable()
        {
            if (quests != null) quests.StateChanged -= RefreshQuest;
            // Do not clear blocks: another component may own unrelated properties.
            Apply(false);
        }

        public void Configure(QuestManager manager, Transform head, Renderer[] renderers = null)
        {
            if (quests != null && isActiveAndEnabled) quests.StateChanged -= RefreshQuest;
            quests = manager;
            playerHead = head;
            if (renderers != null) targets = renderers;
            if (quests != null && isActiveAndEnabled)
            {
                quests.StateChanged += RefreshQuest;
                RefreshQuest(quests.Snapshot);
            }
        }

        private void RefreshQuest(QuestSnapshot snapshot)
        {
            if (!useQuestFlow || snapshot == null) return;
            // Count flags rather than their numeric value: Rice=4 is one channel.
            int flags = (int)snapshot.ConnectedChannels;
            int count = 0;
            for (int bit = 0; bit < 4; bit++) count += (flags >> bit) & 1;
            flow = Mathf.Lerp(baseFlow, 1f, count / 4f);
        }

        /// <summary>Manual flow control for local streams; overrides quest-derived flow.</summary>
        public void SetFlowStrength(float value)
        {
            useQuestFlow = false;
            flow = Mathf.Clamp01(value);
        }

        /// <summary>0 = cool/low impact; 1 = hot/high impact. This is environmental data.</summary>
        public void SetThermalValue(float value) => thermalValue = Mathf.Clamp01(value);
        public void SetThermalView(bool enabled) => thermalView = enabled;
        public void ToggleThermalView() => thermalView = !thermalView;

        private void LateUpdate() => Apply(true);

        private void Apply(bool active)
        {
            if (targets == null) return;
            Vector3 head = playerHead != null ? playerHead.position : Vector3.zero;
            Vector2 direction = flowDirection.sqrMagnitude > 0.0001f
                ? flowDirection.normalized : Vector2.right;
            foreach (Renderer target in targets)
            {
                if (target == null) continue;
                target.GetPropertyBlock(block);
                block.SetVector(Observer, new Vector4(head.x, head.y, head.z, 1f));
                block.SetFloat(Radius, Mathf.Max(0.01f, proximityRadius));
                block.SetFloat(Proximity, active && playerHead != null ? proximityStrength : 0f);
                block.SetFloat(Flow, Mathf.Clamp01(flow));
                block.SetVector(Direction, new Vector4(direction.x, direction.y, 0f, 0f));
                block.SetFloat(ThermalValue, Mathf.Clamp01(thermalValue));
                block.SetFloat(ThermalBlend, active && thermalView ? 1f : 0f);
                target.SetPropertyBlock(block);
            }
        }
    }
}
