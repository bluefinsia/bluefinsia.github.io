using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace RiversInTheSky
{
    /// <summary>
    /// Grades a dedicated global Volume from twilight blues toward candlelit memory.
    /// A runtime clone prevents editing the shared profile asset or another scene's grade.
    /// Use a dedicated Volume so disabling this component restores the original profile.
    /// </summary>
    [RequireComponent(typeof(Volume)), DisallowMultipleComponent]
    public sealed class PainterlyGradeController : MonoBehaviour
    {
        [SerializeField] private QuestManager quests;
        [SerializeField, Min(0.01f)] private float transitionSeconds = 3f;
        [SerializeField] private Color twilightFilter = new Color(0.72f, 0.83f, 1f);
        [SerializeField] private Color candlelightFilter = new Color(1f, 0.9f, 0.75f);
        [SerializeField, Range(0f, 1f)] private float bloomIntensity = 0.18f;
        [SerializeField] private bool enableBloom = false;

        private Volume volume;
        private VolumeProfile originalProfile;
        private bool restoreInternalProfile;
        private VolumeProfile runtimeProfile;
        private ColorAdjustments color;
        private WhiteBalance whiteBalance;
        private Vignette vignette;
        private Bloom bloom;
        private float warmth;
        private float targetWarmth;

        private void OnEnable()
        {
            volume = GetComponent<Volume>();
            restoreInternalProfile = volume.HasInstantiatedProfile();
            originalProfile = restoreInternalProfile ? volume.profile : volume.sharedProfile;
            runtimeProfile = ScriptableObject.CreateInstance<VolumeProfile>();
            // Clone every override, not just the profile's component list.
            if (originalProfile != null)
                foreach (VolumeComponent component in originalProfile.components)
                    runtimeProfile.components.Add(Instantiate(component));
            volume.profile = runtimeProfile;
            color = GetOrAdd<ColorAdjustments>();
            whiteBalance = GetOrAdd<WhiteBalance>();
            vignette = GetOrAdd<Vignette>();
            bloom = GetOrAdd<Bloom>();
            color.contrast.Override(10f);
            color.saturation.Override(-8f);
            vignette.intensity.Override(0.08f);
            vignette.smoothness.Override(0.75f);
            bloom.threshold.Override(1.1f);
            bloom.intensity.Override(enableBloom ? bloomIntensity : 0f);
            if (quests != null)
            {
                quests.StateChanged += RefreshQuest;
                RefreshQuest(quests.Snapshot);
            }
            warmth = targetWarmth;
            ApplyGrade();
        }

        public void Configure(QuestManager manager)
        {
            if (quests != null && isActiveAndEnabled) quests.StateChanged -= RefreshQuest;
            quests = manager;
            if (quests != null && isActiveAndEnabled)
            {
                quests.StateChanged += RefreshQuest;
                RefreshQuest(quests.Snapshot);
            }
        }

        private T GetOrAdd<T>() where T : VolumeComponent
        {
            if (!runtimeProfile.TryGet<T>(out T component)) component = runtimeProfile.Add<T>(true);
            component.active = true;
            return component;
        }

        private void RefreshQuest(QuestSnapshot snapshot)
        {
            if (snapshot != null) targetWarmth = Mathf.Clamp01(snapshot.CleansedCount / 5f);
        }

        public void SetWarmth(float value) => targetWarmth = Mathf.Clamp01(value);

        private void Update()
        {
            warmth = Mathf.MoveTowards(warmth, targetWarmth,
                Time.unscaledDeltaTime / Mathf.Max(0.01f, transitionSeconds));
            ApplyGrade();
        }

        private void ApplyGrade()
        {
            color.colorFilter.Override(Color.Lerp(twilightFilter, candlelightFilter, warmth));
            whiteBalance.temperature.Override(Mathf.Lerp(-12f, 16f, warmth));
            whiteBalance.tint.Override(2f);
        }

        private void OnDisable()
        {
            if (quests != null) quests.StateChanged -= RefreshQuest;
            if (volume != null && volume.profile == runtimeProfile)
                volume.profile = restoreInternalProfile ? originalProfile : null;
            if (runtimeProfile == null) return;
            foreach (VolumeComponent component in runtimeProfile.components) Destroy(component);
            Destroy(runtimeProfile);
            runtimeProfile = null;
        }
    }
}
