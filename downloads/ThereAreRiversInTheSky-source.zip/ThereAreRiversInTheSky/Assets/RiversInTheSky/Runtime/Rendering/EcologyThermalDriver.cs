using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>
    /// Maps one relative quest metric into a local diagnostic color. This is an authored
    /// environmental overlay, not a temperature measurement. Put separate drivers on
    /// the leakage, wetland, and irrigation regions to show the relevant consequence.
    /// </summary>
    public sealed class EcologyThermalDriver : MonoBehaviour
    {
        public enum Metric { Habitat, Pollution, Toxicity, FloodRisk, Nutrients }
        [SerializeField] private QuestManager quests;
        [SerializeField] private CyanobacteriaController surface;
        [SerializeField] private Metric metric = Metric.Toxicity;
        [SerializeField, Range(0f, 1f)] private float baseline = 0.5f;
        [SerializeField, Min(0.01f)] private float unitsToFullScale = 4f;
        [Tooltip("Enable when decreasing this metric should produce a hotter impact color, such as habitat loss.")]
        [SerializeField] private bool invert;

        private void OnEnable()
        {
            if (quests == null) return;
            quests.StateChanged += Refresh;
            Refresh(quests.Snapshot);
        }
        private void OnDisable() { if (quests != null) quests.StateChanged -= Refresh; }
        private void Refresh(QuestSnapshot snapshot)
        {
            if (snapshot == null || surface == null) return;
            int value;
            switch (metric)
            {
                case Metric.Habitat: value = snapshot.Habitat; break;
                case Metric.Pollution: value = snapshot.Pollution; break;
                case Metric.Toxicity: value = snapshot.Toxicity; break;
                case Metric.FloodRisk: value = snapshot.FloodRisk; break;
                case Metric.Nutrients: value = snapshot.Nutrients; break;
                default: value = 0; break;
            }
            surface.SetThermalValue(Mathf.Clamp01(baseline + (invert ? -value : value) /
                Mathf.Max(0.01f, unitsToFullScale)));
        }
    }
}
