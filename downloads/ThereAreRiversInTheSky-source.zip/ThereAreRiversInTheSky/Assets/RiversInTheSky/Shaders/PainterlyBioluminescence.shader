Shader "RiversInTheSky/PainterlyBioluminescence"
{
    Properties
    {
        _BaseMap ("Paint / Albedo", 2D) = "white" {}
        _PatternMap ("Biology: R=colony, G=brush, B=diagnostic", 2D) = "white" {}
        _BaseColor ("Base Color", Color) = (0.09, 0.25, 0.24, 1)
        [HDR] _GlowColor ("Cyanobacteria Glow", Color) = (0.03, 1.8, 1.4, 1)
        _EmissionStrength ("Emission Strength (0 for architecture)", Range(0, 5)) = 1
        [Toggle] _ProceduralPattern ("Generate Colony Pattern", Float) = 1
        _PatternScale ("World Pattern Scale", Float) = 0.5
        _PatternThreshold ("Colony Threshold", Range(0, 1)) = 0.5
        _PatternSoftness ("Colony Softness", Range(0.01, 0.5)) = 0.12
        _Iridescence ("Iridescence", Range(0, 1)) = 0.6
        _BrushStrength ("Brush Variation", Range(0, 1)) = 0.25
        _LightBands ("Paint Light Bands", Range(2, 8)) = 4
        _FlowStrength ("Water Flow", Range(0, 1)) = 0.08
        _FlowDirection ("Flow X/Z", Vector) = (1, 0, 0, 0)
        _FlowSpeed ("Flow Speed", Float) = 0.04
        _ObserverWS ("Observer World Position", Vector) = (0, 0, 0, 1)
        _ProximityRadius ("Response Radius", Float) = 5
        _ProximityStrength ("Proximity Response", Range(0, 1)) = 0
        _ThermalValue ("Environmental Impact", Range(0, 1)) = 0.5
        _ThermalTextureInfluence ("Diagnostic Texture Influence", Range(0, 1)) = 0
        _ThermalBlend ("Diagnostic Overlay", Range(0, 1)) = 0
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" "RenderPipeline"="UniversalPipeline" "Queue"="Geometry" }
        LOD 150
        HLSLINCLUDE
        #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
        #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
        TEXTURE2D(_BaseMap); SAMPLER(sampler_BaseMap);
        TEXTURE2D(_PatternMap); SAMPLER(sampler_PatternMap);
        // Identical layout in every pass is required for the SRP Batcher.
        CBUFFER_START(UnityPerMaterial)
            float4 _BaseMap_ST;
            float4 _PatternMap_ST;
            half4 _BaseColor;
            half4 _GlowColor;
            float4 _ObserverWS;
            float4 _FlowDirection;
            float _PatternScale;
            float _ProximityRadius;
            float _FlowSpeed;
            half _EmissionStrength;
            half _ProceduralPattern;
            half _PatternThreshold;
            half _PatternSoftness;
            half _Iridescence;
            half _BrushStrength;
            half _LightBands;
            half _FlowStrength;
            half _ProximityStrength;
            half _ThermalValue;
            half _ThermalTextureInfluence;
            half _ThermalBlend;
        CBUFFER_END
        ENDHLSL

        Pass
        {
            Name "PainterlyForward"
            Tags { "LightMode"="UniversalForward" }
            Cull Back ZWrite On ZTest LEqual
            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma multi_compile_instancing
            #pragma multi_compile_fog
            #pragma multi_compile _ _MAIN_LIGHT_SHADOWS _MAIN_LIGHT_SHADOWS_CASCADE _MAIN_LIGHT_SHADOWS_SCREEN
            #pragma multi_compile_fragment _ _SHADOWS_SOFT

            struct Attributes
            {
                float4 positionOS : POSITION;
                float3 normalOS : NORMAL;
                float2 uv : TEXCOORD0;
                UNITY_VERTEX_INPUT_INSTANCE_ID
            };
            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                float3 positionWS : TEXCOORD0;
                half3 normalWS : TEXCOORD1;
                float2 uv : TEXCOORD2;
                half fog : TEXCOORD3;
                UNITY_VERTEX_INPUT_INSTANCE_ID
                UNITY_VERTEX_OUTPUT_STEREO
            };
            Varyings Vert(Attributes input)
            {
                Varyings output = (Varyings)0;
                UNITY_SETUP_INSTANCE_ID(input);
                UNITY_TRANSFER_INSTANCE_ID(input, output);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(output);
                VertexPositionInputs position = GetVertexPositionInputs(input.positionOS.xyz);
                output.positionCS = position.positionCS;
                output.positionWS = position.positionWS;
                output.normalWS = TransformObjectToWorldNormal(input.normalOS);
                output.uv = TRANSFORM_TEX(input.uv, _BaseMap);
                output.fog = ComputeFogFactor(position.positionCS.z);
                return output;
            }

            float ColonyHash(float2 p)
            {
                float3 p3 = frac(float3(p.x, p.y, p.x) * 0.1031);
                p3 += dot(p3, p3.yzx + 33.33);
                return frac((p3.x + p3.y) * p3.z);
            }
            float ColonyNoise(float2 p)
            {
                float2 cell = floor(p);
                float2 f = frac(p);
                f = f * f * (3.0 - 2.0 * f);
                return lerp(lerp(ColonyHash(cell), ColonyHash(cell + float2(1, 0)), f.x),
                    lerp(ColonyHash(cell + float2(0, 1)), ColonyHash(cell + 1.0), f.x), f.y);
            }

            // A continuous blue/cyan/yellow/red palette, independent of scene lighting.
            half3 DiagnosticPalette(half t)
            {
                half3 low = half3(0.03h, 0.05h, 0.35h);
                half3 mid = half3(0.0h, 0.9h, 0.85h);
                half3 high = half3(1.0h, 0.85h, 0.03h);
                half3 peak = half3(1.0h, 0.03h, 0.015h);
                return lerp(lerp(low, mid, saturate(t * 3.0h)),
                    lerp(high, peak, saturate(t * 3.0h - 2.0h)), saturate(t * 3.0h - 1.0h));
            }

            half4 Frag(Varyings input) : SV_Target
            {
                UNITY_SETUP_INSTANCE_ID(input);
                // Must precede view-direction lookup for single-pass instanced XR.
                UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
                half3 normal = normalize(input.normalWS);
                half3 view = GetWorldSpaceNormalizeViewDir(input.positionWS);
                float2 flowDirection = _FlowDirection.xy;
                flowDirection *= rsqrt(max(dot(flowDirection, flowDirection), 0.0001));
                float2 worldUV = input.positionWS.xz * _PatternScale;
                worldUV = worldUV * _PatternMap_ST.xy + _PatternMap_ST.zw;
                worldUV -= flowDirection * (_Time.y * _FlowSpeed * _FlowStrength);
                half3 pattern;
                // Uniform branch avoids procedural arithmetic when an artist supplies a texture.
                if (_ProceduralPattern > 0.5h)
                {
                    half noise = ColonyNoise(worldUV * 3.0);
                    pattern = half3(noise, smoothstep(0.1h, 0.9h, noise), 1.0h - noise);
                }
                else pattern = SAMPLE_TEXTURE2D(_PatternMap, sampler_PatternMap, worldUV).rgb;
                half colony = smoothstep(_PatternThreshold - _PatternSoftness,
                    _PatternThreshold + _PatternSoftness, pattern.r);
                half nearHead = saturate(1.0 - distance(input.positionWS, _ObserverWS.xyz)
                    / max(_ProximityRadius, 0.01)) * _ProximityStrength;
                half fresnel = pow(1.0h - saturate(dot(normal, view)), 3.0h);
                // Phase-shifted cosine gives a continuous thin-film-like hue cycle.
                half3 iridescence = 0.5h + 0.5h * cos(6.283185h *
                    (fresnel + pattern.g * 0.15h + half3(0.0h, 0.33h, 0.67h)));
                half3 glow = lerp(_GlowColor.rgb, _GlowColor.rgb * (0.35h + iridescence), _Iridescence);
                half pulse = 0.85h + 0.15h * sin(_Time.y * 1.3h + pattern.r * 6.283185h);
                half3 emission = glow * colony * _EmissionStrength * pulse
                    * (0.12h + nearHead + 0.8h * _FlowStrength);

                float4 shadowCoord;
                #if defined(_MAIN_LIGHT_SHADOWS_SCREEN)
                    // Screen-space shadow resolve expects projected screen coordinates.
                    shadowCoord = ComputeScreenPos(TransformWorldToHClip(input.positionWS));
                #else
                    shadowCoord = TransformWorldToShadowCoord(input.positionWS);
                #endif
                Light sun = GetMainLight(shadowCoord);
                half lambert = saturate(dot(normal, sun.direction));
                half bands = max(_LightBands, 2.0h);
                half paintedLight = floor(lambert * (bands - 1.0h) + 0.5h) / (bands - 1.0h);
                half3 albedo = SAMPLE_TEXTURE2D(_BaseMap, sampler_BaseMap, input.uv).rgb * _BaseColor.rgb;
                albedo *= lerp(1.0h, 0.7h + 0.6h * pattern.g, _BrushStrength);
                half3 lighting = max(SampleSH(normal), 0.06h) + sun.color
                    * paintedLight * sun.distanceAttenuation * sun.shadowAttenuation;
                half3 color = albedo * lighting + emission;
                half diagnostic = saturate(_ThermalValue
                    + (pattern.b - 0.5h) * _ThermalTextureInfluence);
                color = lerp(color, DiagnosticPalette(diagnostic), _ThermalBlend);
                color = MixFog(color, input.fog);
                return half4(color, 1.0h);
            }
            ENDHLSL
        }

        Pass
        {
            Name "ShadowCaster"
            Tags { "LightMode"="ShadowCaster" }
            ZWrite On ZTest LEqual ColorMask 0 Cull Back
            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex ShadowVert
            #pragma fragment ShadowFrag
            #pragma multi_compile_instancing
            #pragma multi_compile_vertex _ _CASTING_PUNCTUAL_LIGHT_SHADOW
            float3 _LightDirection;
            float3 _LightPosition;
            struct ShadowAttributes
            {
                float4 positionOS : POSITION;
                float3 normalOS : NORMAL;
                UNITY_VERTEX_INPUT_INSTANCE_ID
            };
            struct ShadowVaryings { float4 positionCS : SV_POSITION; };
            ShadowVaryings ShadowVert(ShadowAttributes input)
            {
                UNITY_SETUP_INSTANCE_ID(input);
                ShadowVaryings output;
                float3 positionWS = TransformObjectToWorld(input.positionOS.xyz);
                float3 normalWS = TransformObjectToWorldNormal(input.normalOS);
                #if defined(_CASTING_PUNCTUAL_LIGHT_SHADOW)
                    float3 direction = normalize(_LightPosition - positionWS);
                #else
                    float3 direction = _LightDirection;
                #endif
                output.positionCS = TransformWorldToHClip(ApplyShadowBias(positionWS, normalWS, direction));
                // URP 17 handles reversed-Z, near clipping and shadow pancaking here.
                // Inline directional-light near-plane clamping works across URP 17 patches,
                // including patches before the ApplyShadowClamping helper was introduced.
                #if !defined(_CASTING_PUNCTUAL_LIGHT_SHADOW)
                    #if UNITY_REVERSED_Z
                        output.positionCS.z = min(output.positionCS.z,
                            output.positionCS.w * UNITY_NEAR_CLIP_VALUE);
                    #else
                        output.positionCS.z = max(output.positionCS.z,
                            output.positionCS.w * UNITY_NEAR_CLIP_VALUE);
                    #endif
                #endif
                return output;
            }
            half4 ShadowFrag(ShadowVaryings input) : SV_Target { return 0; }
            ENDHLSL
        }

        Pass
        {
            Name "DepthOnly"
            Tags { "LightMode"="DepthOnly" }
            ZWrite On ColorMask R Cull Back
            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex DepthVert
            #pragma fragment DepthFrag
            #pragma multi_compile_instancing
            struct DepthAttributes { float4 positionOS : POSITION; UNITY_VERTEX_INPUT_INSTANCE_ID };
            struct DepthVaryings { float4 positionCS : SV_POSITION; UNITY_VERTEX_OUTPUT_STEREO };
            DepthVaryings DepthVert(DepthAttributes input)
            {
                DepthVaryings output = (DepthVaryings)0;
                UNITY_SETUP_INSTANCE_ID(input);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(output);
                output.positionCS = TransformObjectToHClip(input.positionOS.xyz);
                return output;
            }
            half DepthFrag(DepthVaryings input) : SV_Target { return input.positionCS.z; }
            ENDHLSL
        }
    }
    FallBack Off
}
