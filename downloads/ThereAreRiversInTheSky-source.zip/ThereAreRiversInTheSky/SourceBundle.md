# Complete desktop source listing

Unity 6000.0 / URP 17 / Input System / uGUI. Copy each block to its named file. No headset packages or action asset are required. Read README.md for import, migration and demo-scene setup.

## Assets/RiversInTheSky/Editor/DesktopDemoSceneBuilder.cs

```csharp
using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace RiversInTheSky.Editor
{
    /// <summary>
    /// Builds a complete, wired desktop test scene from the same runtime systems used by
    /// authored levels. Repeated runs create new scenes and preserve existing material assets.
    /// Art and audio can then be replaced without changing quest data or save identities.
    /// </summary>
    public static class DesktopDemoSceneBuilder
    {
        private const string Root = "Assets/RiversInTheSky";
        private const string MaterialFolder = Root + "/Data/DesktopDemo";
        private static Font Font => Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");

        [MenuItem("Tools/Rivers in the Sky/Create Desktop Demo Scene")]
        public static void Create()
        {
            // Respect an unsaved authored scene; cancellation leaves it untouched.
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            if (Shader.Find("RiversInTheSky/PainterlyBioluminescence") == null)
                throw new InvalidOperationException("Import the RiversInTheSky shader before generating its demo scene.");
            EnsureFolder(Root + "/Scenes");
            EnsureFolder(MaterialFolder);
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            Material stone = Material("Demo Painted Stone", new Color(.2f, .29f, .29f), 0f);
            Material living = Material("Demo Living Water", new Color(.03f, .2f, .21f), 1.5f);
            Material restoration = Material("Demo Restoration", new Color(.08f, .5f, .38f), .5f);
            Material impact = Material("Demo Impact", new Color(.65f, .24f, .12f), .15f);
            var diagnostics = new List<CyanobacteriaController>();

            var services = new GameObject("Services");
            var quests = services.AddComponent<QuestManager>();
            // A demo run starts fresh and cannot replace an existing game's save files.
            Edit(quests, so => { so.FindProperty("loadOnAwake").boolValue = false; so.FindProperty("autoSave").boolValue = false; });
            var journal = services.AddComponent<JournalManager>();
            Edit(journal, so => so.FindProperty("persistenceEnabled").boolValue = false);
            var audio = services.AddComponent<AudioLandscapeManager>();
            audio.Configure(quests);

            var player = new GameObject("Desktop Player");
            player.layer = 2; // Built-in Ignore Raycast: the player's collider must not hide a subject.
            player.transform.position = new Vector3(0f, .05f, -4f);
            var body = player.AddComponent<CharacterController>();
            body.height = 1.8f; body.radius = .3f; body.center = new Vector3(0, .9f, 0);
            body.stepOffset = .25f; body.slopeLimit = 45f;
            var cameraObject = Child("Main Camera", player.transform);
            cameraObject.tag = "MainCamera"; cameraObject.layer = 2;
            cameraObject.transform.localPosition = new Vector3(0, 1.65f, 0);
            var camera = cameraObject.AddComponent<Camera>();
            camera.nearClipPlane = .05f; camera.farClipPlane = 150f; camera.fieldOfView = 65f;
            camera.backgroundColor = new Color(.12f, .18f, .25f);
            camera.GetUniversalAdditionalCameraData().renderPostProcessing = true;
            cameraObject.AddComponent<AudioListener>();

            var panelOwner = new GameObject("Choice Panel Controller");
            var panel = panelOwner.AddComponent<ArtifactChoicePanel>();
            CreateChoicePanel(panel, camera);
            var photoCamera = cameraObject.AddComponent<EnvironmentCamera>();
            Edit(photoCamera, so =>
            {
                Ref(so, "viewfinder", camera.transform); Ref(so, "journal", journal);
                so.FindProperty("visibilityMask").intValue = Physics.DefaultRaycastLayers;
            });
            player.AddComponent<DesktopPlayerController>().Configure(camera, panel);
            var interaction = player.AddComponent<DesktopInteractor>();
            interaction.Configure(camera, panel, photoCamera);

            var eventSystem = new GameObject("EventSystem", typeof(EventSystem), typeof(InputSystemUIInputModule));
            // The module creates and owns its standard pointer/UI actions when no asset is assigned.
            eventSystem.GetComponent<InputSystemUIInputModule>().AssignDefaultActions();

            Primitive("Floor", PrimitiveType.Cube, null, new Vector3(0, -.15f, 3f), new Vector3(18, .3f, 18), stone);
            var sunObject = new GameObject("Twilight Sun");
            var sun = sunObject.AddComponent<Light>();
            sun.type = LightType.Directional; sun.intensity = 1.2f; sun.color = new Color(1f, .85f, .67f);
            sun.shadows = LightShadows.Soft; sun.transform.rotation = Quaternion.Euler(48, -28, 0);
            RenderSettings.ambientMode = AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(.32f, .4f, .5f);
            var gradeObject = new GameObject("Painterly Global Volume");
            gradeObject.AddComponent<Volume>().isGlobal = true;
            gradeObject.AddComponent<PainterlyGradeController>().Configure(quests);

            CreateHud(quests, camera, living);
            Vector3[] positions =
            {
                new Vector3(-3, 0, 0), new Vector3(0, 0, 1), new Vector3(3, 0, 0),
                new Vector3(-3, 0, 4), new Vector3(3, 0, 4)
            };
            for (int i = 0; i < positions.Length; i++)
            {
                ArtifactId id = (ArtifactId)i;
                ArtifactDefinition definition = ArtifactDefinition.CreateDefault(id);
                try
                {
                    var artifact = new GameObject(definition.DisplayName);
                    artifact.transform.position = positions[i];
                    var visual = Primitive("Artifact Form", i == 1 ? PrimitiveType.Sphere : PrimitiveType.Cube,
                        artifact.transform, new Vector3(0, .65f, 0), new Vector3(1, 1.1f, 1), i == 1 ? living : stone);
                    var node = artifact.AddComponent<ArtifactNode>(); node.Configure(quests, id);
                    artifact.AddComponent<ArtifactInteractor>().Configure(node, panel, camera.transform);
                    var memory = artifact.AddComponent<Photographable>();
                    memory.Configure("artifact-" + id.ToString().ToLowerInvariant(), definition.DisplayName, true, id);
                    Edit(memory, so => Ref(so, "framingPoint", visual.transform));
                    Label(definition.DisplayName, artifact.transform, new Vector3(0, 1.5f, -.1f));
                    CreateBranchMarkers(artifact, node, definition, restoration, impact);
                    var biology = visual.AddComponent<CyanobacteriaController>();
                    biology.Configure(quests, camera.transform, new[] { visual.GetComponent<Renderer>() });
                    diagnostics.Add(biology);
                    if (i < 4)
                    {
                        var metric = visual.AddComponent<EcologyThermalDriver>();
                        EcologyThermalDriver.Metric[] metrics =
                        { EcologyThermalDriver.Metric.Habitat, EcologyThermalDriver.Metric.Pollution,
                          EcologyThermalDriver.Metric.Toxicity, EcologyThermalDriver.Metric.FloodRisk };
                        Edit(metric, so =>
                        {
                            Ref(so, "quests", quests); Ref(so, "surface", biology);
                            so.FindProperty("metric").enumValueIndex = (int)metrics[i];
                            so.FindProperty("invert").boolValue = i == 0;
                        });
                    }
                }
                finally { Object.DestroyImmediate(definition); }
            }

            CreatePool(quests, camera, stone, living, restoration, diagnostics);
            Edit(interaction, so =>
            {
                var array = so.FindProperty("diagnosticSurfaces"); array.arraySize = diagnostics.Count;
                for (int i = 0; i < diagnostics.Count; i++) array.GetArrayElementAtIndex(i).objectReferenceValue = diagnostics[i];
            });

            string scenePath = AssetDatabase.GenerateUniqueAssetPath(Root + "/Scenes/DesktopDemo.unity");
            EditorSceneManager.MarkSceneDirty(scene);
            if (!EditorSceneManager.SaveScene(scene, scenePath)) throw new InvalidOperationException("Could not save the desktop demo scene.");
            AssetDatabase.SaveAssets();
            Selection.activeGameObject = player;
            if (SceneView.lastActiveSceneView != null) SceneView.lastActiveSceneView.AlignViewToObject(camera.transform);
            Debug.Log("Desktop demo ready at " + scenePath + ". Press Play: WASD move, mouse look, E/click interact, F photograph, T diagnostics, Esc close/release cursor.");
        }

        private static void CreateChoicePanel(ArtifactChoicePanel panel, Camera camera)
        {
            var canvasObject = new GameObject("Choice Canvas", typeof(RectTransform), typeof(Canvas), typeof(GraphicRaycaster));
            var canvas = canvasObject.GetComponent<Canvas>(); canvas.renderMode = RenderMode.WorldSpace; canvas.worldCamera = camera;
            var rect = canvasObject.GetComponent<RectTransform>(); rect.sizeDelta = new Vector2(1000, 650); rect.localScale = Vector3.one * .001f;
            var background = canvasObject.AddComponent<Image>(); background.color = new Color(.035f, .075f, .09f, .98f);
            Text title = Text("Artifact Title", rect, new Vector2(25, -20), new Vector2(950, 65), 38, TextAnchor.UpperLeft);
            Text description = Text("Description", rect, new Vector2(25, -100), new Vector2(950, 110), 27, TextAnchor.UpperLeft);
            Text status = Text("Status", rect, new Vector2(25, -210), new Vector2(950, 75), 25, TextAnchor.UpperLeft);
            var container = new GameObject("Choices", typeof(RectTransform), typeof(VerticalLayoutGroup));
            container.transform.SetParent(rect, false);
            Place(container.GetComponent<RectTransform>(), new Vector2(25, -300), new Vector2(950, 225));
            var layout = container.GetComponent<VerticalLayoutGroup>();
            layout.spacing = 18; layout.childControlWidth = true; layout.childControlHeight = true;
            layout.childForceExpandWidth = true; layout.childForceExpandHeight = false;
            Button template = Button("Choice Button Template", panel.transform, "Choice");
            template.gameObject.SetActive(false);
            Button close = Button("Close", rect, "Close");
            Place(close.GetComponent<RectTransform>(), new Vector2(800, -565), new Vector2(175, 60));
            UnityEventTools.AddPersistentListener(close.onClick, panel.Close);
            Edit(panel, so =>
            {
                Ref(so, "panelRoot", canvasObject); Ref(so, "title", title); Ref(so, "description", description);
                Ref(so, "status", status); Ref(so, "buttonContainer", container.transform); Ref(so, "buttonPrefab", template);
            });
        }

        private static void CreateHud(QuestManager quests, Camera camera, Material living)
        {
            var hud = new GameObject("Desktop HUD", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler));
            hud.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = hud.GetComponent<CanvasScaler>(); scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1280, 720); scaler.matchWidthOrHeight = .5f;
            Text instructions = Text("Controls", hud.transform, new Vector2(24, -20), new Vector2(900, 95), 21, TextAnchor.UpperLeft);
            instructions.text = "WASD move  |  Mouse look  |  E / click interact\nF photograph  |  T environmental view  |  Esc close / release cursor";
            Text crosshair = Text("Aim", hud.transform, Vector2.zero, new Vector2(40, 40), 30, TextAnchor.MiddleCenter);
            var crossRect = crosshair.rectTransform; crossRect.anchorMin = crossRect.anchorMax = crossRect.pivot = new Vector2(.5f, .5f);
            crossRect.anchoredPosition = Vector2.zero; crosshair.text = "+";
            Text subtitle = Text("ISO Subtitle", hud.transform, Vector2.zero, new Vector2(1100, 115), 26, TextAnchor.MiddleCenter);
            subtitle.rectTransform.anchorMin = subtitle.rectTransform.anchorMax = subtitle.rectTransform.pivot = new Vector2(.5f, 0);
            subtitle.rectTransform.anchoredPosition = new Vector2(0, 35);
            var group = subtitle.gameObject.AddComponent<CanvasGroup>();
            var isoVisual = Primitive("ISO", PrimitiveType.Sphere, null, new Vector3(.8f, 1.5f, -2.7f), Vector3.one * .24f, living);
            isoVisual.layer = 2; Object.DestroyImmediate(isoVisual.GetComponent<Collider>());
            var iso = isoVisual.AddComponent<IsoCompanion>(); iso.Configure(quests, camera.transform);
            var presenter = hud.AddComponent<IsoSubtitlePresenter>();
            Edit(presenter, so => { Ref(so, "iso", iso); Ref(so, "subtitle", subtitle); Ref(so, "visibility", group); });
        }

        private static void CreateBranchMarkers(GameObject owner, ArtifactNode node, ArtifactDefinition data, Material restored, Material impact)
        {
            if (data.Choices.Count == 0) return;
            var consequences = owner.AddComponent<ArtifactConsequenceView>();
            var markers = new GameObject[data.Choices.Count];
            for (int i = 0; i < markers.Length; i++)
            {
                var choice = data.Choices[i];
                markers[i] = Primitive("Consequence - " + choice.Id, PrimitiveType.Cube, owner.transform,
                    new Vector3(0, .16f, -.7f), new Vector3(.85f, .25f, .25f), choice.IsRestorative ? restored : impact);
                Object.DestroyImmediate(markers[i].GetComponent<Collider>());
                markers[i].SetActive(false);
            }
            Edit(consequences, so =>
            {
                Ref(so, "artifact", node);
                var branches = so.FindProperty("branches"); branches.arraySize = markers.Length;
                for (int i = 0; i < markers.Length; i++)
                {
                    var branch = branches.GetArrayElementAtIndex(i);
                    branch.FindPropertyRelative("choiceId").stringValue = data.Choices[i].Id;
                    var objects = branch.FindPropertyRelative("objects"); objects.arraySize = 1;
                    objects.GetArrayElementAtIndex(0).objectReferenceValue = markers[i];
                }
            });
        }

        private static void CreatePool(QuestManager quests, Camera camera, Material stone, Material living,
            Material restored, List<CyanobacteriaController> diagnostics)
        {
            var pool = new GameObject("Central Pool"); pool.transform.position = new Vector3(0, 0, 6);
            Primitive("Pool Base", PrimitiveType.Cylinder, pool.transform, new Vector3(0, .1f, 0), new Vector3(3, .1f, 3), stone);
            var water = Primitive("Water Surface", PrimitiveType.Cylinder, pool.transform, new Vector3(0, .25f, 0), new Vector3(2.7f, .025f, 2.7f), living);
            Object.DestroyImmediate(water.GetComponent<Collider>());
            var biology = water.AddComponent<CyanobacteriaController>();
            biology.Configure(quests, camera.transform, new[] { water.GetComponent<Renderer>() }); diagnostics.Add(biology);
            var memory = new GameObject("Final Memory"); memory.transform.SetParent(pool.transform, false);
            Primitive("Memory Light", PrimitiveType.Sphere, memory.transform, new Vector3(0, 1.4f, 0), Vector3.one * .65f, restored);
            Label("Four streams, one living home.", memory.transform, new Vector3(0, 2.1f, -.2f));
            memory.SetActive(false);
            var poolView = pool.AddComponent<CentralPoolView>();
            Edit(poolView, so =>
            {
                Ref(so, "quests", quests); Ref(so, "waterSurface", water.transform); Ref(so, "finalMemoryRoot", memory);
                so.FindProperty("emptyLocalY").floatValue = .25f; so.FindProperty("fullLocalY").floatValue = .8f;
            });
            WaterChannel[] channels = { WaterChannel.Water, WaterChannel.Lotus, WaterChannel.Lantern, WaterChannel.Rice };
            for (int i = 0; i < channels.Length; i++)
            {
                var valveRoot = new GameObject(channels[i] + " Channel Valve");
                valveRoot.transform.position = new Vector3(-2.25f + i * 1.5f, 0, 4.2f);
                Primitive("Valve", PrimitiveType.Cylinder, valveRoot.transform, new Vector3(0, .5f, 0), new Vector3(.4f, .5f, .4f), stone);
                Label(channels[i].ToString(), valveRoot.transform, new Vector3(0, 1.15f, -.05f));
                var valve = valveRoot.AddComponent<WaterChannelValve>(); valve.Configure(quests, channels[i]);
                var indicator = Primitive("Connected Indicator", PrimitiveType.Sphere, valveRoot.transform,
                    new Vector3(0, 1.35f, 0), Vector3.one * .17f, restored);
                Object.DestroyImmediate(indicator.GetComponent<Collider>()); indicator.SetActive(false);
                UnityEventTools.AddPersistentListener(Event<bool>(valve, "onConnectedState"), indicator.SetActive);
            }
        }

        private static GameObject Primitive(string name, PrimitiveType type, Transform parent, Vector3 position, Vector3 scale, Material material)
        {
            var result = GameObject.CreatePrimitive(type); result.name = name;
            if (parent != null) result.transform.SetParent(parent, false);
            result.transform.localPosition = position; result.transform.localScale = scale;
            result.GetComponent<Renderer>().sharedMaterial = material;
            return result;
        }
        private static GameObject Child(string name, Transform parent)
        { var result = new GameObject(name); result.transform.SetParent(parent, false); return result; }

        private static Material Material(string name, Color color, float emission)
        {
            string path = MaterialFolder + "/" + name + ".mat";
            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (material != null) return material;
            material = new Material(Shader.Find("RiversInTheSky/PainterlyBioluminescence")) { name = name };
            material.SetColor("_BaseColor", color); material.SetFloat("_EmissionStrength", emission);
            AssetDatabase.CreateAsset(material, path); return material;
        }
        private static void Label(string value, Transform parent, Vector3 localPosition)
        {
            var label = Child("Label", parent); label.transform.localPosition = localPosition;
            var text = label.AddComponent<TextMesh>(); text.text = value; text.font = Font; text.fontSize = 64;
            text.characterSize = .045f; text.anchor = TextAnchor.MiddleCenter; text.alignment = TextAlignment.Center;
            text.color = new Color(.85f, 1f, .94f); label.GetComponent<Renderer>().sharedMaterial = Font.material;
        }
        private static Text Text(string name, Transform parent, Vector2 position, Vector2 size, int fontSize, TextAnchor alignment)
        {
            var result = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));
            result.transform.SetParent(parent, false);
            var text = result.GetComponent<Text>(); text.font = Font; text.fontSize = fontSize;
            text.color = new Color(.9f, .97f, .95f); text.alignment = alignment; text.raycastTarget = false;
            text.horizontalOverflow = HorizontalWrapMode.Wrap; text.verticalOverflow = VerticalWrapMode.Truncate;
            Place(text.rectTransform, position, size); return text;
        }
        private static Button Button(string name, Transform parent, string caption)
        {
            var result = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button), typeof(LayoutElement));
            result.transform.SetParent(parent, false); result.GetComponent<Image>().color = new Color(.1f, .25f, .26f);
            result.GetComponent<LayoutElement>().preferredHeight = 95f;
            var button = result.GetComponent<Button>(); button.targetGraphic = result.GetComponent<Image>();
            var label = Text("Text", result.transform, Vector2.zero, Vector2.zero, 27, TextAnchor.MiddleCenter); label.text = caption;
            label.rectTransform.anchorMin = Vector2.zero; label.rectTransform.anchorMax = Vector2.one;
            label.rectTransform.offsetMin = new Vector2(14, 8); label.rectTransform.offsetMax = new Vector2(-14, -8);
            return button;
        }
        private static void Place(RectTransform rect, Vector2 position, Vector2 size)
        {
            rect.anchorMin = rect.anchorMax = rect.pivot = new Vector2(0, 1);
            rect.anchoredPosition = position; rect.sizeDelta = size;
        }
        private static void Edit(Object target, Action<SerializedObject> update)
        { var so = new SerializedObject(target); update(so); so.ApplyModifiedPropertiesWithoutUndo(); }
        private static void Ref(SerializedObject so, string field, Object value)
        {
            SerializedProperty property = so.FindProperty(field);
            if (property == null) throw new MissingFieldException(so.targetObject.GetType().Name, field);
            property.objectReferenceValue = value;
        }
        private static UnityEvent<T> Event<T>(Object owner, string field)
        {
            var member = owner.GetType().GetField(field, BindingFlags.Instance | BindingFlags.NonPublic);
            return (UnityEvent<T>)(member?.GetValue(owner) ?? throw new MissingFieldException(owner.GetType().Name, field));
        }
        private static void EnsureFolder(string path)
        {
            string[] parts = path.Split('/'); string parent = parts[0];
            for (int i = 1; i < parts.Length; i++)
            { if (!AssetDatabase.IsValidFolder(parent + "/" + parts[i])) AssetDatabase.CreateFolder(parent, parts[i]); parent += "/" + parts[i]; }
        }
    }
}
```

## Assets/RiversInTheSky/Editor/RiversAuthoringTools.cs

```csharp
using System;
using UnityEditor;
using UnityEngine;

namespace RiversInTheSky.Editor
{
    /// <summary>
    /// Creates editable assets from the same complete catalog used by the runtime fallback.
    /// Existing assets are preserved, so rerunning the menu cannot erase authored narrative.
    /// </summary>
    public static class RiversAuthoringTools
    {
        private const string DataFolder = "Assets/RiversInTheSky/Data";

        [MenuItem("Tools/Rivers in the Sky/Create Default Artifact Assets")]
        public static void CreateDefaultArtifactAssets()
        {
            EnsureFolder("Assets", "RiversInTheSky");
            EnsureFolder("Assets/RiversInTheSky", "Data");
            foreach (ArtifactId id in Enum.GetValues(typeof(ArtifactId)))
            {
                string path = $"{DataFolder}/{id}.asset";
                if (AssetDatabase.LoadMainAssetAtPath(path) != null) continue;
                ArtifactDefinition definition = ArtifactDefinition.CreateDefault(id);
                AssetDatabase.CreateAsset(definition, path);
            }
            AssetDatabase.SaveAssets();
            Selection.activeObject = AssetDatabase.LoadAssetAtPath<DefaultAsset>(DataFolder);
            EditorGUIUtility.PingObject(Selection.activeObject);
            Debug.Log("Five artifact assets are ready. Assign them to QuestManager, or leave its array empty to use runtime defaults.");
        }

        [MenuItem("Tools/Rivers in the Sky/Validate Artifact Assets")]
        public static void ValidateArtifactAssets()
        {
            int valid = 0;
            foreach (string guid in AssetDatabase.FindAssets("t:ArtifactDefinition"))
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                ArtifactDefinition definition = AssetDatabase.LoadAssetAtPath<ArtifactDefinition>(path);
                if (!definition.Validate(out string error)) Debug.LogError($"{path}: {error}", definition);
                else valid++;
            }
            Debug.Log($"Validated {valid} artifact definitions. Duplicate IDs are permitted across catalogs; each QuestManager accepts one definition per ID.");
        }

        private static void EnsureFolder(string parent, string name)
        {
            if (!AssetDatabase.IsValidFolder(parent + "/" + name)) AssetDatabase.CreateFolder(parent, name);
        }
    }
}
```

## Assets/RiversInTheSky/Editor/RiversInTheSky.Editor.asmdef

```json
{
  "name": "RiversInTheSky.Editor",
  "rootNamespace": "RiversInTheSky.Editor",
  "references": [
    "RiversInTheSky.Runtime",
    "Unity.InputSystem",
    "UnityEngine.UI",
    "Unity.RenderPipelines.Core.Runtime",
    "Unity.RenderPipelines.Universal.Runtime"
  ],
  "includePlatforms": ["Editor"],
  "autoReferenced": true
}
```

## Assets/RiversInTheSky/Runtime/Audio/AudioLandscapeManager.cs

```csharp
using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Audio;

namespace RiversInTheSky
{
    /// <summary>
    /// Keeps every folk-song stem on one DSP timeline. Quest changes affect gain,
    /// never playback position, so revealing a layer cannot restart the song.
    /// Audio media is authored separately; assign licensed/owned performances of Đi Cấy.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class AudioLandscapeManager : MonoBehaviour
    {
        [Header("State and routing")]
        [SerializeField] private QuestManager quests;
        [SerializeField] private AudioMixerGroup ambienceBus;
        [SerializeField] private AudioMixerGroup musicBus;

        [Header("Looped soundscapes")]
        [SerializeField] private AudioClip wind;
        [SerializeField] private AudioClip underwater;
        [SerializeField, Range(0f, 1f)] private float ambienceGain = 0.45f;
        [SerializeField, Range(0f, 1f)] private float underwaterBlend;

        [Header("Five aligned Đi Cấy stems, one revealed per artifact")]
        [Tooltip("Export all stems from the same bar range, with matching duration and sample rate. Include silence before each fragment where appropriate.")]
        [SerializeField] private AudioClip[] folkStems = new AudioClip[5];
        [SerializeField, Range(0f, 1f)] private float musicGain = 0.4f;
        [SerializeField, Min(0.05f)] private float fadeSeconds = 2f;
        [SerializeField, Min(0.05f)] private float scheduleLeadSeconds = 0.2f;

        private GameObject ownedRoot;
        private AudioSource windSource;
        private AudioSource underwaterSource;
        private AudioSource[] stemSources;
        private Coroutine preparation;
        private QuestManager subscribedQuests;
        private int resolvedCount;
        private int cleansedCount;
        private bool ready;
        private bool applicationPaused;
        private bool scheduled;
        private double scheduledStart;
        private double remainingLeadOnPause;
        private float smoothedWaterBlend;

        public bool IsReady => ready;

        private void Awake()
        {
            // This component owns only these generated children, never scene-authored sources.
            ownedRoot = new GameObject("Audio Landscape Sources");
            ownedRoot.transform.SetParent(transform, false);
            windSource = CreateSource("Wind", wind, ambienceBus);
            underwaterSource = CreateSource("Underwater", underwater, ambienceBus);
            stemSources = new AudioSource[5];
            for (int i = 0; i < stemSources.Length; i++)
            {
                AudioClip clip = folkStems != null && i < folkStems.Length ? folkStems[i] : null;
                stemSources[i] = CreateSource("Đi Cấy Stem " + (i + 1), clip, musicBus);
            }
            smoothedWaterBlend = Mathf.Clamp01(underwaterBlend);
        }

        private void OnEnable()
        {
            BindQuest();
            preparation = StartCoroutine(PrepareAndSchedule());
        }

        private void OnDisable()
        {
            UnbindQuest();
            if (preparation != null) StopCoroutine(preparation);
            preparation = null;
            ForEachSource(source => { source.Stop(); source.volume = 0f; });
            ready = scheduled = false;
        }

        private void OnDestroy()
        {
            if (ownedRoot != null) Destroy(ownedRoot);
        }

        /// <summary>Rebinds state without disturbing the current music timeline.</summary>
        public void Configure(QuestManager manager)
        {
            UnbindQuest();
            quests = manager;
            if (isActiveAndEnabled) BindQuest();
        }

        /// <summary>Drive with a water-volume sensor, swim depth, or an authored trigger.</summary>
        public void SetUnderwaterBlend(float blend) => underwaterBlend = Mathf.Clamp01(blend);

        private void BindQuest()
        {
            if (quests == null) return;
            subscribedQuests = quests;
            subscribedQuests.StateChanged += OnStateChanged;
            OnStateChanged(subscribedQuests.Snapshot);
        }

        private void UnbindQuest()
        {
            if (subscribedQuests != null) subscribedQuests.StateChanged -= OnStateChanged;
            subscribedQuests = null;
        }

        private void OnStateChanged(QuestSnapshot snapshot)
        {
            if (snapshot == null) return;
            resolvedCount = Mathf.Clamp(snapshot.ResolvedCount, 0, 5);
            cleansedCount = Mathf.Clamp(snapshot.CleansedCount, 0, resolvedCount);
        }

        private AudioSource CreateSource(string sourceName, AudioClip clip, AudioMixerGroup bus)
        {
            var child = new GameObject(sourceName);
            child.transform.SetParent(ownedRoot.transform, false);
            var source = child.AddComponent<AudioSource>();
            source.clip = clip;
            source.playOnAwake = false;
            source.loop = true;
            source.spatialBlend = 0f; // An encompassing landscape; positional sound belongs elsewhere.
            source.dopplerLevel = 0f;
            source.volume = 0f;
            source.outputAudioMixerGroup = bus;
            return source;
        }

        private IEnumerator PrepareAndSchedule()
        {
            // Unloaded clips cannot be scheduled reliably. Loading is asynchronous on platforms
            // that support it; a bad asset cannot hold the entire landscape indefinitely.
            ForEachSource(source =>
            {
                if (source.clip != null && source.clip.loadState == AudioDataLoadState.Unloaded)
                    source.clip.LoadAudioData();
            });
            float deadline = Time.realtimeSinceStartup + 15f;
            bool loading;
            do
            {
                loading = false;
                ForEachSource(source =>
                {
                    if (source.clip != null && source.clip.loadState == AudioDataLoadState.Loading)
                        loading = true;
                });
                if (loading) yield return null;
            } while (loading && Time.realtimeSinceStartup < deadline);

            ForEachSource(source =>
            {
                if (source.clip != null && source.clip.loadState != AudioDataLoadState.Loaded)
                {
                    Debug.LogWarning("Landscape clip could not load: " + source.clip.name, this);
                    source.clip = null;
                }
            });
            ValidateStemTiming();
            while (applicationPaused) yield return null;
            ScheduleAll();
            ready = true;
            preparation = null;
        }

        private void ScheduleAll()
        {
            scheduledStart = AudioSettings.dspTime + Math.Max(0.05, scheduleLeadSeconds);
            ForEachSource(source =>
            {
                if (source.clip == null) return;
                source.Stop();
                source.timeSamples = 0;
                source.PlayScheduled(scheduledStart);
            });
            scheduled = true;
        }

        private void ValidateStemTiming()
        {
            AudioClip reference = null;
            foreach (AudioSource source in stemSources)
            {
                if (source.clip == null) continue;
                if (reference == null) { reference = source.clip; continue; }
                if (source.clip.samples != reference.samples || source.clip.frequency != reference.frequency)
                {
                    Debug.LogWarning("Đi Cấy stems need identical sample counts and sample rates for seamless repeating alignment. Re-export the stems from one timeline.", this);
                    break;
                }
            }
        }

        private void Update()
        {
            if (!ready || applicationPaused) return;
            float step = Time.unscaledDeltaTime / Mathf.Max(0.05f, fadeSeconds);
            smoothedWaterBlend = Mathf.MoveTowards(smoothedWaterBlend, underwaterBlend, step);
            // Equal-power environmental crossfade, with independent master headroom.
            Fade(windSource, ambienceGain * Mathf.Sqrt(1f - smoothedWaterBlend), step);
            Fade(underwaterSource, ambienceGain * Mathf.Sqrt(smoothedWaterBlend), step);

            int audibleStemCount = 0;
            for (int i = 0; i < resolvedCount; i++)
                if (stemSources[i].clip != null) audibleStemCount++;
            // Normalize the sum of target stem gains. Restoration subtly opens the music,
            // while every branch still reveals a fragment and reaches the final arrangement.
            float restoration = resolvedCount == 0 ? 0f : (float)cleansedCount / resolvedCount;
            float perStem = musicGain * Mathf.Lerp(0.7f, 1f, restoration) / Mathf.Max(1, audibleStemCount);
            for (int i = 0; i < stemSources.Length; i++)
                Fade(stemSources[i], i < resolvedCount ? perStem : 0f, step);
        }

        private static void Fade(AudioSource source, float target, float step)
        {
            source.volume = Mathf.MoveTowards(source.volume, Mathf.Clamp01(target), step);
        }

        private void OnApplicationPause(bool paused)
        {
            applicationPaused = paused;
            if (!scheduled || !isActiveAndEnabled) return;
            if (paused)
            {
                // A scheduled start that has not happened needs to be scheduled again after
                // resume; an already-playing loop preserves its exact sample cursor.
                remainingLeadOnPause = Math.Max(0.0, scheduledStart - AudioSettings.dspTime);
                if (remainingLeadOnPause > 0.0) ForEachSource(source => source.Stop());
                else ForEachSource(source => source.Pause());
            }
            else if (remainingLeadOnPause > 0.0)
            {
                ScheduleAll();
                remainingLeadOnPause = 0.0;
            }
            else ForEachSource(source => source.UnPause());
        }

        private void ForEachSource(Action<AudioSource> action)
        {
            if (windSource != null) action(windSource);
            if (underwaterSource != null) action(underwaterSource);
            if (stemSources == null) return;
            foreach (AudioSource source in stemSources)
                if (source != null) action(source);
        }

        private void OnValidate()
        {
            fadeSeconds = Mathf.Max(0.05f, fadeSeconds);
            scheduleLeadSeconds = Mathf.Max(0.05f, scheduleLeadSeconds);
            if (folkStems == null) folkStems = new AudioClip[5];
            else if (folkStems.Length != 5) Array.Resize(ref folkStems, 5);
        }
    }
}
```

## Assets/RiversInTheSky/Runtime/Audio/WaterAudioDepthDriver.cs

```csharp
using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>Drives the ambience crossfade from the view camera's depth below a water plane.</summary>
    [DisallowMultipleComponent]
    public sealed class WaterAudioDepthDriver : MonoBehaviour
    {
        [SerializeField] private AudioLandscapeManager landscape;
        [SerializeField] private Transform playerHead;
        [SerializeField] private Transform waterSurface;
        [Tooltip("Optional box/sphere/capsule or convex mesh defining this water region.")]
        [SerializeField] private Collider waterRegion;
        [SerializeField, Min(0.01f)] private float transitionDepth = 0.25f;

        private void Update()
        {
            if (landscape == null || playerHead == null || waterSurface == null) return;
            Vector3 head = playerHead.position;
            // ClosestPoint returns the supplied point when it is inside a supported volume.
            bool insideRegion = waterRegion == null ||
                (waterRegion.ClosestPoint(head) - head).sqrMagnitude < 0.0001f;
            float depth = waterSurface.position.y - head.y;
            landscape.SetUnderwaterBlend(insideRegion
                ? Mathf.InverseLerp(-transitionDepth, transitionDepth, depth) : 0f);
        }

        private void OnDisable()
        {
            if (landscape != null) landscape.SetUnderwaterBlend(0f);
        }
    }
}
```

## Assets/RiversInTheSky/Runtime/Companion/IsoCompanion.cs

```csharp
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace RiversInTheSky
{
    /// <summary>
    /// A flying companion driven by authoritative quest state. Restoration updates its act,
    /// but only live decisions enqueue speech, so loading never repeats a conversation.
    /// This component moves ISO only; it never changes the player or view camera pose.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class IsoCompanion : MonoBehaviour
    {
        [Serializable] public sealed class SubtitleEvent : UnityEvent<string> { }
        [Serializable] public sealed class ActEvent : UnityEvent<IsoAct> { }

        [Serializable]
        private sealed class DialogueOverride
        {
            [SerializeField] internal ArtifactId artifact;
            [SerializeField] internal bool restorative;
            [SerializeField] internal IsoAct act;
            [SerializeField, TextArea(2, 6)] internal string subtitle;
            [SerializeField] internal AudioClip voice;
            [SerializeField, Min(0.5f)] internal float minimumSeconds = 4f;
        }

        [Header("Explicit scene references")]
        [SerializeField] private QuestManager quests;
        [SerializeField] private Transform playerHead;
        [Tooltip("Optional spatial AudioSource on ISO, exclusively owned by this component.")]
        [SerializeField] private AudioSource voiceSource;

        [Header("Head-relative position; world gravity remains upright")]
        [SerializeField] private Vector3 localOffset = new Vector3(0.8f, -0.1f, 1.3f);
        [SerializeField] private Vector3 axisSmoothTimes = new Vector3(0.45f, 0.65f, 0.45f);
        [SerializeField, Min(0.1f)] private float maximumSpeed = 3f;
        [SerializeField, Min(0.1f)] private float teleportThreshold = 4f;
        [SerializeField, Min(0f)] private float bobAmplitude = 0.06f;
        [SerializeField, Min(0f)] private float bobFrequency = 0.45f;
        [SerializeField, Min(0f)] private float rotationSharpness = 5f;

        [Header("Optional obstacle avoidance")]
        [Tooltip("Static environment layers only. Exclude player, ISO and trigger volumes.")]
        [SerializeField] private LayerMask obstacleMask;
        [SerializeField, Min(0.01f)] private float collisionRadius = 0.12f;
        [SerializeField, Min(0f)] private float wallMargin = 0.03f;

        [Header("Dialogue; overrides replace the included original English lines")]
        [SerializeField] private DialogueOverride[] dialogueOverrides = Array.Empty<DialogueOverride>();
        [SerializeField, TextArea(2, 6)] private string finalMemorySubtitle =
            "Four streams, one home. I thought these waters were something to take. Now I understand why you stayed to care for them.";
        [SerializeField] private AudioClip finalMemoryVoice;
        [SerializeField, Min(0.5f)] private float secondsPerLine = 5f;
        [SerializeField] private SubtitleEvent onSubtitleChanged = new SubtitleEvent();
        [SerializeField] private ActEvent onActChanged = new ActEvent();

        public IsoAct Act { get; private set; } = IsoAct.AnalyticalCurious;
        public string CurrentSubtitle { get; private set; } = string.Empty;
        public event Action<string> SubtitleChanged;
        public event Action<IsoAct> ActChanged;

        private readonly Queue<Line> lines = new Queue<Line>();
        private QuestManager subscribedQuests;
        private Coroutine speech;
        private Vector3 dampingVelocity;
        private Vector3 previousHeadPosition;
        private Vector3 lastFlatForward = Vector3.forward;
        private bool hasTrackedTarget;

        private readonly struct Line
        {
            internal readonly string Text;
            internal readonly AudioClip Voice;
            internal readonly float MinimumSeconds;
            internal Line(string text, AudioClip voice, float seconds)
            { Text = text; Voice = voice; MinimumSeconds = seconds; }
        }

        /// <summary>May be called by a scene bootstrapper before or after enabling ISO.</summary>
        public void Configure(QuestManager manager, Transform head)
        {
            Unsubscribe();
            quests = manager;
            playerHead = head;
            hasTrackedTarget = false;
            if (isActiveAndEnabled) Subscribe();
        }

        private void OnEnable()
        {
            hasTrackedTarget = false;
            if (voiceSource != null)
            {
                voiceSource.playOnAwake = false;
                voiceSource.loop = false;
            }
            Subscribe();
        }

        private void OnDisable()
        {
            Unsubscribe();
            if (speech != null) StopCoroutine(speech);
            speech = null;
            lines.Clear();
            if (voiceSource != null) voiceSource.Stop();
            SetSubtitle(string.Empty);
        }

        private void Subscribe()
        {
            if (quests == null || subscribedQuests == quests) return;
            subscribedQuests = quests;
            subscribedQuests.StateChanged += RestoreAct;
            subscribedQuests.ChoiceCommitted += ReactToChoice;
            subscribedQuests.FinalMemoryUnlocked += ReactToFinalMemory;
            RestoreAct(subscribedQuests.Snapshot);
        }

        private void Unsubscribe()
        {
            if (subscribedQuests == null) return;
            subscribedQuests.StateChanged -= RestoreAct;
            subscribedQuests.ChoiceCommitted -= ReactToChoice;
            subscribedQuests.FinalMemoryUnlocked -= ReactToFinalMemory;
            subscribedQuests = null;
        }

        private void RestoreAct(QuestSnapshot state)
        {
            if (state == null || Act == state.Act) return;
            Act = state.Act;
            onActChanged.Invoke(Act);
            ActChanged?.Invoke(Act);
        }

        private void LateUpdate()
        {
            if (playerHead == null) return;
            float dt = Time.deltaTime;
            // A vertical gaze has no reliable yaw; preserve the last valid horizontal heading.
            Vector3 flatForward = Vector3.ProjectOnPlane(playerHead.forward, Vector3.up);
            if (flatForward.sqrMagnitude > 0.001f) lastFlatForward = flatForward.normalized;
            Vector3 right = Vector3.Cross(Vector3.up, lastFlatForward);
            Vector3 desired = playerHead.position + right * localOffset.x +
                Vector3.up * localOffset.y + lastFlatForward * localOffset.z;
            desired.y += Mathf.Sin(Time.time * bobFrequency * Mathf.PI * 2f) * bobAmplitude;
            desired = ConstrainSegment(playerHead.position, desired);

            bool teleported = hasTrackedTarget &&
                (playerHead.position - previousHeadPosition).sqrMagnitude > teleportThreshold * teleportThreshold;
            if (!hasTrackedTarget || teleported)
            {
                // Do not fly rapidly across the map after teleport locomotion.
                transform.position = desired;
                dampingVelocity = Vector3.zero;
            }
            else if (dt > 0f)
            {
                Vector3 current = transform.position;
                Vector3 next = new Vector3(
                    Mathf.SmoothDamp(current.x, desired.x, ref dampingVelocity.x,
                        Mathf.Max(0.01f, axisSmoothTimes.x), maximumSpeed, dt),
                    Mathf.SmoothDamp(current.y, desired.y, ref dampingVelocity.y,
                        Mathf.Max(0.01f, axisSmoothTimes.y), maximumSpeed, dt),
                    Mathf.SmoothDamp(current.z, desired.z, ref dampingVelocity.z,
                        Mathf.Max(0.01f, axisSmoothTimes.z), maximumSpeed, dt));
                Vector3 constrained = ConstrainSegment(current, next);
                if ((constrained - next).sqrMagnitude > 0.000001f) dampingVelocity = Vector3.zero;
                transform.position = constrained;
            }

            Vector3 towardPlayer = playerHead.position - transform.position;
            if (towardPlayer.sqrMagnitude > 0.0001f)
                transform.rotation = Quaternion.Slerp(transform.rotation,
                    Quaternion.LookRotation(towardPlayer, Vector3.up),
                    1f - Mathf.Exp(-rotationSharpness * dt));
            previousHeadPosition = playerHead.position;
            hasTrackedTarget = true;
        }

        private Vector3 ConstrainSegment(Vector3 start, Vector3 end)
        {
            Vector3 delta = end - start;
            float distance = delta.magnitude;
            if (obstacleMask.value != 0 && distance > 0.0001f &&
                Physics.SphereCast(start, collisionRadius, delta / distance, out RaycastHit hit,
                    distance, obstacleMask, QueryTriggerInteraction.Ignore))
                return start + delta / distance * Mathf.Max(0f, hit.distance - wallMargin);
            return end;
        }

        private void ReactToChoice(ChoiceOutcome outcome)
        {
            // Act is derived from committed state, never advanced by the animation or dialogue queue.
            if (subscribedQuests != null) RestoreAct(subscribedQuests.Snapshot);
            foreach (DialogueOverride entry in dialogueOverrides)
            {
                if (entry == null || entry.artifact != outcome.Artifact ||
                    entry.restorative != outcome.Choice.IsRestorative || entry.act != outcome.Act) continue;
                string text = string.IsNullOrWhiteSpace(entry.subtitle)
                    ? DefaultLine(outcome.Artifact, outcome.Choice.IsRestorative, outcome.Act) : entry.subtitle;
                Enqueue(new Line(text, entry.voice, entry.minimumSeconds));
                return;
            }
            Enqueue(new Line(DefaultLine(outcome.Artifact, outcome.Choice.IsRestorative, outcome.Act), null, secondsPerLine));
        }

        private void ReactToFinalMemory()
        {
            Enqueue(new Line(finalMemorySubtitle, finalMemoryVoice, Mathf.Max(secondsPerLine, 7f)));
        }

        private void Enqueue(Line line)
        {
            if (!isActiveAndEnabled) return;
            lines.Enqueue(line);
            if (speech == null) speech = StartCoroutine(Speak());
        }

        private IEnumerator Speak()
        {
            while (lines.Count > 0)
            {
                Line line = lines.Dequeue();
                SetSubtitle(line.Text);
                float duration = Mathf.Max(0.5f, line.MinimumSeconds);
                if (voiceSource != null && line.Voice != null)
                {
                    voiceSource.clip = line.Voice;
                    voiceSource.Play();
                    duration = Mathf.Max(duration, line.Voice.length / Mathf.Max(0.01f, Mathf.Abs(voiceSource.pitch)));
                }
                // Unscaled wait avoids losing a subtitle when a comfort/menu pause stops world time.
                yield return new WaitForSecondsRealtime(duration);
                if (voiceSource != null) voiceSource.Stop();
                SetSubtitle(string.Empty);
                if (lines.Count > 0) yield return new WaitForSecondsRealtime(0.2f);
            }
            speech = null;
        }

        private void SetSubtitle(string text)
        {
            CurrentSubtitle = text ?? string.Empty;
            onSubtitleChanged.Invoke(CurrentSubtitle);
            SubtitleChanged?.Invoke(CurrentSubtitle);
        }

        private static string DefaultLine(ArtifactId artifact, bool restorative, IsoAct act)
        {
            // Artifacts may be visited in any order. The act selects ISO's interpretation,
            // while the branch selects the observed consequence; location never advances its arc.
            switch (artifact)
            {
                case ArtifactId.Pagoda:
                    return restorative
                        ? ForAct(act,
                            "The passage is restored. The connected wetland should improve water access. I will map its capacity.",
                            "The wetland is connected again. I wonder how many lives depend on this passage staying open.",
                            "You reopened the water's path. The wetland and pagoda can share it again. This is how we care for a living home.")
                        : ForAct(act,
                            "The entrance is open. Habitat damage recorded. I need to include that cost in the access calculation.",
                            "We opened the entrance, but broke a habitat. What lived there before we arrived? I am concerned about what we displaced.",
                            "We can enter now, and a shelter has been damaged. This place is home to others too. I want us to remember that loss.");
                case ArtifactId.Lotus:
                    return restorative
                        ? ForAct(act,
                            "The waste source is stopped. That should reduce repeated cleanup work and preserve the pond's usable water.",
                            "The waste has stopped arriving. Looking upstream helped us protect what was struggling here. I am learning to ask where harm begins.",
                            "The pond can recover without more waste arriving. The lotus has a chance to flourish in its own home. I am glad we stayed to help.")
                        : ForAct(act,
                            "Visible rubbish removed. The upstream source remains active, so I predict another cleanup will be necessary.",
                            "The surface is clearer, but waste still comes downstream. Will the lotus keep struggling after we leave?",
                            "We cleared space around the lotus. Waste is still arriving, and this living pond needs lasting care. I will remember what remains upstream.");
                case ArtifactId.Lamplight:
                    return restorative
                        ? ForAct(act,
                            "Solar light is available. A renewable input should extend the lantern's operating life without consuming stored cells.",
                            "The lantern holds a little sunlight. The water stays free of a leaking cell. I am beginning to understand why you waited.",
                            "The lantern keeps a little of the sun, and the water beneath it stays safe. Its warmth belongs in this home.")
                        : ForAct(act,
                            "The old cell powers the lantern. Toxic leakage detected. Immediate energy yield carries a contamination cost.",
                            "The lantern is lit, but the old cell is leaking. What will that light cost the life in this water?",
                            "The light is warm, but the cell is leaking into a living home. I feel the cost reaching beyond the lantern.");
                case ArtifactId.RiceField:
                    return restorative
                        ? ForAct(act,
                            "The wetland reduces flood risk and nutrient delivery. I will record the tradeoff between water control and rice productivity.",
                            "The wetland slows the flood, though fewer nutrients reach the rice. How can we help the field without putting its neighbours at risk?",
                            "The wetland shelters the field from flooding. Fewer nutrients reach the rice, so it will need continuing care. A home asks us to keep listening.")
                        : ForAct(act,
                            "Direct irrigation is active. Water reaches the rice quickly, with an increased flood risk. Both outcomes belong in the model.",
                            "The field receives water directly, and the flood risk rises. I am starting to see how one useful flow can threaten another life.",
                            "The gate brings water and flood risk to the rice. These lives share one stream with us. I want us to care for everyone it reaches.");
                default:
                    return ForAct(act,
                        "Water connections recorded. I will compare their resource flows.",
                        "These connected waters hold consequences I am still learning to see.",
                        "These waters carry the choices we made. I will remember what they have taught us about home.");
            }
        }

        private static string ForAct(IsoAct act, string analytical, string questioning, string empathetic)
        {
            switch (act)
            {
                case IsoAct.QuestionAndLearn: return questioning;
                case IsoAct.UnderstandingEmpathetic: return empathetic;
                default: return analytical;
            }
        }
    }
}
```

## Assets/RiversInTheSky/Runtime/Companion/IsoSubtitlePresenter.cs

```csharp
using UnityEngine;
using UnityEngine.UI;

namespace RiversInTheSky
{
    /// <summary>Connects ISO's queued dialogue to an existing world-space uGUI text panel.</summary>
    [DisallowMultipleComponent]
    public sealed class IsoSubtitlePresenter : MonoBehaviour
    {
        [SerializeField] private IsoCompanion iso;
        [SerializeField] private Text subtitle;
        [Tooltip("Optional CanvasGroup; keep the presenter enabled while the text is hidden.")]
        [SerializeField] private CanvasGroup visibility;

        private void OnEnable()
        {
            if (iso != null) iso.SubtitleChanged += Present;
            Present(iso != null ? iso.CurrentSubtitle : string.Empty);
        }

        private void OnDisable()
        {
            if (iso != null) iso.SubtitleChanged -= Present;
        }

        private void Present(string message)
        {
            if (subtitle != null) subtitle.text = message;
            if (visibility == null) return;
            visibility.alpha = string.IsNullOrEmpty(message) ? 0f : 1f;
            visibility.interactable = false;
            visibility.blocksRaycasts = false;
        }
    }
}
```

## Assets/RiversInTheSky/Runtime/Core/ArtifactConsequenceView.cs

```csharp
using System;
using UnityEngine;
using UnityEngine.Events;

namespace RiversInTheSky
{
    /// <summary>
    /// Reconstructs persistent scene changes from a chosen ID. Author an object group for each branch
    /// (damaged reeds, closed waste outlet, leakage particles, wetland route, reduced-nutrient crops).
    /// The group remains enabled on save restoration; one-shot narrative belongs to ChoiceCommitted.
    /// </summary>
    public sealed class ArtifactConsequenceView : MonoBehaviour
    {
        [Serializable]
        private sealed class Branch
        {
            public string choiceId;
            public GameObject[] objects = Array.Empty<GameObject>();
        }
        [SerializeField] private ArtifactNode artifact;
        [SerializeField] private GameObject[] unresolvedObjects = Array.Empty<GameObject>();
        [SerializeField] private Branch[] branches = Array.Empty<Branch>();
        [SerializeField] private UnityEvent<string> onConsequenceText = new UnityEvent<string>();
        private bool initialized;
        private string appliedId;
        private QuestManager bound;

        private void OnEnable()
        {
            bound = artifact != null ? artifact.Quests : null;
            if (bound == null) return;
            bound.StateChanged += Refresh;
            initialized = false;
            Refresh(bound.Snapshot);
        }
        private void OnDisable() { if (bound != null) bound.StateChanged -= Refresh; bound = null; }
        private void Refresh(QuestSnapshot snapshot)
        {
            if (snapshot == null || artifact == null) return;
            string chosen = bound.GetChoiceId(artifact.Id);
            if (initialized && chosen == appliedId) return;
            initialized = true; appliedId = chosen;
            foreach (GameObject item in unresolvedObjects) if (item != null) item.SetActive(chosen == null);
            foreach (Branch branch in branches)
                if (branch != null && branch.objects != null)
                    foreach (GameObject item in branch.objects)
                        if (item != null) item.SetActive(!string.IsNullOrEmpty(chosen) && branch.choiceId == chosen);
            ChoiceDefinition choice = artifact.Definition != null ? artifact.Definition.FindChoice(chosen) : null;
            onConsequenceText.Invoke(choice != null ? choice.ConsequenceText : string.Empty);
        }
    }
}
```

## Assets/RiversInTheSky/Runtime/Core/ArtifactDefinition.cs

```csharp
using System;
using System.Collections.Generic;
using UnityEngine;

namespace RiversInTheSky
{
    public enum ArtifactId { Pagoda, Lotus, Lamplight, RiceField, FourYoungMaidens }

    [Flags]
    public enum WaterChannel { None = 0, Lotus = 1, Lantern = 2, Rice = 4, Water = 8, All = 15 }

    public enum IsoAct { AnalyticalCurious, QuestionAndLearn, UnderstandingEmpathetic }

    /// <summary>Authored consequences, never mutable runtime progress. Deltas are illustrative game units.</summary>
    [Serializable]
    public sealed class ChoiceDefinition
    {
        [SerializeField] private string id;
        [SerializeField] private string label;
        [SerializeField, TextArea(2, 5)] private string consequenceText;
        [SerializeField] private bool isRestorative;
        [SerializeField] private int habitatDelta;
        [SerializeField] private int pollutionDelta;
        [SerializeField] private int toxicityDelta;
        [SerializeField] private int floodRiskDelta;
        [SerializeField] private int nutrientDelta;

        public string Id => id;
        public string Label => label;
        public string ConsequenceText => consequenceText;
        public bool IsRestorative => isRestorative;
        public int HabitatDelta => habitatDelta;
        public int PollutionDelta => pollutionDelta;
        public int ToxicityDelta => toxicityDelta;
        public int FloodRiskDelta => floodRiskDelta;
        public int NutrientDelta => nutrientDelta;

        public ChoiceDefinition(string id, string label, string consequenceText, bool restorative,
            int habitat = 0, int pollution = 0, int toxicity = 0, int floodRisk = 0, int nutrients = 0)
        {
            this.id = id;
            this.label = label;
            this.consequenceText = consequenceText;
            isRestorative = restorative;
            habitatDelta = habitat;
            pollutionDelta = pollution;
            toxicityDelta = toxicity;
            floodRiskDelta = floodRisk;
            nutrientDelta = nutrients;
        }
    }

    [CreateAssetMenu(menuName = "Rivers in the Sky/Artifact Definition")]
    public sealed class ArtifactDefinition : ScriptableObject
    {
        [SerializeField] private ArtifactId id;
        [SerializeField] private string displayName;
        [SerializeField, TextArea(2, 6)] private string description;
        [SerializeField] private ChoiceDefinition[] choices = Array.Empty<ChoiceDefinition>();

        public ArtifactId Id => id;
        public string DisplayName => displayName;
        public string Description => description;
        public IReadOnlyList<ChoiceDefinition> Choices => Array.AsReadOnly(choices ?? Array.Empty<ChoiceDefinition>());

        // Used by the editor bootstrap and runtime fallback catalog; choice IDs are stable save keys.
        public void Initialize(ArtifactId artifact, string title, string body, params ChoiceDefinition[] options)
        {
            id = artifact;
            displayName = title;
            description = body;
            choices = options == null ? Array.Empty<ChoiceDefinition>() : (ChoiceDefinition[])options.Clone();
        }

        public ChoiceDefinition FindChoice(string choiceId)
        {
            if (choices == null) return null;
            foreach (ChoiceDefinition choice in choices)
                if (choice != null && string.Equals(choice.Id, choiceId, StringComparison.Ordinal)) return choice;
            return null;
        }

        public bool Validate(out string error)
        {
            if (!Enum.IsDefined(typeof(ArtifactId), id) || string.IsNullOrWhiteSpace(displayName))
            { error = "Artifact needs a valid ID and display name."; return false; }
            if (id == ArtifactId.FourYoungMaidens)
            {
                error = null;
                return true; // Its interactions are the four channel valves, not a binary choice.
            }
            var seen = new HashSet<string>(StringComparer.Ordinal);
            if (choices == null || choices.Length < 2)
            { error = $"{displayName} requires at least two choices."; return false; }
            foreach (ChoiceDefinition choice in choices)
            {
                if (choice == null || string.IsNullOrWhiteSpace(choice.Id) ||
                    string.IsNullOrWhiteSpace(choice.Label) || !seen.Add(choice.Id))
                { error = $"{displayName} has a blank or duplicate choice ID/label."; return false; }
            }
            error = null;
            return true;
        }

        /// <summary>Complete playable defaults. Replace with assets to author/localize the narrative.</summary>
        public static ArtifactDefinition CreateDefault(ArtifactId artifact)
        {
            var result = CreateInstance<ArtifactDefinition>();
            switch (artifact)
            {
                case ArtifactId.Pagoda:
                    result.Initialize(artifact, "The Pagoda", "A flooded threshold shelters a living wetland.",
                        new ChoiceDefinition("force_entrance", "Force Entrance (Habitat Damage)",
                            "The stone door opens, but the nesting reeds are crushed.", false, habitat: -2),
                        new ChoiceDefinition("restore_passage", "Restore Water Passage (Connect Wetland)",
                            "Water returns through the passage and reconnects the wetland.", true, habitat: 2));
                    break;
                case ArtifactId.Lotus:
                    result.Initialize(artifact, "The Lotus", "Waste drifts through a luminous lotus pond.",
                        new ChoiceDefinition("remove_rubbish", "Remove Visible Rubbish",
                            "The surface clears. The upstream outlet continues to bring waste.", false, pollution: -1),
                        new ChoiceDefinition("stop_source", "Stop Waste at Source",
                            "The waste outlet closes. The pond can recover beyond its visible surface.", true, pollution: -3));
                    break;
                case ArtifactId.Lamplight:
                    result.Initialize(artifact, "The Lamplight", "An old lantern waits for energy.",
                        new ChoiceDefinition("old_cell", "Use Old Energy Cell (Toxic Leakage)",
                            "The lantern glows; the damaged cell leaks into the water below.", false, toxicity: 2),
                        new ChoiceDefinition("sunlight", "Harness Sunlight (Sustainable Illumination)",
                            "A sun collector stores enough light to keep the lantern glowing after twilight.", true));
                    break;
                case ArtifactId.RiceField:
                    result.Initialize(artifact, "The Rice Field", "The terraces need water, with consequences downstream.",
                        new ChoiceDefinition("direct_gate", "Open Direct Irrigation Gate (Flood Risk)",
                            "Nutrient-rich water reaches the field quickly; downstream flood risk rises.", false,
                            floodRisk: 2, nutrients: 2),
                        new ChoiceDefinition("wetland_route", "Redirect Through Wetland (Reduced Nutrients)",
                            "The wetland slows the flow and reduces flood risk, while retaining some nutrients.", true,
                            habitat: 1, floodRisk: -1, nutrients: -1));
                    break;
                case ArtifactId.FourYoungMaidens:
                    result.Initialize(artifact, "The Four Young Maidens",
                        "Reconnect Lotus, Lantern, Rice, and Water. Their joined current fills the central pool.");
                    break;
                default: DestroyImmediate(result); throw new ArgumentOutOfRangeException(nameof(artifact));
            }
            result.name = artifact + " Definition";
            return result;
        }
    }
}
```

## Assets/RiversInTheSky/Runtime/Core/ArtifactNode.cs

```csharp
using UnityEngine;
using UnityEngine.Events;

namespace RiversInTheSky
{
    /// <summary>Attach beside the artifact's collider; ArtifactInteractor opens its choice UI.</summary>
    [DisallowMultipleComponent]
    public sealed class ArtifactNode : MonoBehaviour
    {
        [SerializeField] private QuestManager quests;
        [SerializeField] private ArtifactId id;
        [SerializeField] private UnityEvent<bool> onAvailabilityChanged = new UnityEvent<bool>();
        [SerializeField] private UnityEvent<bool> onResolvedChanged = new UnityEvent<bool>();
        private bool initialized, lastAvailable, lastResolved;

        public ArtifactId Id => id;
        public ArtifactDefinition Definition => quests != null ? quests.GetDefinition(id) : null;
        public QuestManager Quests => quests;
        public bool IsAvailable => quests != null && quests.IsAvailable(id);
        public bool IsResolved => quests != null && quests.IsResolved(id);

        public void Configure(QuestManager manager, ArtifactId artifact)
        {
            if (isActiveAndEnabled && quests != null) quests.StateChanged -= Refresh;
            quests = manager; id = artifact; initialized = false;
            if (isActiveAndEnabled && quests != null) { quests.StateChanged += Refresh; Refresh(quests.Snapshot); }
        }

        private void OnEnable()
        {
            if (quests == null) return;
            quests.StateChanged += Refresh;
            Refresh(quests.Snapshot);
        }
        private void OnDisable() { if (quests != null) quests.StateChanged -= Refresh; }
        private void Refresh(QuestSnapshot snapshot)
        {
            if (snapshot == null) return;
            bool available = IsAvailable, resolved = IsResolved;
            if (!initialized || available != lastAvailable) onAvailabilityChanged.Invoke(available);
            if (!initialized || resolved != lastResolved) onResolvedChanged.Invoke(resolved);
            lastAvailable = available; lastResolved = resolved; initialized = true;
        }
    }
}
```

## Assets/RiversInTheSky/Runtime/Core/CentralPoolView.cs

```csharp
using UnityEngine;
using UnityEngine.Events;

namespace RiversInTheSky
{
    /// <summary>Drive a separate visual water surface; keep this listener outside the final-memory root.</summary>
    public sealed class CentralPoolView : MonoBehaviour
    {
        [SerializeField] private QuestManager quests;
        [SerializeField] private Transform waterSurface;
        [SerializeField] private float emptyLocalY;
        [SerializeField] private float fullLocalY = 1f;
        [SerializeField] private GameObject finalMemoryRoot;
        [SerializeField] private UnityEvent<float> onFillChanged = new UnityEvent<float>();

        private void OnEnable()
        {
            if (quests == null) return;
            quests.StateChanged += Refresh;
            Refresh(quests.Snapshot);
        }
        private void OnDisable() { if (quests != null) quests.StateChanged -= Refresh; }
        private void Refresh(QuestSnapshot snapshot)
        {
            if (snapshot == null) return;
            if (waterSurface != null)
            {
                Vector3 position = waterSurface.localPosition;
                position.y = Mathf.Lerp(emptyLocalY, fullLocalY, snapshot.PoolFill01);
                waterSurface.localPosition = position;
            }
            if (finalMemoryRoot != null && finalMemoryRoot != gameObject)
                finalMemoryRoot.SetActive(snapshot.FinalMemoryUnlocked);
            onFillChanged.Invoke(snapshot.PoolFill01);
        }
    }
}
```

## Assets/RiversInTheSky/Runtime/Core/QuestManager.cs

```csharp
using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>
    /// Scene-owned quest service. Reference explicitly from other systems; no global singleton or
    /// scene search is needed. Save restoration emits state, never the player's live-choice event.
    /// </summary>
    [DefaultExecutionOrder(-200)]
    [DisallowMultipleComponent]
    public sealed class QuestManager : MonoBehaviour
    {
        [SerializeField] private ArtifactDefinition[] definitions = Array.Empty<ArtifactDefinition>();
        [SerializeField, Min(.1f)] private float poolFillDuration = 8f;
        [SerializeField] private bool loadOnAwake = true;
        [SerializeField] private bool autoSave = true;
        [SerializeField] private string saveFileName = "rivers-quest.json";

        private readonly Dictionary<ArtifactId, ArtifactDefinition> catalog = new Dictionary<ArtifactId, ArtifactDefinition>();
        private readonly List<ArtifactDefinition> generatedDefinitions = new List<ArtifactDefinition>();
        private QuestState state;
        private bool publishing;
        private bool persistenceAllowed = true;
        private float nextPoolSaveTime;

        public QuestSnapshot Snapshot { get; private set; }
        public event Action<QuestSnapshot> StateChanged;
        public event Action<ChoiceOutcome> ChoiceCommitted;
        public event Action FinalMemoryUnlocked;

        private string SavePath => Path.Combine(Application.persistentDataPath,
            string.IsNullOrWhiteSpace(saveFileName) ? "rivers-quest.json" : Path.GetFileName(saveFileName));

        private void Awake()
        {
            BuildCatalog();
            state = new QuestState(catalog);
            if (loadOnAwake) Load();
            Snapshot = state.Snapshot;
        }

        // Initial scene consumers may subscribe in OnEnable and always also read Snapshot there.
        private void Start() => PublishState();

        private void Update()
        {
            if (!state.AdvancePool(Time.deltaTime, poolFillDuration, out bool unlocked)) return;
            Snapshot = state.Snapshot;
            if (autoSave && (unlocked || Time.unscaledTime >= nextPoolSaveTime))
            { Save(); nextPoolSaveTime = Time.unscaledTime + 1f; }
            PublishState();
            if (unlocked) InvokeSafely(FinalMemoryUnlocked);
        }

        public ArtifactDefinition GetDefinition(ArtifactId id) => catalog.TryGetValue(id, out ArtifactDefinition definition) ? definition : null;
        public bool IsResolved(ArtifactId id) => state != null && state.IsResolved(id);
        public bool IsAvailable(ArtifactId id) => state != null && state.IsAvailable(id);
        public string GetChoiceId(ArtifactId id) => state?.GetChoiceId(id);

        public bool TryChoose(ArtifactId id, string choiceId, out string error)
        {
            if (state == null || publishing) { error = "The quest service is not ready for a new interaction."; return false; }
            if (!state.TryChoose(id, choiceId, out ChoiceOutcome outcome, out error)) return false;
            Snapshot = state.Snapshot;
            if (autoSave) Save();
            PublishState();
            // Narrative, one-shot sounds and haptics subscribe here, not to state reconstruction.
            publishing = true;
            try { InvokeSafely(ChoiceCommitted, outcome); }
            finally { publishing = false; }
            return true;
        }

        public bool TryConnectChannel(WaterChannel channel, out string error)
        {
            if (state == null || publishing) { error = "The quest service is not ready for a new interaction."; return false; }
            if (!state.TryConnectChannel(channel, out error)) return false;
            Snapshot = state.Snapshot;
            if (autoSave) Save();
            PublishState();
            return true;
        }

        public void Save()
        {
            if (state == null || !persistenceAllowed) return;
            string path = SavePath;
            string temporary = path + ".tmp";
            string backup = path + ".bak";
            try
            {
                Directory.CreateDirectory(Application.persistentDataPath);
                File.WriteAllText(temporary, JsonUtility.ToJson(state.Export(), true));
                if (!File.Exists(path)) File.Move(temporary, path);
                else
                {
                    try { File.Replace(temporary, path, backup); }
                    catch (PlatformNotSupportedException)
                    {
                        // Preserve the previous state even on platforms without atomic replacement.
                        File.Copy(path, backup, true);
                        File.Copy(temporary, path, true);
                        File.Delete(temporary);
                    }
                }
            }
            catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException || exception is ArgumentException)
            { Debug.LogError($"Quest save failed: {exception.Message}", this); }
        }

        private void Load()
        {
            string path = SavePath;
            foreach (string candidate in new[] { path, path + ".bak" })
            {
                if (!File.Exists(candidate)) continue;
                try
                {
                    QuestSaveData data = JsonUtility.FromJson<QuestSaveData>(File.ReadAllText(candidate));
                    if (data != null && data.version > 1)
                    {
                        persistenceAllowed = false;
                        Debug.LogError("This save belongs to a newer game version; writes are disabled to preserve it.", this);
                        return;
                    }
                    state.Restore(data);
                    return;
                }
                catch (Exception exception) when (exception is IOException || exception is InvalidDataException ||
                    exception is UnauthorizedAccessException || exception is ArgumentException)
                { Debug.LogWarning($"Could not load {Path.GetFileName(candidate)}: {exception.Message}", this); }
            }
        }

        private void BuildCatalog()
        {
            if (definitions != null)
                foreach (ArtifactDefinition definition in definitions)
                {
                    if (definition == null) continue;
                    if (!definition.Validate(out string error)) { Debug.LogError(error, definition); continue; }
                    if (!catalog.TryAdd(definition.Id, definition))
                        Debug.LogError($"Duplicate artifact ID {definition.Id}; the first definition is used.", definition);
                }
            foreach (ArtifactId id in Enum.GetValues(typeof(ArtifactId)))
                if (!catalog.ContainsKey(id))
                {
                    ArtifactDefinition generated = ArtifactDefinition.CreateDefault(id);
                    generated.hideFlags = HideFlags.HideAndDontSave;
                    generatedDefinitions.Add(generated);
                    catalog.Add(id, generated);
                }
        }

        private void PublishState()
        {
            publishing = true;
            try { InvokeSafely(StateChanged, Snapshot); }
            finally { publishing = false; }
        }

        // A broken scene listener must not prevent other listeners from observing committed state.
        private void InvokeSafely<T>(Action<T> handlers, T value)
        {
            if (handlers == null) return;
            foreach (Action<T> handler in handlers.GetInvocationList())
                try { handler(value); } catch (Exception exception) { Debug.LogException(exception, this); }
        }
        private void InvokeSafely(Action handlers)
        {
            if (handlers == null) return;
            foreach (Action handler in handlers.GetInvocationList())
                try { handler(); } catch (Exception exception) { Debug.LogException(exception, this); }
        }

        private void OnApplicationPause(bool paused) { if (paused && autoSave) Save(); }
        private void OnDisable() { if (autoSave) Save(); }
        private void OnDestroy()
        {
            foreach (ArtifactDefinition generated in generatedDefinitions)
                if (generated != null) Destroy(generated);
        }
    }
}
```

## Assets/RiversInTheSky/Runtime/Core/QuestState.cs

```csharp
using System;
using System.Collections.Generic;
using System.IO;

namespace RiversInTheSky
{
    public sealed class ChoiceOutcome
    {
        public ArtifactId Artifact { get; }
        public ChoiceDefinition Choice { get; }
        public IsoAct Act { get; }
        public ChoiceOutcome(ArtifactId artifact, ChoiceDefinition choice, IsoAct act)
        { Artifact = artifact; Choice = choice; Act = act; }
    }

    /// <summary>Immutable event payload: listeners cannot change the quest underneath other listeners.</summary>
    public sealed class QuestSnapshot
    {
        public int ResolvedCount { get; }
        public int CleansedCount { get; }
        public WaterChannel ConnectedChannels { get; }
        public float PoolFill01 { get; }
        public bool FinalMemoryUnlocked { get; }
        public IsoAct Act { get; }
        public int Habitat { get; }
        public int Pollution { get; }
        public int Toxicity { get; }
        public int FloodRisk { get; }
        public int Nutrients { get; }

        internal QuestSnapshot(int resolved, int cleansed, WaterChannel channels, float fill,
            int habitat, int pollution, int toxicity, int floodRisk, int nutrients)
        {
            FinalMemoryUnlocked = fill >= 1f;
            ResolvedCount = resolved + (FinalMemoryUnlocked ? 1 : 0);
            CleansedCount = cleansed + (FinalMemoryUnlocked ? 1 : 0);
            ConnectedChannels = channels;
            PoolFill01 = fill;
            Act = resolved < 2 ? IsoAct.AnalyticalCurious : resolved < 4
                ? IsoAct.QuestionAndLearn : IsoAct.UnderstandingEmpathetic;
            Habitat = habitat; Pollution = pollution; Toxicity = toxicity;
            FloodRisk = floodRisk; Nutrients = nutrients;
        }
    }

    [Serializable]
    public sealed class QuestSaveData
    {
        public int version = 1;
        public List<ArtifactChoiceRecord> choices = new List<ArtifactChoiceRecord>();
        public int connectedChannels;
        public float poolFill;
    }

    [Serializable]
    public sealed class ArtifactChoiceRecord
    {
        public ArtifactId artifact;
        public string choiceId;
        public ArtifactChoiceRecord(ArtifactId artifact, string choiceId)
        { this.artifact = artifact; this.choiceId = choiceId; }
    }

    /// <summary>
    /// Deterministic domain model. Choices are the source of truth: counters and ecology are derived,
    /// so replaying saves or enabling scene objects cannot increment rewards twice.
    /// </summary>
    public sealed class QuestState
    {
        private readonly IReadOnlyDictionary<ArtifactId, ArtifactDefinition> catalog;
        private readonly Dictionary<ArtifactId, string> selected = new Dictionary<ArtifactId, string>();
        private WaterChannel channels;
        private float poolFill;

        public QuestState(IReadOnlyDictionary<ArtifactId, ArtifactDefinition> catalog)
        { this.catalog = catalog ?? throw new ArgumentNullException(nameof(catalog)); }

        public string GetChoiceId(ArtifactId id) => selected.TryGetValue(id, out string value) ? value : null;
        public bool IsResolved(ArtifactId id) => id == ArtifactId.FourYoungMaidens ? poolFill >= 1f : selected.ContainsKey(id);
        public bool IsAvailable(ArtifactId id) => catalog.ContainsKey(id) && !IsResolved(id) &&
            (id != ArtifactId.FourYoungMaidens || selected.Count == 4);

        public QuestSnapshot Snapshot
        {
            get
            {
                int clean = 0, habitat = 0, pollution = 0, toxicity = 0, flood = 0, nutrients = 0;
                foreach (KeyValuePair<ArtifactId, string> entry in selected)
                {
                    ChoiceDefinition choice = catalog[entry.Key].FindChoice(entry.Value);
                    if (choice.IsRestorative) clean++;
                    habitat += choice.HabitatDelta; pollution += choice.PollutionDelta;
                    toxicity += choice.ToxicityDelta; flood += choice.FloodRiskDelta; nutrients += choice.NutrientDelta;
                }
                return new QuestSnapshot(selected.Count, clean, channels, poolFill,
                    habitat, pollution, toxicity, flood, nutrients);
            }
        }

        public bool TryChoose(ArtifactId id, string choiceId, out ChoiceOutcome outcome, out string error)
        {
            outcome = null;
            if (!catalog.TryGetValue(id, out ArtifactDefinition definition))
            { error = "This artifact is not in the quest catalog."; return false; }
            if (id == ArtifactId.FourYoungMaidens)
            { error = "Reconnect the four channels to reveal this memory."; return false; }
            if (selected.ContainsKey(id))
            { error = "This artifact's choice has already been committed."; return false; }
            ChoiceDefinition choice = definition.FindChoice(choiceId);
            if (choice == null) { error = "Unknown choice for this artifact."; return false; }
            selected.Add(id, choiceId);
            outcome = new ChoiceOutcome(id, choice, Snapshot.Act);
            error = null;
            return true;
        }

        public bool TryConnectChannel(WaterChannel channel, out string error)
        {
            if (!TryGetPrerequisite(channel, out ArtifactId prerequisite))
            { error = "Choose exactly one of the four channels."; return false; }
            if ((channels & channel) != 0) { error = "This channel is already connected."; return false; }
            if (!IsResolved(prerequisite))
            { error = $"Resolve {catalog[prerequisite].DisplayName} before connecting this channel."; return false; }
            channels |= channel;
            error = null;
            return true;
        }

        // Call only from the manager's clock. No branch can permanently prevent final completion.
        public bool AdvancePool(float deltaTime, float fillDuration, out bool unlockedNow)
        {
            unlockedNow = false;
            if (channels != WaterChannel.All || selected.Count != 4 || poolFill >= 1f ||
                float.IsNaN(deltaTime) || float.IsInfinity(deltaTime) || deltaTime <= 0) return false;
            float duration = float.IsNaN(fillDuration) || float.IsInfinity(fillDuration) ? 8f : Math.Max(.01f, fillDuration);
            poolFill = Math.Min(1f, poolFill + deltaTime / duration);
            unlockedNow = poolFill >= 1f;
            return true;
        }

        public QuestSaveData Export()
        {
            var data = new QuestSaveData { connectedChannels = (int)channels, poolFill = poolFill };
            // Explicit order keeps saves and source control diffs stable across runtimes.
            for (int i = 0; i < 4; i++)
                if (selected.TryGetValue((ArtifactId)i, out string choice))
                    data.choices.Add(new ArtifactChoiceRecord((ArtifactId)i, choice));
            return data;
        }

        public void Restore(QuestSaveData data)
        {
            if (data == null || data.version != 1) throw new InvalidDataException("Unsupported quest save version.");
            selected.Clear();
            // Invalid IDs, removed authored choices, and duplicate records never create phantom progress.
            if (data.choices != null)
                foreach (ArtifactChoiceRecord record in data.choices)
                    if (record != null && record.artifact != ArtifactId.FourYoungMaidens &&
                        !selected.ContainsKey(record.artifact) && catalog.TryGetValue(record.artifact, out ArtifactDefinition def) &&
                        def.FindChoice(record.choiceId) != null) selected.Add(record.artifact, record.choiceId);
            channels = WaterChannel.None;
            foreach (WaterChannel channel in new[] { WaterChannel.Lotus, WaterChannel.Lantern, WaterChannel.Rice, WaterChannel.Water })
                if ((((WaterChannel)data.connectedChannels) & channel) != 0 &&
                    TryGetPrerequisite(channel, out ArtifactId prerequisite) && IsResolved(prerequisite)) channels |= channel;
            poolFill = channels == WaterChannel.All && selected.Count == 4 &&
                !float.IsNaN(data.poolFill) && !float.IsInfinity(data.poolFill) ? Math.Max(0, Math.Min(1, data.poolFill)) : 0;
        }

        private static bool TryGetPrerequisite(WaterChannel channel, out ArtifactId prerequisite)
        {
            switch (channel)
            {
                case WaterChannel.Lotus: prerequisite = ArtifactId.Lotus; return true;
                case WaterChannel.Lantern: prerequisite = ArtifactId.Lamplight; return true;
                case WaterChannel.Rice: prerequisite = ArtifactId.RiceField; return true;
                case WaterChannel.Water: prerequisite = ArtifactId.Pagoda; return true;
                default: prerequisite = default; return false;
            }
        }
    }
}
```

## Assets/RiversInTheSky/Runtime/Core/WaterChannelValve.cs

```csharp
using UnityEngine;
using UnityEngine.Events;

namespace RiversInTheSky
{
    /// <summary>DesktopInteractor calls Connect() when aimed at this valve; UI buttons can call it too.</summary>
    public sealed class WaterChannelValve : MonoBehaviour
    {
        [SerializeField] private QuestManager quests;
        [SerializeField] private WaterChannel channel = WaterChannel.Lotus;
        [SerializeField] private UnityEvent<bool> onConnectedState = new UnityEvent<bool>();
        [SerializeField] private UnityEvent<string> onRejected = new UnityEvent<string>();
        private bool initialized, lastConnected;

        public void Configure(QuestManager manager, WaterChannel value)
        {
            if (isActiveAndEnabled && quests != null) quests.StateChanged -= Refresh;
            quests = manager; channel = value; initialized = false;
            if (isActiveAndEnabled && quests != null) { quests.StateChanged += Refresh; Refresh(quests.Snapshot); }
        }

        public void Connect()
        {
            if (quests == null) { onRejected.Invoke("No quest service is assigned."); return; }
            if (!quests.TryConnectChannel(channel, out string error)) onRejected.Invoke(error);
        }
        private void OnEnable()
        {
            if (quests == null) return;
            quests.StateChanged += Refresh;
            Refresh(quests.Snapshot);
        }
        private void OnDisable() { if (quests != null) quests.StateChanged -= Refresh; }
        private void Refresh(QuestSnapshot snapshot)
        {
            if (snapshot == null) return;
            bool connected = (snapshot.ConnectedChannels & channel) == channel && channel != WaterChannel.None;
            if (!initialized || connected != lastConnected) onConnectedState.Invoke(connected);
            initialized = true; lastConnected = connected;
        }
    }
}
```

## Assets/RiversInTheSky/Runtime/Player/ArtifactChoicePanel.cs

```csharp
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

namespace RiversInTheSky
{
    /// <summary>
    /// Shared world-space mouse UI. It releases the gameplay cursor while open and
    /// restores the previous state after closing. Keep this controller outside panelRoot.
    /// </summary>
    public sealed class ArtifactChoicePanel : MonoBehaviour
    {
        [SerializeField] private GameObject panelRoot;
        [SerializeField] private Text title;
        [SerializeField] private Text description;
        [SerializeField] private Text status;
        [SerializeField] private Transform buttonContainer;
        [SerializeField] private Button buttonPrefab;
        [SerializeField, Min(0.5f)] private float viewingDistance = 1.5f;
        private readonly List<Button> buttons = new List<Button>();
        private ArtifactNode node;
        private ArtifactInteractor owner;
        private bool committing;
        private bool ownsCursor;
        private CursorLockMode previousCursorLock;
        private bool previousCursorVisible;
        private CanvasGroup openingClickGroup;
        private bool previousBlocksRaycasts;
        private bool waitingForOpeningClickRelease;

        public bool IsOpen { get; private set; }
        public int LastClosedFrame { get; private set; } = -1;

        private void Awake()
        {
            if (panelRoot != null && transform.IsChildOf(panelRoot.transform))
            {
                Debug.LogError("ArtifactChoicePanel must be outside the panelRoot that it hides.", this);
                enabled = false;
                return;
            }
            if (panelRoot != null) panelRoot.SetActive(false);
        }

        private void Update()
        {
            // Teleporting or disabling a target must not leave a remote choice available.
            if (IsOpen && (node == null || !node.isActiveAndEnabled || node.Quests == null || owner == null || !owner.IsInRange ||
                panelRoot == null || !panelRoot.activeInHierarchy))
            { Close(); return; }
            if (waitingForOpeningClickRelease && (Mouse.current == null || !Mouse.current.leftButton.isPressed))
                RestoreOpeningClickRaycasts();
        }

        public void Open(ArtifactNode artifact, ArtifactInteractor source, Transform head)
        {
            if (!isActiveAndEnabled || artifact == null || artifact.Quests == null || head == null ||
                source == null || !source.IsInRange) return;
            Close();
            if (panelRoot == null || buttonPrefab == null || buttonContainer == null ||
                transform.IsChildOf(panelRoot.transform)) return;
            ArtifactDefinition definition = artifact.Quests.GetDefinition(artifact.Id);
            if (definition == null) return;
            node = artifact; owner = source;
            previousCursorLock = Cursor.lockState;
            previousCursorVisible = Cursor.visible;
            ownsCursor = true;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            IsOpen = true;
            panelRoot.SetActive(true);
            var horizontal = Vector3.ProjectOnPlane(head.forward, Vector3.up);
            if (horizontal.sqrMagnitude < 0.001f) horizontal = Vector3.forward;
            panelRoot.transform.position = head.position + horizontal.normalized * viewingDistance;
            // A world-space Canvas's front faces the viewer with this orientation.
            panelRoot.transform.rotation = Quaternion.LookRotation(horizontal.normalized, Vector3.up);
            if (title != null) title.text = definition.DisplayName;
            if (description != null) description.text = definition.Description;
            if (status != null) status.text = artifact.Quests.IsResolved(artifact.Id)
                ? "This memory is already restored."
                : artifact.Id == ArtifactId.FourYoungMaidens ? "Reconnect the Lotus, Lantern, Rice and Water channels." : string.Empty;
            foreach (var choice in definition.Choices)
            {
                var capturedId = choice.Id; // Capture an immutable ID, never a mutable loop index.
                var button = Instantiate(buttonPrefab, buttonContainer);
                button.gameObject.SetActive(true);
                var label = button.GetComponentInChildren<Text>(true);
                if (label != null) label.text = choice.Label;
                button.interactable = artifact.Quests.IsAvailable(artifact.Id) && !artifact.Quests.IsResolved(artifact.Id);
                button.onClick.AddListener(() => Commit(capturedId));
                buttons.Add(button);
            }
            // The click which opened the panel must not also press a newly spawned choice.
            if (Mouse.current != null && Mouse.current.leftButton.isPressed)
            {
                openingClickGroup = panelRoot.GetComponent<CanvasGroup>();
                if (openingClickGroup == null) openingClickGroup = panelRoot.AddComponent<CanvasGroup>();
                previousBlocksRaycasts = openingClickGroup.blocksRaycasts;
                openingClickGroup.blocksRaycasts = false;
                waitingForOpeningClickRelease = true;
            }
        }

        private void Commit(string choiceId)
        {
            if (committing || !IsOpen || node == null || !node.isActiveAndEnabled || node.Quests == null || owner == null || !owner.IsInRange)
            { Close(); return; }
            committing = true;
            foreach (var button in buttons) if (button != null) button.interactable = false;
            bool accepted;
            string error;
            try { accepted = node.Quests.TryChoose(node.Id, choiceId, out error); }
            finally { committing = false; }
            if (accepted) { Close(); return; }
            if (status != null) status.text = error;
            foreach (var button in buttons)
                if (button != null) button.interactable = node.Quests.IsAvailable(node.Id) && !node.Quests.IsResolved(node.Id);
        }

        public void CloseIfOwner(ArtifactInteractor source) { if (owner == source) Close(); }
        public void Close() => CloseInternal(isActiveAndEnabled);

        private void RestoreOpeningClickRaycasts()
        {
            if (openingClickGroup != null) openingClickGroup.blocksRaycasts = previousBlocksRaycasts;
            openingClickGroup = null;
            waitingForOpeningClickRelease = false;
        }

        private void CloseInternal(bool restoreGameplayCursor)
        {
            if (IsOpen) LastClosedFrame = Time.frameCount;
            RestoreOpeningClickRaycasts();
            foreach (var button in buttons)
            {
                if (button == null) continue;
                button.onClick.RemoveAllListeners();
                button.gameObject.SetActive(false);
                if (Application.isPlaying) Destroy(button.gameObject);
                else DestroyImmediate(button.gameObject);
            }
            buttons.Clear(); owner = null; node = null; committing = false; IsOpen = false;
            if (panelRoot != null && panelRoot != gameObject) panelRoot.SetActive(false);
            if (!ownsCursor) return;
            ownsCursor = false;
            // Disabling the UI/controller or losing focus must never trap the desktop cursor.
            bool restore = restoreGameplayCursor && Application.isFocused;
            Cursor.lockState = restore ? previousCursorLock : CursorLockMode.None;
            Cursor.visible = restore ? previousCursorVisible : true;
        }

        private void OnDisable() => CloseInternal(false);
    }
}
```

## Assets/RiversInTheSky/Runtime/Player/ArtifactInteractor.cs

```csharp
using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>
    /// An artifact-side desktop interaction endpoint. DesktopInteractor performs the
    /// camera raycast; this component validates the player and opens the shared UI.
    /// </summary>
    [RequireComponent(typeof(ArtifactNode))]
    public sealed class ArtifactInteractor : MonoBehaviour
    {
        [SerializeField] private ArtifactNode node;
        [SerializeField] private ArtifactChoicePanel choicePanel;
        // Keep the field name to preserve existing Inspector references. It is the desktop camera.
        [SerializeField] private Transform playerHead;
        [SerializeField, Min(0.1f)] private float interactionDistance = 4f;

        public bool IsInRange => isActiveAndEnabled && playerHead != null &&
            (playerHead.position - transform.position).sqrMagnitude <=
            Mathf.Max(0.1f, interactionDistance) * Mathf.Max(0.1f, interactionDistance);

        private void Awake()
        {
            if (node == null) node = GetComponent<ArtifactNode>();
            if (playerHead == null && Camera.main != null) playerHead = Camera.main.transform;
        }

        /// <summary>Called only after the player's centre ray hits this artifact.</summary>
        public bool TryInteract(Transform viewer)
        {
            if (!isActiveAndEnabled || viewer == null) return false;
            playerHead = viewer;
            if (node == null) node = GetComponent<ArtifactNode>();
            if (!IsInRange || node == null || !node.isActiveAndEnabled || node.Quests == null ||
                choicePanel == null || !choicePanel.isActiveAndEnabled) return false;
            choicePanel.Open(node, this, playerHead);
            return choicePanel.IsOpen;
        }

        private void OnDisable()
        {
            if (choicePanel != null) choicePanel.CloseIfOwner(this);
        }

        public void Configure(ArtifactNode artifact, ArtifactChoicePanel panel, Transform head)
        { node = artifact; choicePanel = panel; playerHead = head; }
    }
}
```

## Assets/RiversInTheSky/Runtime/Player/DesktopInteractor.cs

```csharp
using UnityEngine;
using UnityEngine.InputSystem;

namespace RiversInTheSky
{
    /// <summary>
    /// E or left click interacts with the first solid object in the camera's centre ray.
    /// F photographs, Escape closes choices/releases the pointer, and a click resumes play.
    /// Place this on the player root so its own colliders can be excluded from the ray.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class DesktopInteractor : MonoBehaviour
    {
        [SerializeField] private Camera playerCamera;
        [SerializeField] private ArtifactChoicePanel choicePanel;
        [SerializeField] private EnvironmentCamera environmentCamera;
        [Tooltip("Optional scene surfaces whose environmental diagnostic view toggles with T.")]
        [SerializeField] private CyanobacteriaController[] diagnosticSurfaces = new CyanobacteriaController[0];
        [Tooltip("Include scenery and interaction colliders. Exclude player/tool layers where possible.")]
        [SerializeField] private LayerMask interactionMask = Physics.DefaultRaycastLayers;
        [SerializeField, Min(0.1f)] private float interactionDistance = 4f;

        private InputActionMap input;
        private InputAction interact;
        private InputAction pointerClick;
        private InputAction photograph;
        private InputAction cancel;
        private InputAction thermalView;

        private void Awake()
        {
            if (playerCamera == null) playerCamera = GetComponentInChildren<Camera>(true);
            if (environmentCamera == null) environmentCamera = GetComponent<EnvironmentCamera>();
            input = new InputActionMap("Rivers Desktop Interaction");
            interact = input.AddAction("Interact", InputActionType.Button, "<Keyboard>/e");
            pointerClick = input.AddAction("Pointer Click", InputActionType.Button, "<Mouse>/leftButton");
            photograph = input.AddAction("Photograph", InputActionType.Button, "<Keyboard>/f");
            cancel = input.AddAction("Cancel", InputActionType.Button, "<Keyboard>/escape");
            thermalView = input.AddAction("Thermal View", InputActionType.Button, "<Keyboard>/t");
        }

        public void Configure(Camera view, ArtifactChoicePanel panel, EnvironmentCamera cameraTool)
        { playerCamera = view; choicePanel = panel; environmentCamera = cameraTool; }

        private void OnEnable() => input?.Enable();
        private void OnDisable() => input?.Disable();
        private void OnDestroy() => input?.Dispose();

        private void Update()
        {
            // The panel handles cursor restoration. Do not immediately release it a second time.
            if (cancel.WasPressedThisFrame())
            {
                if (choicePanel != null && choicePanel.IsOpen) choicePanel.Close();
                else { Cursor.lockState = CursorLockMode.None; Cursor.visible = true; }
                return;
            }
            if (choicePanel != null && choicePanel.IsOpen) return;
            // EventSystem may have just closed the menu earlier in this Update cycle.
            // Its button click belongs to UI, not to the artifact behind the canvas.
            if (choicePanel != null && choicePanel.LastClosedFrame == Time.frameCount) return;
            if (Cursor.lockState != CursorLockMode.Locked)
            {
                if (pointerClick.WasPressedThisFrame())
                { Cursor.lockState = CursorLockMode.Locked; Cursor.visible = false; }
                return; // Resuming input must not also commit an interaction on that click.
            }
            if (photograph.WasPressedThisFrame())
            {
                if (environmentCamera != null) environmentCamera.Photograph();
                return;
            }
            if (thermalView.WasPressedThisFrame() && diagnosticSurfaces != null)
                foreach (CyanobacteriaController surface in diagnosticSurfaces)
                    if (surface != null) surface.ToggleThermalView();
            if (interact.WasPressedThisFrame() || pointerClick.WasPressedThisFrame()) TryInteract();
        }

        /// <summary>
        /// Performs one aim query without requiring a keyboard event. True means an interaction
        /// was delivered; a valve can still reject it through its existing prerequisite event.
        /// </summary>
        public bool TryInteract()
        {
            if (playerCamera == null || (choicePanel != null && choicePanel.IsOpen)) return false;
            Ray ray = playerCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0f));
            // ViewportPointToRay starts at the near clip plane. Start at the lens instead,
            // so even an occluder closer than that plane still blocks an interaction.
            ray.origin = playerCamera.transform.position;
            // This allocates only on a deliberate press. Filtering all hits skips our own body
            // without ignoring walls or requiring every default-layer object to be relayered.
            RaycastHit[] hits = Physics.RaycastAll(ray, interactionDistance, interactionMask, QueryTriggerInteraction.Ignore);
            int closestIndex = -1;
            float closestDistance = float.PositiveInfinity;
            for (int i = 0; i < hits.Length; i++)
            {
                if (hits[i].collider == null || hits[i].collider.transform.IsChildOf(transform)) continue;
                if (hits[i].distance >= closestDistance) continue;
                closestIndex = i;
                closestDistance = hits[i].distance;
            }
            if (closestIndex < 0) return false;
            Collider target = hits[closestIndex].collider;
            ArtifactInteractor artifact = target.GetComponentInParent<ArtifactInteractor>();
            if (artifact != null && artifact.isActiveAndEnabled) return artifact.TryInteract(playerCamera.transform);
            WaterChannelValve valve = target.GetComponentInParent<WaterChannelValve>();
            if (valve == null || !valve.isActiveAndEnabled) return false;
            valve.Connect();
            return true;
        }
    }
}
```

## Assets/RiversInTheSky/Runtime/Player/DesktopPlayerController.cs

```csharp
using UnityEngine;
using UnityEngine.InputSystem;

namespace RiversInTheSky
{
    /// <summary>
    /// Collision-aware first-person walking and mouse look. The component owns its input
    /// map, so a desktop scene needs no action asset and no other action maps are disabled.
    /// Keep the Camera below this player root, at eye height, and the root upright.
    /// </summary>
    [RequireComponent(typeof(CharacterController)), DisallowMultipleComponent]
    public sealed class DesktopPlayerController : MonoBehaviour
    {
        [SerializeField] private Camera playerCamera;
        [SerializeField] private ArtifactChoicePanel choicePanel;
        [SerializeField, Min(0.1f)] private float moveSpeed = 1.5f;
        [Tooltip("Degrees per mouse pixel. Mouse delta already measures displacement per frame.")]
        [SerializeField, Min(0.001f)] private float lookSensitivity = 0.12f;
        [SerializeField, Range(-89f, 89f)] private float minPitch = -80f;
        [SerializeField, Range(-89f, 89f)] private float maxPitch = 80f;
        [SerializeField] private float gravity = -20f;

        private CharacterController character;
        private InputActionMap input;
        private InputAction move;
        private InputAction look;
        private float pitch;
        private float verticalSpeed;
        private CursorLockMode previousCursorLock;
        private bool previousCursorVisible;
        private bool ownsCursor;
        private bool wasAcceptingInput;

        public Camera PlayerCamera => playerCamera;

        private void Awake()
        {
            character = GetComponent<CharacterController>();
            if (playerCamera == null) playerCamera = GetComponentInChildren<Camera>(true);
            input = new InputActionMap("Rivers Desktop Movement");
            move = input.AddAction("Move", InputActionType.Value, expectedControlLayout: "Vector2");
            move.AddCompositeBinding("2DVector")
                .With("Up", "<Keyboard>/w").With("Down", "<Keyboard>/s")
                .With("Left", "<Keyboard>/a").With("Right", "<Keyboard>/d");
            move.AddCompositeBinding("2DVector")
                .With("Up", "<Keyboard>/upArrow").With("Down", "<Keyboard>/downArrow")
                .With("Left", "<Keyboard>/leftArrow").With("Right", "<Keyboard>/rightArrow");
            look = input.AddAction("Look", InputActionType.Value, "<Mouse>/delta", expectedControlLayout: "Vector2");
            ReadCameraPitch();
        }

        public void Configure(Camera view, ArtifactChoicePanel panel)
        {
            playerCamera = view;
            choicePanel = panel;
            ReadCameraPitch();
        }

        private void ReadCameraPitch()
        {
            if (playerCamera == null) return;
            float angle = playerCamera.transform.localEulerAngles.x;
            pitch = Mathf.Clamp(angle > 180f ? angle - 360f : angle, minPitch, maxPitch);
        }

        private void OnEnable()
        {
            input?.Enable();
            previousCursorLock = Cursor.lockState;
            previousCursorVisible = Cursor.visible;
            ownsCursor = true;
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
            if (playerCamera == null)
                Debug.LogWarning("Desktop player needs a child Camera assigned to Player Camera.", this);
        }

        private void Update()
        {
            if (character == null || !character.enabled || Time.deltaTime <= 0f) return;
            bool acceptingInput = Cursor.lockState == CursorLockMode.Locked &&
                (choicePanel == null || (!choicePanel.IsOpen && choicePanel.LastClosedFrame != Time.frameCount));
            Vector3 horizontalVelocity = Vector3.zero;
            if (acceptingInput)
            {
                Vector2 movement = Vector2.ClampMagnitude(move.ReadValue<Vector2>(), 1f);
                // World up is fixed. Looking vertically cannot propel the player into the air.
                Vector3 forward = Vector3.ProjectOnPlane(transform.forward, Vector3.up).normalized;
                Vector3 right = Vector3.Cross(Vector3.up, forward);
                horizontalVelocity = (forward * movement.y + right * movement.x) * moveSpeed;
                if (playerCamera != null && wasAcceptingInput)
                {
                    Vector2 delta = look.ReadValue<Vector2>() * lookSensitivity;
                    transform.Rotate(0f, delta.x, 0f, Space.World);
                    // Mouse delta is NOT multiplied by deltaTime, avoiding frame-rate-dependent look.
                    pitch = Mathf.Clamp(pitch - delta.y, minPitch, maxPitch);
                    playerCamera.transform.localRotation = Quaternion.Euler(pitch, 0f, 0f);
                }
            }
            // Ignore the first look sample after pointer capture; it can contain UI mouse motion.
            wasAcceptingInput = acceptingInput;
            // UI pauses walking/look, but gravity must still settle the player onto the floor.
            if (character.isGrounded && verticalSpeed < 0f) verticalSpeed = -2f;
            verticalSpeed = Mathf.Max(-50f, verticalSpeed - Mathf.Abs(gravity) * Time.deltaTime);
            CollisionFlags collisions = character.Move((horizontalVelocity + Vector3.up * verticalSpeed) * Time.deltaTime);
            if ((collisions & CollisionFlags.Above) != 0 && verticalSpeed > 0f) verticalSpeed = 0f;
        }

        private void OnApplicationFocus(bool focused)
        {
            if (focused) return;
            wasAcceptingInput = false;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            // Returning to the game requires a click; it must not capture the pointer unexpectedly.
        }

        private void OnDisable()
        {
            input?.Disable();
            verticalSpeed = 0f;
            wasAcceptingInput = false;
            if (!ownsCursor) return;
            Cursor.lockState = previousCursorLock;
            Cursor.visible = previousCursorVisible;
            ownsCursor = false;
        }

        private void OnDestroy() => input?.Dispose();

        private void OnValidate()
        {
            moveSpeed = Mathf.Max(0.1f, moveSpeed);
            lookSensitivity = Mathf.Max(0.001f, lookSensitivity);
            minPitch = Mathf.Clamp(minPitch, -89f, 89f);
            maxPitch = Mathf.Clamp(maxPitch, minPitch, 89f);
        }
    }
}
```

## Assets/RiversInTheSky/Runtime/Player/EnvironmentCamera.cs

```csharp
using System;
using System.IO;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;
using UnityEngine.Rendering;

namespace RiversInTheSky
{
    /// <summary>Photographs the closest-to-centre eligible memory with a clear line of sight.</summary>
    public sealed class EnvironmentCamera : MonoBehaviour
    {
        [SerializeField] private Transform viewfinder;
        [SerializeField] private JournalManager journal;
        [SerializeField] private InputActionReference shutterAction;
        [SerializeField, Min(0.1f)] private float maxDistance = 20f;
        [SerializeField, Range(1f, 80f)] private float framingHalfAngle = 25f;
        [SerializeField] private LayerMask visibilityMask = ~0;
        [SerializeField, Min(0f)] private float shutterCooldown = 0.5f;
        [Header("Optional image capture: a separate, disabled camera")]
        [SerializeField] private Camera captureCamera;
        [SerializeField, Range(128, 1024)] private int imageResolution = 512;
        [SerializeField] private UnityEvent<string> onPhotographed = new UnityEvent<string>();
        [SerializeField] private UnityEvent onNoNewMemory = new UnityEvent();
        private float nextShutterTime;
        private void Awake() { if (viewfinder == null && Camera.main != null) viewfinder = Camera.main.transform; }
        private void OnEnable()
        {
            // Optional external actions belong to their Input System owner; observe without changing map enablement.
            if (shutterAction != null && shutterAction.action != null) shutterAction.action.performed += OnShutter;
        }
        private void OnDisable()
        {
            if (shutterAction != null && shutterAction.action != null) shutterAction.action.performed -= OnShutter;
        }
        private void OnShutter(InputAction.CallbackContext context) => TryPhotograph();
        // UnityEvent's Inspector binds void methods; this also supports a diegetic shutter button.
        public void Photograph() => TryPhotograph();
        public bool TryPhotograph()
        {
            if (journal == null || viewfinder == null || Time.unscaledTime < nextShutterTime) return false;
            nextShutterTime = Time.unscaledTime + shutterCooldown;
            Photographable best = null;
            var bestAlignment = -1f;
            var nearest = float.PositiveInfinity;
            var minimumAlignment = Mathf.Cos(framingHalfAngle * Mathf.Deg2Rad);
            foreach (var target in Photographable.Active)
            {
                if (target == null || string.IsNullOrWhiteSpace(target.MemoryId) || journal.ContainsPhoto(target.MemoryId)) continue;
                var offset = target.FramingPosition - viewfinder.position;
                var distance = offset.magnitude;
                if (distance < 0.01f || distance > maxDistance) continue;
                var direction = offset / distance;
                var alignment = Vector3.Dot(viewfinder.forward, direction);
                if (alignment < minimumAlignment) continue;
                // The first blocker must be this target (including its child colliders), or there must be no blocker.
                if (Physics.Raycast(viewfinder.position, direction, out var hit, distance, visibilityMask, QueryTriggerInteraction.Ignore) &&
                    hit.collider.GetComponentInParent<Photographable>() != target) continue;
                if (alignment > bestAlignment || (Mathf.Approximately(alignment, bestAlignment) && distance < nearest))
                { best = target; bestAlignment = alignment; nearest = distance; }
            }
            if (best == null) { onNoNewMemory.Invoke(); return false; }
            var imageFileName = TryCaptureImage();
            var accepted = journal.TryRecordPhoto(new PhotoMemory
            {
                memoryId = best.MemoryId, displayName = best.DisplayName,
                playerPosition = viewfinder.position, playerRotation = viewfinder.rotation, relatedToArtifact = best.RelatedToArtifact,
                artifact = best.Artifact, imageFileName = imageFileName
            });
            if (accepted) onPhotographed.Invoke(best.MemoryId);
            return accepted;
        }
        private string TryCaptureImage()
        {
            if (captureCamera == null) return string.Empty;
            if (captureCamera.enabled || captureCamera.transform == viewfinder)
            {
                Debug.LogWarning("Photo capture needs a separate disabled Camera; metadata was still recorded.", this);
                return string.Empty;
            }
            RenderTexture renderTarget = null;
            Texture2D pixels = null;
            var oldTarget = captureCamera.targetTexture;
            var oldActive = RenderTexture.active;
            var oldPosition = captureCamera.transform.position;
            var oldRotation = captureCamera.transform.rotation;
            try
            {
                var size = Mathf.Clamp(imageResolution, 128, 1024);
                renderTarget = RenderTexture.GetTemporary(size, size, 24, RenderTextureFormat.ARGB32);
                captureCamera.transform.SetPositionAndRotation(viewfinder.position, viewfinder.rotation);
                captureCamera.targetTexture = renderTarget;
                // URP supports this explicit request; Camera.Render is not supported by every SRP version.
                if (GraphicsSettings.currentRenderPipeline != null)
                {
                    var request = new RenderPipeline.StandardRequest { destination = renderTarget };
                    if (!RenderPipeline.SupportsRenderRequest(captureCamera, request)) return string.Empty;
                    RenderPipeline.SubmitRenderRequest(captureCamera, request);
                }
                else captureCamera.Render();
                RenderTexture.active = renderTarget;
                pixels = new Texture2D(size, size, TextureFormat.RGB24, false);
                pixels.ReadPixels(new Rect(0, 0, size, size), 0, 0);
                pixels.Apply(false, false);
                Directory.CreateDirectory(journal.PhotoDirectory);
                var fileName = Guid.NewGuid().ToString("N") + ".png";
                File.WriteAllBytes(Path.Combine(journal.PhotoDirectory, fileName), pixels.EncodeToPNG());
                return fileName;
            }
            catch (Exception error) when (error is IOException || error is UnauthorizedAccessException || error is UnityException)
            { Debug.LogWarning($"Image capture failed; metadata remains available: {error.Message}", this); return string.Empty; }
            finally
            {
                captureCamera.targetTexture = oldTarget;
                captureCamera.transform.SetPositionAndRotation(oldPosition, oldRotation);
                RenderTexture.active = oldActive;
                if (pixels != null) Destroy(pixels);
                if (renderTarget != null) RenderTexture.ReleaseTemporary(renderTarget);
            }
        }
    }
}
```

## Assets/RiversInTheSky/Runtime/Player/JournalManager.cs

```csharp
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEngine;

namespace RiversInTheSky
{
    [Serializable]
    public sealed class PhotoMemory
    {
        public string memoryId;
        public string displayName;
        public string photographedAtUtc;
        public Vector3 playerPosition;
        public Quaternion playerRotation = Quaternion.identity;
        public bool relatedToArtifact;
        public ArtifactId artifact;
        // Relative to JournalManager.PhotoDirectory; never contains a user-supplied absolute path.
        public string imageFileName;
    }

    /// <summary>A metadata journal that also indexes optional PNGs. IDs are unique across sessions.</summary>
    [DefaultExecutionOrder(-150)]
    public sealed class JournalManager : MonoBehaviour
    {
        [Serializable] private sealed class SaveData
        {
            public int version;
            public List<PhotoMemory> photos = new List<PhotoMemory>();
        }
        [SerializeField] private bool persistenceEnabled = true;
        [SerializeField] private string saveFileName = "rivers-journal-v1.json";
        private bool persistenceAllowed = true;
        private readonly List<PhotoMemory> photos = new List<PhotoMemory>();
        private readonly HashSet<string> ids = new HashSet<string>(StringComparer.Ordinal);
        public IReadOnlyList<PhotoMemory> Photos
        {
            get
            {
                var copies = new List<PhotoMemory>(photos.Count);
                foreach (var photo in photos) copies.Add(Copy(photo));
                return copies.AsReadOnly();
            }
        }
        public string PhotoDirectory => Path.Combine(Application.persistentDataPath, "rivers-photos");
        public event Action<PhotoMemory> PhotoRecorded;
        private string SavePath => Path.Combine(Application.persistentDataPath,
            string.IsNullOrWhiteSpace(saveFileName) ? "rivers-journal-v1.json" : Path.GetFileName(saveFileName));
        private void Awake() { if (persistenceEnabled) Load(); }
        public bool ContainsPhoto(string memoryId) => !string.IsNullOrWhiteSpace(memoryId) && ids.Contains(memoryId);
        public bool TryRecordPhoto(PhotoMemory memory)
        {
            if (memory == null || string.IsNullOrWhiteSpace(memory.memoryId) || !ids.Add(memory.memoryId)) return false;
            // Snapshot input data so subsequent caller mutations do not alter the saved entry.
            var stored = Copy(memory);
            if (string.IsNullOrWhiteSpace(stored.photographedAtUtc))
                stored.photographedAtUtc = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture);
            stored.imageFileName = string.IsNullOrEmpty(stored.imageFileName) ? string.Empty : Path.GetFileName(stored.imageFileName);
            photos.Add(stored);
            Save();
            PhotoRecorded?.Invoke(Copy(stored));
            return true;
        }
        public void Save()
        {
            if (!persistenceEnabled || !persistenceAllowed) return;
            try
            {
                Directory.CreateDirectory(Application.persistentDataPath);
                var payload = new SaveData { version = 1, photos = photos };
                var temporary = SavePath + ".tmp";
                File.WriteAllText(temporary, JsonUtility.ToJson(payload, true));
                // Keep the previous complete revision in case the application exits during a copy.
                if (File.Exists(SavePath)) File.Copy(SavePath, SavePath + ".bak", true);
                File.Copy(temporary, SavePath, true);
                File.Delete(temporary);
            }
            catch (Exception error) when (error is IOException || error is UnauthorizedAccessException || error is ArgumentException)
            { Debug.LogWarning($"Journal save failed: {error.Message}", this); }
        }
        private void Load()
        {
            // A newer primary is intentionally not replaced with an older backup. The player
            // may continue in memory, but this application version must not downgrade their data.
            if (!TryLoad(SavePath) && persistenceAllowed) TryLoad(SavePath + ".bak");
        }
        private bool TryLoad(string path)
        {
            if (!File.Exists(path)) return false;
            try
            {
                var payload = JsonUtility.FromJson<SaveData>(File.ReadAllText(path));
                if (payload != null && payload.version > 1)
                {
                    persistenceAllowed = false;
                    Debug.LogError("This journal belongs to a newer game version; writes are disabled to preserve it.", this);
                    return false;
                }
                if (payload == null || payload.version != 1 || payload.photos == null) return false;
                photos.Clear(); ids.Clear();
                foreach (var photo in payload.photos)
                {
                    if (photo == null || string.IsNullOrWhiteSpace(photo.memoryId) || !ids.Add(photo.memoryId)) continue;
                    var stored = Copy(photo);
                    stored.imageFileName = string.IsNullOrEmpty(photo.imageFileName) ? string.Empty : Path.GetFileName(photo.imageFileName);
                    photos.Add(stored);
                }
                return true;
            }
            catch (Exception error) when (error is IOException || error is UnauthorizedAccessException || error is ArgumentException)
            { Debug.LogWarning($"Journal load failed: {error.Message}", this); return false; }
        }
        private static PhotoMemory Copy(PhotoMemory source) => new PhotoMemory
        {
            memoryId = source.memoryId, displayName = source.displayName,
            photographedAtUtc = source.photographedAtUtc, playerPosition = source.playerPosition,
            playerRotation = source.playerRotation,
            relatedToArtifact = source.relatedToArtifact, artifact = source.artifact,
            imageFileName = source.imageFileName
        };
        private void OnApplicationPause(bool paused) { if (paused) Save(); }
        private void OnApplicationQuit() => Save();
    }
}
```

## Assets/RiversInTheSky/Runtime/Player/Photographable.cs

```csharp
using System.Collections.Generic;
using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>Place on a location or artifact root. Give every memory a stable, unique authoring ID.</summary>
    public sealed class Photographable : MonoBehaviour
    {
        private static readonly HashSet<Photographable> active = new HashSet<Photographable>();
        public static IEnumerable<Photographable> Active => active;
        [SerializeField] private string memoryId;
        [SerializeField] private string displayName;
        [SerializeField] private Transform framingPoint;
        [SerializeField] private bool relatedToArtifact;
        [SerializeField] private ArtifactId artifact;
        public string MemoryId => memoryId;
        public string DisplayName => displayName;
        public Vector3 FramingPosition => framingPoint != null ? framingPoint.position : transform.position;
        public bool RelatedToArtifact => relatedToArtifact;
        public ArtifactId Artifact => artifact;
        private void OnEnable() => active.Add(this);
        private void OnDisable() => active.Remove(this);
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ClearRegistry() => active.Clear();
        public void Configure(string id, string label, bool isArtifact, ArtifactId artifactId)
        { memoryId = id; displayName = label; relatedToArtifact = isArtifact; artifact = artifactId; }
    }
}
```

## Assets/RiversInTheSky/Runtime/Rendering/CyanobacteriaController.cs

```csharp
using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>
    /// Supplies the painterly shader with the player's view camera position,
    /// channel flow, and an optional environmental diagnostic overlay.
    /// Owns only the named shader properties, preserving other property-block values.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class CyanobacteriaController : MonoBehaviour
    {
        [SerializeField] private QuestManager quests;
        [SerializeField] private Transform playerHead;
        [SerializeField] private Renderer[] targets = new Renderer[0];
        [SerializeField, Min(0.01f)] private float proximityRadius = 5f;
        [SerializeField, Range(0f, 1f)] private float proximityStrength = 1f;
        [SerializeField] private Vector2 flowDirection = new Vector2(1f, 0.25f);
        [SerializeField, Range(0f, 1f)] private float baseFlow = 0.08f;
        [SerializeField] private bool useQuestFlow = true;
        [SerializeField, Range(0f, 1f)] private float thermalValue = 0.5f;
        [SerializeField] private bool thermalView;

        private readonly MaterialPropertyBlock block = new MaterialPropertyBlock();
        private float flow;
        private static readonly int Observer = Shader.PropertyToID("_ObserverWS");
        private static readonly int Radius = Shader.PropertyToID("_ProximityRadius");
        private static readonly int Proximity = Shader.PropertyToID("_ProximityStrength");
        private static readonly int Flow = Shader.PropertyToID("_FlowStrength");
        private static readonly int Direction = Shader.PropertyToID("_FlowDirection");
        private static readonly int ThermalBlend = Shader.PropertyToID("_ThermalBlend");
        private static readonly int ThermalValue = Shader.PropertyToID("_ThermalValue");

        private void Awake()
        {
            if (targets == null || targets.Length == 0)
                targets = GetComponentsInChildren<Renderer>(true);
            flow = baseFlow;
        }

        private void OnEnable()
        {
            if (quests != null)
            {
                quests.StateChanged += RefreshQuest;
                RefreshQuest(quests.Snapshot);
            }
        }

        private void OnDisable()
        {
            if (quests != null) quests.StateChanged -= RefreshQuest;
            // Do not clear blocks: another component may own unrelated properties.
            Apply(false);
        }

        public void Configure(QuestManager manager, Transform head, Renderer[] renderers = null)
        {
            if (quests != null && isActiveAndEnabled) quests.StateChanged -= RefreshQuest;
            quests = manager;
            playerHead = head;
            if (renderers != null) targets = renderers;
            if (quests != null && isActiveAndEnabled)
            {
                quests.StateChanged += RefreshQuest;
                RefreshQuest(quests.Snapshot);
            }
        }

        private void RefreshQuest(QuestSnapshot snapshot)
        {
            if (!useQuestFlow || snapshot == null) return;
            // Count flags rather than their numeric value: Rice=4 is one channel.
            int flags = (int)snapshot.ConnectedChannels;
            int count = 0;
            for (int bit = 0; bit < 4; bit++) count += (flags >> bit) & 1;
            flow = Mathf.Lerp(baseFlow, 1f, count / 4f);
        }

        /// <summary>Manual flow control for local streams; overrides quest-derived flow.</summary>
        public void SetFlowStrength(float value)
        {
            useQuestFlow = false;
            flow = Mathf.Clamp01(value);
        }

        /// <summary>0 = cool/low impact; 1 = hot/high impact. This is environmental data.</summary>
        public void SetThermalValue(float value) => thermalValue = Mathf.Clamp01(value);
        public void SetThermalView(bool enabled) => thermalView = enabled;
        public void ToggleThermalView() => thermalView = !thermalView;

        private void LateUpdate() => Apply(true);

        private void Apply(bool active)
        {
            if (targets == null) return;
            Vector3 head = playerHead != null ? playerHead.position : Vector3.zero;
            Vector2 direction = flowDirection.sqrMagnitude > 0.0001f
                ? flowDirection.normalized : Vector2.right;
            foreach (Renderer target in targets)
            {
                if (target == null) continue;
                target.GetPropertyBlock(block);
                block.SetVector(Observer, new Vector4(head.x, head.y, head.z, 1f));
                block.SetFloat(Radius, Mathf.Max(0.01f, proximityRadius));
                block.SetFloat(Proximity, active && playerHead != null ? proximityStrength : 0f);
                block.SetFloat(Flow, Mathf.Clamp01(flow));
                block.SetVector(Direction, new Vector4(direction.x, direction.y, 0f, 0f));
                block.SetFloat(ThermalValue, Mathf.Clamp01(thermalValue));
                block.SetFloat(ThermalBlend, active && thermalView ? 1f : 0f);
                target.SetPropertyBlock(block);
            }
        }
    }
}
```

## Assets/RiversInTheSky/Runtime/Rendering/EcologyThermalDriver.cs

```csharp
using UnityEngine;

namespace RiversInTheSky
{
    /// <summary>
    /// Maps one relative quest metric into a local diagnostic color. This is an authored
    /// environmental overlay, not a temperature measurement. Put separate drivers on
    /// the leakage, wetland, and irrigation regions to show the relevant consequence.
    /// </summary>
    public sealed class EcologyThermalDriver : MonoBehaviour
    {
        public enum Metric { Habitat, Pollution, Toxicity, FloodRisk, Nutrients }
        [SerializeField] private QuestManager quests;
        [SerializeField] private CyanobacteriaController surface;
        [SerializeField] private Metric metric = Metric.Toxicity;
        [SerializeField, Range(0f, 1f)] private float baseline = 0.5f;
        [SerializeField, Min(0.01f)] private float unitsToFullScale = 4f;
        [Tooltip("Enable when decreasing this metric should produce a hotter impact color, such as habitat loss.")]
        [SerializeField] private bool invert;

        private void OnEnable()
        {
            if (quests == null) return;
            quests.StateChanged += Refresh;
            Refresh(quests.Snapshot);
        }
        private void OnDisable() { if (quests != null) quests.StateChanged -= Refresh; }
        private void Refresh(QuestSnapshot snapshot)
        {
            if (snapshot == null || surface == null) return;
            int value;
            switch (metric)
            {
                case Metric.Habitat: value = snapshot.Habitat; break;
                case Metric.Pollution: value = snapshot.Pollution; break;
                case Metric.Toxicity: value = snapshot.Toxicity; break;
                case Metric.FloodRisk: value = snapshot.FloodRisk; break;
                case Metric.Nutrients: value = snapshot.Nutrients; break;
                default: value = 0; break;
            }
            surface.SetThermalValue(Mathf.Clamp01(baseline + (invert ? -value : value) /
                Mathf.Max(0.01f, unitsToFullScale)));
        }
    }
}
```

## Assets/RiversInTheSky/Runtime/Rendering/PainterlyGradeController.cs

```csharp
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace RiversInTheSky
{
    /// <summary>
    /// Grades a dedicated global Volume from twilight blues toward candlelit memory.
    /// A runtime clone prevents editing the shared profile asset or another scene's grade.
    /// Use a dedicated Volume so disabling this component restores the original profile.
    /// </summary>
    [RequireComponent(typeof(Volume)), DisallowMultipleComponent]
    public sealed class PainterlyGradeController : MonoBehaviour
    {
        [SerializeField] private QuestManager quests;
        [SerializeField, Min(0.01f)] private float transitionSeconds = 3f;
        [SerializeField] private Color twilightFilter = new Color(0.72f, 0.83f, 1f);
        [SerializeField] private Color candlelightFilter = new Color(1f, 0.9f, 0.75f);
        [SerializeField, Range(0f, 1f)] private float bloomIntensity = 0.18f;
        [SerializeField] private bool enableBloom = false;

        private Volume volume;
        private VolumeProfile originalProfile;
        private bool restoreInternalProfile;
        private VolumeProfile runtimeProfile;
        private ColorAdjustments color;
        private WhiteBalance whiteBalance;
        private Vignette vignette;
        private Bloom bloom;
        private float warmth;
        private float targetWarmth;

        private void OnEnable()
        {
            volume = GetComponent<Volume>();
            restoreInternalProfile = volume.HasInstantiatedProfile();
            originalProfile = restoreInternalProfile ? volume.profile : volume.sharedProfile;
            runtimeProfile = ScriptableObject.CreateInstance<VolumeProfile>();
            // Clone every override, not just the profile's component list.
            if (originalProfile != null)
                foreach (VolumeComponent component in originalProfile.components)
                    runtimeProfile.components.Add(Instantiate(component));
            volume.profile = runtimeProfile;
            color = GetOrAdd<ColorAdjustments>();
            whiteBalance = GetOrAdd<WhiteBalance>();
            vignette = GetOrAdd<Vignette>();
            bloom = GetOrAdd<Bloom>();
            color.contrast.Override(10f);
            color.saturation.Override(-8f);
            vignette.intensity.Override(0.08f);
            vignette.smoothness.Override(0.75f);
            bloom.threshold.Override(1.1f);
            bloom.intensity.Override(enableBloom ? bloomIntensity : 0f);
            if (quests != null)
            {
                quests.StateChanged += RefreshQuest;
                RefreshQuest(quests.Snapshot);
            }
            warmth = targetWarmth;
            ApplyGrade();
        }

        public void Configure(QuestManager manager)
        {
            if (quests != null && isActiveAndEnabled) quests.StateChanged -= RefreshQuest;
            quests = manager;
            if (quests != null && isActiveAndEnabled)
            {
                quests.StateChanged += RefreshQuest;
                RefreshQuest(quests.Snapshot);
            }
        }

        private T GetOrAdd<T>() where T : VolumeComponent
        {
            if (!runtimeProfile.TryGet<T>(out T component)) component = runtimeProfile.Add<T>(true);
            component.active = true;
            return component;
        }

        private void RefreshQuest(QuestSnapshot snapshot)
        {
            if (snapshot != null) targetWarmth = Mathf.Clamp01(snapshot.CleansedCount / 5f);
        }

        public void SetWarmth(float value) => targetWarmth = Mathf.Clamp01(value);

        private void Update()
        {
            warmth = Mathf.MoveTowards(warmth, targetWarmth,
                Time.unscaledDeltaTime / Mathf.Max(0.01f, transitionSeconds));
            ApplyGrade();
        }

        private void ApplyGrade()
        {
            color.colorFilter.Override(Color.Lerp(twilightFilter, candlelightFilter, warmth));
            whiteBalance.temperature.Override(Mathf.Lerp(-12f, 16f, warmth));
            whiteBalance.tint.Override(2f);
        }

        private void OnDisable()
        {
            if (quests != null) quests.StateChanged -= RefreshQuest;
            if (volume != null && volume.profile == runtimeProfile)
                volume.profile = restoreInternalProfile ? originalProfile : null;
            if (runtimeProfile == null) return;
            foreach (VolumeComponent component in runtimeProfile.components) Destroy(component);
            Destroy(runtimeProfile);
            runtimeProfile = null;
        }
    }
}
```

## Assets/RiversInTheSky/Runtime/RiversInTheSky.Runtime.asmdef

```json
{
  "name": "RiversInTheSky.Runtime",
  "rootNamespace": "RiversInTheSky",
  "references": [
    "Unity.InputSystem",
    "UnityEngine.UI",
    "Unity.RenderPipelines.Core.Runtime",
    "Unity.RenderPipelines.Universal.Runtime"
  ],
  "autoReferenced": true
}
```

## Assets/RiversInTheSky/Shaders/PainterlyBioluminescence.shader

```hlsl
Shader "RiversInTheSky/PainterlyBioluminescence"
{
    Properties
    {
        _BaseMap ("Paint / Albedo", 2D) = "white" {}
        _PatternMap ("Biology: R=colony, G=brush, B=diagnostic", 2D) = "white" {}
        _BaseColor ("Base Color", Color) = (0.09, 0.25, 0.24, 1)
        [HDR] _GlowColor ("Cyanobacteria Glow", Color) = (0.03, 1.8, 1.4, 1)
        _EmissionStrength ("Emission Strength (0 for architecture)", Range(0, 5)) = 1
        [Toggle] _ProceduralPattern ("Generate Colony Pattern", Float) = 1
        _PatternScale ("World Pattern Scale", Float) = 0.5
        _PatternThreshold ("Colony Threshold", Range(0, 1)) = 0.5
        _PatternSoftness ("Colony Softness", Range(0.01, 0.5)) = 0.12
        _Iridescence ("Iridescence", Range(0, 1)) = 0.6
        _BrushStrength ("Brush Variation", Range(0, 1)) = 0.25
        _LightBands ("Paint Light Bands", Range(2, 8)) = 4
        _FlowStrength ("Water Flow", Range(0, 1)) = 0.08
        _FlowDirection ("Flow X/Z", Vector) = (1, 0, 0, 0)
        _FlowSpeed ("Flow Speed", Float) = 0.04
        _ObserverWS ("Observer World Position", Vector) = (0, 0, 0, 1)
        _ProximityRadius ("Response Radius", Float) = 5
        _ProximityStrength ("Proximity Response", Range(0, 1)) = 0
        _ThermalValue ("Environmental Impact", Range(0, 1)) = 0.5
        _ThermalTextureInfluence ("Diagnostic Texture Influence", Range(0, 1)) = 0
        _ThermalBlend ("Diagnostic Overlay", Range(0, 1)) = 0
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" "RenderPipeline"="UniversalPipeline" "Queue"="Geometry" }
        LOD 150
        HLSLINCLUDE
        #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
        #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
        TEXTURE2D(_BaseMap); SAMPLER(sampler_BaseMap);
        TEXTURE2D(_PatternMap); SAMPLER(sampler_PatternMap);
        // Identical layout in every pass is required for the SRP Batcher.
        CBUFFER_START(UnityPerMaterial)
            float4 _BaseMap_ST;
            float4 _PatternMap_ST;
            half4 _BaseColor;
            half4 _GlowColor;
            float4 _ObserverWS;
            float4 _FlowDirection;
            float _PatternScale;
            float _ProximityRadius;
            float _FlowSpeed;
            half _EmissionStrength;
            half _ProceduralPattern;
            half _PatternThreshold;
            half _PatternSoftness;
            half _Iridescence;
            half _BrushStrength;
            half _LightBands;
            half _FlowStrength;
            half _ProximityStrength;
            half _ThermalValue;
            half _ThermalTextureInfluence;
            half _ThermalBlend;
        CBUFFER_END
        ENDHLSL

        Pass
        {
            Name "PainterlyForward"
            Tags { "LightMode"="UniversalForward" }
            Cull Back ZWrite On ZTest LEqual
            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma multi_compile_instancing
            #pragma multi_compile_fog
            #pragma multi_compile _ _MAIN_LIGHT_SHADOWS _MAIN_LIGHT_SHADOWS_CASCADE _MAIN_LIGHT_SHADOWS_SCREEN
            #pragma multi_compile_fragment _ _SHADOWS_SOFT

            struct Attributes
            {
                float4 positionOS : POSITION;
                float3 normalOS : NORMAL;
                float2 uv : TEXCOORD0;
                UNITY_VERTEX_INPUT_INSTANCE_ID
            };
            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                float3 positionWS : TEXCOORD0;
                half3 normalWS : TEXCOORD1;
                float2 uv : TEXCOORD2;
                half fog : TEXCOORD3;
                UNITY_VERTEX_INPUT_INSTANCE_ID
            };
            Varyings Vert(Attributes input)
            {
                Varyings output = (Varyings)0;
                UNITY_SETUP_INSTANCE_ID(input);
                UNITY_TRANSFER_INSTANCE_ID(input, output);
                VertexPositionInputs position = GetVertexPositionInputs(input.positionOS.xyz);
                output.positionCS = position.positionCS;
                output.positionWS = position.positionWS;
                output.normalWS = TransformObjectToWorldNormal(input.normalOS);
                output.uv = TRANSFORM_TEX(input.uv, _BaseMap);
                output.fog = ComputeFogFactor(position.positionCS.z);
                return output;
            }

            float ColonyHash(float2 p)
            {
                float3 p3 = frac(float3(p.x, p.y, p.x) * 0.1031);
                p3 += dot(p3, p3.yzx + 33.33);
                return frac((p3.x + p3.y) * p3.z);
            }
            float ColonyNoise(float2 p)
            {
                float2 cell = floor(p);
                float2 f = frac(p);
                f = f * f * (3.0 - 2.0 * f);
                return lerp(lerp(ColonyHash(cell), ColonyHash(cell + float2(1, 0)), f.x),
                    lerp(ColonyHash(cell + float2(0, 1)), ColonyHash(cell + 1.0), f.x), f.y);
            }

            // A continuous blue/cyan/yellow/red palette, independent of scene lighting.
            half3 DiagnosticPalette(half t)
            {
                half3 low = half3(0.03h, 0.05h, 0.35h);
                half3 mid = half3(0.0h, 0.9h, 0.85h);
                half3 high = half3(1.0h, 0.85h, 0.03h);
                half3 peak = half3(1.0h, 0.03h, 0.015h);
                return lerp(lerp(low, mid, saturate(t * 3.0h)),
                    lerp(high, peak, saturate(t * 3.0h - 2.0h)), saturate(t * 3.0h - 1.0h));
            }

            half4 Frag(Varyings input) : SV_Target
            {
                UNITY_SETUP_INSTANCE_ID(input);
                half3 normal = normalize(input.normalWS);
                half3 view = GetWorldSpaceNormalizeViewDir(input.positionWS);
                float2 flowDirection = _FlowDirection.xy;
                flowDirection *= rsqrt(max(dot(flowDirection, flowDirection), 0.0001));
                float2 worldUV = input.positionWS.xz * _PatternScale;
                worldUV = worldUV * _PatternMap_ST.xy + _PatternMap_ST.zw;
                worldUV -= flowDirection * (_Time.y * _FlowSpeed * _FlowStrength);
                half3 pattern;
                // Uniform branch avoids procedural arithmetic when an artist supplies a texture.
                if (_ProceduralPattern > 0.5h)
                {
                    half noise = ColonyNoise(worldUV * 3.0);
                    pattern = half3(noise, smoothstep(0.1h, 0.9h, noise), 1.0h - noise);
                }
                else pattern = SAMPLE_TEXTURE2D(_PatternMap, sampler_PatternMap, worldUV).rgb;
                half colony = smoothstep(_PatternThreshold - _PatternSoftness,
                    _PatternThreshold + _PatternSoftness, pattern.r);
                half nearHead = saturate(1.0 - distance(input.positionWS, _ObserverWS.xyz)
                    / max(_ProximityRadius, 0.01)) * _ProximityStrength;
                half fresnel = pow(1.0h - saturate(dot(normal, view)), 3.0h);
                // Phase-shifted cosine gives a continuous thin-film-like hue cycle.
                half3 iridescence = 0.5h + 0.5h * cos(6.283185h *
                    (fresnel + pattern.g * 0.15h + half3(0.0h, 0.33h, 0.67h)));
                half3 glow = lerp(_GlowColor.rgb, _GlowColor.rgb * (0.35h + iridescence), _Iridescence);
                half pulse = 0.85h + 0.15h * sin(_Time.y * 1.3h + pattern.r * 6.283185h);
                half3 emission = glow * colony * _EmissionStrength * pulse
                    * (0.12h + nearHead + 0.8h * _FlowStrength);

                float4 shadowCoord;
                #if defined(_MAIN_LIGHT_SHADOWS_SCREEN)
                    // Screen-space shadow resolve expects projected screen coordinates.
                    shadowCoord = ComputeScreenPos(TransformWorldToHClip(input.positionWS));
                #else
                    shadowCoord = TransformWorldToShadowCoord(input.positionWS);
                #endif
                Light sun = GetMainLight(shadowCoord);
                half lambert = saturate(dot(normal, sun.direction));
                half bands = max(_LightBands, 2.0h);
                half paintedLight = floor(lambert * (bands - 1.0h) + 0.5h) / (bands - 1.0h);
                half3 albedo = SAMPLE_TEXTURE2D(_BaseMap, sampler_BaseMap, input.uv).rgb * _BaseColor.rgb;
                albedo *= lerp(1.0h, 0.7h + 0.6h * pattern.g, _BrushStrength);
                half3 lighting = max(SampleSH(normal), 0.06h) + sun.color
                    * paintedLight * sun.distanceAttenuation * sun.shadowAttenuation;
                half3 color = albedo * lighting + emission;
                half diagnostic = saturate(_ThermalValue
                    + (pattern.b - 0.5h) * _ThermalTextureInfluence);
                color = lerp(color, DiagnosticPalette(diagnostic), _ThermalBlend);
                color = MixFog(color, input.fog);
                return half4(color, 1.0h);
            }
            ENDHLSL
        }

        Pass
        {
            Name "ShadowCaster"
            Tags { "LightMode"="ShadowCaster" }
            ZWrite On ZTest LEqual ColorMask 0 Cull Back
            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex ShadowVert
            #pragma fragment ShadowFrag
            #pragma multi_compile_instancing
            #pragma multi_compile_vertex _ _CASTING_PUNCTUAL_LIGHT_SHADOW
            float3 _LightDirection;
            float3 _LightPosition;
            struct ShadowAttributes
            {
                float4 positionOS : POSITION;
                float3 normalOS : NORMAL;
                UNITY_VERTEX_INPUT_INSTANCE_ID
            };
            struct ShadowVaryings { float4 positionCS : SV_POSITION; };
            ShadowVaryings ShadowVert(ShadowAttributes input)
            {
                UNITY_SETUP_INSTANCE_ID(input);
                ShadowVaryings output;
                float3 positionWS = TransformObjectToWorld(input.positionOS.xyz);
                float3 normalWS = TransformObjectToWorldNormal(input.normalOS);
                #if defined(_CASTING_PUNCTUAL_LIGHT_SHADOW)
                    float3 direction = normalize(_LightPosition - positionWS);
                #else
                    float3 direction = _LightDirection;
                #endif
                output.positionCS = TransformWorldToHClip(ApplyShadowBias(positionWS, normalWS, direction));
                // URP 17 handles reversed-Z, near clipping and shadow pancaking here.
                // Inline directional-light near-plane clamping works across URP 17 patches,
                // including patches before the ApplyShadowClamping helper was introduced.
                #if !defined(_CASTING_PUNCTUAL_LIGHT_SHADOW)
                    #if UNITY_REVERSED_Z
                        output.positionCS.z = min(output.positionCS.z,
                            output.positionCS.w * UNITY_NEAR_CLIP_VALUE);
                    #else
                        output.positionCS.z = max(output.positionCS.z,
                            output.positionCS.w * UNITY_NEAR_CLIP_VALUE);
                    #endif
                #endif
                return output;
            }
            half4 ShadowFrag(ShadowVaryings input) : SV_Target { return 0; }
            ENDHLSL
        }

        Pass
        {
            Name "DepthOnly"
            Tags { "LightMode"="DepthOnly" }
            ZWrite On ColorMask R Cull Back
            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex DepthVert
            #pragma fragment DepthFrag
            #pragma multi_compile_instancing
            struct DepthAttributes { float4 positionOS : POSITION; UNITY_VERTEX_INPUT_INSTANCE_ID };
            struct DepthVaryings { float4 positionCS : SV_POSITION; };
            DepthVaryings DepthVert(DepthAttributes input)
            {
                DepthVaryings output = (DepthVaryings)0;
                UNITY_SETUP_INSTANCE_ID(input);
                output.positionCS = TransformObjectToHClip(input.positionOS.xyz);
                return output;
            }
            half DepthFrag(DepthVaryings input) : SV_Target { return input.positionCS.z; }
            ENDHLSL
        }
    }
    FallBack Off
}
```

## Assets/RiversInTheSky/Tests/Editor/DesktopInteractionTests.cs

```csharp
using System.Collections.Generic;
using System.Reflection;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using UnityEngine.Events;

namespace RiversInTheSky.Tests
{
    /// <summary>
    /// Exercises the actual desktop aim query without creating keyboard/mouse devices.
    /// A valve's existing rejection feedback observes delivery; no quest save is loaded
    /// or modified, and no cursor ownership or rendered frame is required.
    /// </summary>
    public sealed class DesktopInteractionTests
    {
        private const int TestLayer = 30;
        private readonly List<GameObject> roots = new List<GameObject>();
        private DesktopInteractor interactor;
        private Camera camera;
        private GameObject player;
        private int delivered;

        [SetUp]
        public void SetUp()
        {
            player = CreateRoot("Desktop query test player");
            player.SetActive(false);
            player.transform.position = Vector3.up * 1000f;
            var lens = new GameObject("Disabled test camera");
            lens.transform.SetParent(player.transform, false);
            camera = lens.AddComponent<Camera>();
            camera.enabled = false;
            camera.nearClipPlane = 0.3f;
            interactor = player.AddComponent<DesktopInteractor>();
            interactor.Configure(camera, null, null);
            var serialized = new SerializedObject(interactor);
            serialized.FindProperty("interactionMask").intValue = 1 << TestLayer;
            serialized.FindProperty("interactionDistance").floatValue = 4f;
            serialized.ApplyModifiedPropertiesWithoutUndo();
            player.SetActive(true);
            delivered = 0;
        }

        [TearDown]
        public void TearDown()
        {
            foreach (var root in roots) if (root != null) Object.DestroyImmediate(root);
            roots.Clear();
            Physics.SyncTransforms();
        }

        [Test]
        public void UnobstructedValveReceivesExactlyOneInteraction()
        {
            CreateValve(2f);
            Physics.SyncTransforms();
            Assert.That(interactor.TryInteract(), Is.True);
            Assert.That(delivered, Is.EqualTo(1));
        }

        [TestCase(1f, 0.1f)]
        [TestCase(0.12f, 0.04f)]
        public void SolidWallBlocksValveIncludingBeforeCameraNearPlane(float distance, float thickness)
        {
            CreateValve(2f);
            CreateBox("Solid occluder", distance, new Vector3(1f, 1f, thickness));
            Physics.SyncTransforms();
            Assert.That(interactor.TryInteract(), Is.False);
            Assert.That(delivered, Is.Zero);
        }

        [Test]
        public void BeyondRangeValveReceivesNoInteraction()
        {
            CreateValve(8f);
            Physics.SyncTransforms();
            Assert.That(interactor.TryInteract(), Is.False);
            Assert.That(delivered, Is.Zero);
        }

        [Test]
        public void OwnChildColliderDoesNotHideAnUnobstructedValve()
        {
            CreateValve(2f);
            var ownBody = new GameObject("Player-owned collider");
            ownBody.layer = TestLayer;
            ownBody.transform.SetParent(player.transform, false);
            ownBody.transform.localPosition = Vector3.forward * 0.5f;
            ownBody.AddComponent<BoxCollider>().size = Vector3.one * 0.2f;
            Physics.SyncTransforms();
            Assert.That(interactor.TryInteract(), Is.True);
            Assert.That(delivered, Is.EqualTo(1));
        }

        [Test]
        public void TriggerVolumeDoesNotHideAnUnobstructedValve()
        {
            CreateValve(2f);
            CreateBox("Trigger volume", 1f, Vector3.one * 0.25f).isTrigger = true;
            Physics.SyncTransforms();
            Assert.That(interactor.TryInteract(), Is.True);
            Assert.That(delivered, Is.EqualTo(1));
        }

        [Test]
        public void DisabledValveReceivesNoInteraction()
        {
            CreateValve(2f).enabled = false;
            Physics.SyncTransforms();
            Assert.That(interactor.TryInteract(), Is.False);
            Assert.That(delivered, Is.Zero);
        }

        [Test]
        public void MissingCameraReceivesNoInteraction()
        {
            CreateValve(2f);
            interactor.Configure(null, null, null);
            Physics.SyncTransforms();
            Assert.That(interactor.TryInteract(), Is.False);
            Assert.That(delivered, Is.Zero);
        }

        private GameObject CreateRoot(string name)
        {
            var result = new GameObject(name);
            roots.Add(result);
            return result;
        }

        private BoxCollider CreateBox(string name, float distance, Vector3 size)
        {
            var result = CreateRoot(name);
            result.layer = TestLayer;
            result.transform.position = player.transform.position + Vector3.forward * distance;
            var collider = result.AddComponent<BoxCollider>();
            collider.size = size;
            return collider;
        }

        private WaterChannelValve CreateValve(float distance)
        {
            var collider = CreateBox("Test valve", distance, Vector3.one * 0.5f);
            var valve = collider.gameObject.AddComponent<WaterChannelValve>();
            var rejected = (UnityEvent<string>)typeof(WaterChannelValve)
                .GetField("onRejected", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(valve);
            rejected.AddListener(_ => delivered++);
            return valve;
        }
    }
}
```

## Assets/RiversInTheSky/Tests/Editor/JournalTests.cs

```csharp
using System.IO;
using System.Reflection;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using UnityEngine.TestTools;

namespace RiversInTheSky.Tests
{
    public sealed class JournalTests
    {
        private GameObject host;
        private JournalManager journal;
        private string isolatedSavePath;

        [SetUp]
        public void SetUp()
        {
            host = new GameObject("Journal Test");
            host.SetActive(false); // Prevent Awake from loading the player's real journal.
            journal = host.AddComponent<JournalManager>();
            var serialized = new SerializedObject(journal);
            serialized.FindProperty("persistenceEnabled").boolValue = false;
            serialized.ApplyModifiedPropertiesWithoutUndo();
        }
        [TearDown]
        public void TearDown()
        {
            Object.DestroyImmediate(host);
            if (string.IsNullOrEmpty(isolatedSavePath)) return;
            foreach (var suffix in new[] { string.Empty, ".bak", ".tmp" })
                if (File.Exists(isolatedSavePath + suffix)) File.Delete(isolatedSavePath + suffix);
            isolatedSavePath = null;
        }

        [Test]
        public void DuplicateMemoryDoesNotDispatchOrAppend()
        {
            int notifications = 0;
            journal.PhotoRecorded += _ => notifications++;
            Assert.That(journal.TryRecordPhoto(new PhotoMemory { memoryId = "lotus" }), Is.True);
            Assert.That(journal.TryRecordPhoto(new PhotoMemory { memoryId = "lotus" }), Is.False);
            Assert.That(journal.Photos.Count, Is.EqualTo(1));
            Assert.That(notifications, Is.EqualTo(1));
        }
        [Test]
        public void CallerAndEventAndGetterCannotMutateStoredIdentity()
        {
            var input = new PhotoMemory { memoryId = "pagoda", displayName = "Pagoda" };
            journal.PhotoRecorded += copy => copy.memoryId = "changed-by-event";
            Assert.That(journal.TryRecordPhoto(input), Is.True);
            input.memoryId = "changed-by-caller";
            journal.Photos[0].memoryId = "changed-by-getter";
            Assert.That(journal.ContainsPhoto("pagoda"), Is.True);
            Assert.That(journal.Photos[0].memoryId, Is.EqualTo("pagoda"));
            Assert.That(journal.ContainsPhoto("changed-by-getter"), Is.False);
        }
        [Test]
        public void FuturePrimaryPreventsFallbackAndAnySaveOverwrite()
        {
            var fileName = "rivers-journal-test-" + System.Guid.NewGuid().ToString("N") + ".json";
            isolatedSavePath = Path.Combine(Application.persistentDataPath, fileName);
            Directory.CreateDirectory(Application.persistentDataPath);
            const string futurePrimary = "{\"version\":2,\"photos\":[]}";
            const string oldBackup = "{\"version\":1,\"photos\":[{\"memoryId\":\"backup-memory\"}]}";
            File.WriteAllText(isolatedSavePath, futurePrimary);
            File.WriteAllText(isolatedSavePath + ".bak", oldBackup);
            var serialized = new SerializedObject(journal);
            serialized.FindProperty("saveFileName").stringValue = fileName;
            serialized.FindProperty("persistenceEnabled").boolValue = true;
            serialized.ApplyModifiedPropertiesWithoutUndo();
            LogAssert.Expect(LogType.Error,
                "This journal belongs to a newer game version; writes are disabled to preserve it.");
            typeof(JournalManager).GetMethod("Load", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(journal, null);
            Assert.That(journal.Photos.Count, Is.Zero, "The older backup must not replace a future primary.");
            Assert.That(journal.TryRecordPhoto(new PhotoMemory { memoryId = "session-memory" }), Is.True);
            journal.Save();
            Assert.That(journal.ContainsPhoto("session-memory"), Is.True);
            Assert.That(File.ReadAllText(isolatedSavePath), Is.EqualTo(futurePrimary));
            Assert.That(File.ReadAllText(isolatedSavePath + ".bak"), Is.EqualTo(oldBackup));
        }
        [Test]
        public void EmptyMemoryIdIsRejected()
        {
            Assert.That(journal.TryRecordPhoto(new PhotoMemory { memoryId = "  " }), Is.False);
            Assert.That(journal.Photos.Count, Is.Zero);
        }
    }
}
```

## Assets/RiversInTheSky/Tests/Editor/QuestStateTests.cs

```csharp
using System;
using System.Collections.Generic;
using System.IO;
using NUnit.Framework;
using UnityEngine;

namespace RiversInTheSky.Tests
{
    public sealed class QuestStateTests
    {
        private Dictionary<ArtifactId, ArtifactDefinition> catalog;

        [SetUp]
        public void SetUp()
        {
            catalog = new Dictionary<ArtifactId, ArtifactDefinition>();
            foreach (ArtifactId id in Enum.GetValues(typeof(ArtifactId))) catalog.Add(id, ArtifactDefinition.CreateDefault(id));
        }

        [TearDown]
        public void TearDown()
        { foreach (ArtifactDefinition definition in catalog.Values) UnityEngine.Object.DestroyImmediate(definition); }

        [Test]
        public void RepeatedChoiceCannotApplyConsequencesTwice()
        {
            var state = new QuestState(catalog);
            Assert.That(state.TryChoose(ArtifactId.Pagoda, "force_entrance", out _, out _), Is.True);
            Assert.That(state.TryChoose(ArtifactId.Pagoda, "restore_passage", out _, out _), Is.False);
            Assert.That(state.Snapshot.ResolvedCount, Is.EqualTo(1));
            Assert.That(state.Snapshot.Habitat, Is.EqualTo(-2));
            Assert.That(state.GetChoiceId(ArtifactId.Pagoda), Is.EqualTo("force_entrance"));
        }

        [Test]
        public void UnknownChoiceAndCompoundChannelAreRejected()
        {
            var state = new QuestState(catalog);
            Assert.That(state.TryChoose(ArtifactId.Lotus, "unknown", out _, out _), Is.False);
            Assert.That(state.TryConnectChannel(WaterChannel.All, out _), Is.False);
            Assert.That(state.TryConnectChannel(WaterChannel.Lotus, out _), Is.False);
            Assert.That(state.Snapshot.ResolvedCount, Is.Zero);
        }

        [TestCase(0)] [TestCase(1)] [TestCase(2)] [TestCase(3)]
        [TestCase(4)] [TestCase(5)] [TestCase(6)] [TestCase(7)]
        [TestCase(8)] [TestCase(9)] [TestCase(10)] [TestCase(11)]
        [TestCase(12)] [TestCase(13)] [TestCase(14)] [TestCase(15)]
        public void EveryBranchCombinationCanReachFinalMemory(int combination)
        {
            var state = ResolveAll(combination);
            Assert.That(state.Snapshot.FinalMemoryUnlocked, Is.False);
            foreach (WaterChannel channel in new[] { WaterChannel.Lotus, WaterChannel.Lantern, WaterChannel.Rice, WaterChannel.Water })
                Assert.That(state.TryConnectChannel(channel, out _), Is.True);
            Assert.That(state.AdvancePool(4f, 8f, out bool unlocked), Is.True);
            Assert.That(unlocked, Is.False);
            Assert.That(state.Snapshot.PoolFill01, Is.EqualTo(.5f));
            state.AdvancePool(4f, 8f, out unlocked);
            Assert.That(unlocked, Is.True);
            Assert.That(state.Snapshot.ResolvedCount, Is.EqualTo(5));
            Assert.That(state.Snapshot.FinalMemoryUnlocked, Is.True);
            Assert.That(state.AdvancePool(4f, 8f, out unlocked), Is.False);
            Assert.That(unlocked, Is.False);
        }

        [Test]
        public void IncompleteChannelsCannotFillPool()
        {
            var state = ResolveAll(15);
            state.TryConnectChannel(WaterChannel.Lotus, out _);
            Assert.That(state.AdvancePool(100f, 8f, out _), Is.False);
            Assert.That(state.Snapshot.PoolFill01, Is.Zero);
        }

        [Test]
        public void SaveRoundTripPreservesConsequencesAndPartialPool()
        {
            var state = ResolveAll(5);
            foreach (WaterChannel channel in new[] { WaterChannel.Lotus, WaterChannel.Lantern, WaterChannel.Rice, WaterChannel.Water })
                state.TryConnectChannel(channel, out _);
            state.AdvancePool(2f, 8f, out _);
            QuestSaveData copy = JsonUtility.FromJson<QuestSaveData>(JsonUtility.ToJson(state.Export()));
            var restored = new QuestState(catalog);
            restored.Restore(copy);
            Assert.That(restored.Snapshot.ResolvedCount, Is.EqualTo(state.Snapshot.ResolvedCount));
            Assert.That(restored.Snapshot.CleansedCount, Is.EqualTo(state.Snapshot.CleansedCount));
            Assert.That(restored.Snapshot.Toxicity, Is.EqualTo(state.Snapshot.Toxicity));
            Assert.That(restored.Snapshot.PoolFill01, Is.EqualTo(.25f));
        }

        [Test]
        public void RestoreCanonicalizesDuplicatesUnknownIdsAndImpossibleProgress()
        {
            var data = new QuestSaveData { connectedChannels = 255, poolFill = 1f };
            data.choices.Add(new ArtifactChoiceRecord(ArtifactId.Pagoda, "force_entrance"));
            data.choices.Add(new ArtifactChoiceRecord(ArtifactId.Pagoda, "restore_passage"));
            data.choices.Add(new ArtifactChoiceRecord((ArtifactId)99, "force_entrance"));
            data.choices.Add(new ArtifactChoiceRecord(ArtifactId.Lotus, "removed_choice"));
            data.choices.Add(new ArtifactChoiceRecord(ArtifactId.FourYoungMaidens, "anything"));
            var state = new QuestState(catalog);
            state.Restore(data);
            Assert.That(state.Snapshot.ResolvedCount, Is.EqualTo(1));
            Assert.That(state.Snapshot.ConnectedChannels, Is.EqualTo(WaterChannel.Water));
            Assert.That(state.Snapshot.PoolFill01, Is.Zero);
            Assert.That(state.Snapshot.Habitat, Is.EqualTo(-2));
        }

        [Test]
        public void FutureVersionIsRejectedBeforeExistingStateIsChanged()
        {
            var state = ResolveAll(15);
            Assert.Throws<InvalidDataException>(() => state.Restore(new QuestSaveData { version = 2 }));
            Assert.That(state.Snapshot.ResolvedCount, Is.EqualTo(4));
        }

        [Test]
        public void WetlandRiceRoutePreservesItsNutrientTradeoff()
        {
            var state = new QuestState(catalog);
            state.TryChoose(ArtifactId.RiceField, "wetland_route", out _, out _);
            Assert.That(state.Snapshot.Nutrients, Is.EqualTo(-1));
            Assert.That(state.Snapshot.FloodRisk, Is.EqualTo(-1));
            Assert.That(state.Snapshot.CleansedCount, Is.EqualTo(1));
        }

        [Test]
        public void ArcAdvancesWithExperienceEvenAfterNonrestorativeChoices()
        {
            var state = new QuestState(catalog);
            Assert.That(state.Snapshot.Act, Is.EqualTo(IsoAct.AnalyticalCurious));
            state.TryChoose(ArtifactId.Pagoda, "force_entrance", out _, out _);
            state.TryChoose(ArtifactId.Lotus, "remove_rubbish", out ChoiceOutcome outcome, out _);
            Assert.That(outcome.Act, Is.EqualTo(IsoAct.QuestionAndLearn));
            state.TryChoose(ArtifactId.Lamplight, "old_cell", out _, out _);
            state.TryChoose(ArtifactId.RiceField, "direct_gate", out outcome, out _);
            Assert.That(outcome.Act, Is.EqualTo(IsoAct.UnderstandingEmpathetic));
        }

        private QuestState ResolveAll(int combination)
        {
            var state = new QuestState(catalog);
            for (int i = 0; i < 4; i++)
            {
                ArtifactId id = (ArtifactId)i;
                string choice = catalog[id].Choices[(combination >> i) & 1].Id;
                Assert.That(state.TryChoose(id, choice, out _, out _), Is.True);
            }
            return state;
        }
    }
}
```

## Assets/RiversInTheSky/Tests/Editor/RiversInTheSky.Tests.asmdef

```json
{
  "name": "RiversInTheSky.Tests",
  "rootNamespace": "RiversInTheSky.Tests",
  "references": ["RiversInTheSky.Runtime"],
  "includePlatforms": ["Editor"],
  "optionalUnityReferences": ["TestAssemblies"],
  "autoReferenced": false
}
```

## Setup/manifest.dependencies.json

```json
{
  "com.unity.inputsystem": "1.11.2",
  "com.unity.render-pipelines.universal": "17.0.3",
  "com.unity.test-framework": "1.4.5",
  "com.unity.ugui": "2.0.0"
}
```
