# There Are Rivers in the Sky — Desktop source kit

Unity **6000.0 LTS**, **URP 17**, Input System **1.11.2**, and uGUI **2.0.0**.
The player now uses a normal camera, keyboard, and mouse. All five artifacts,
branching consequences, ISO's three acts/dialogue, photography, save formats,
folk-song mixing, and painterly materials retain their original behavior.
The player module is under `Runtime/Player`.

## Start in Unity

1. Create a **Universal 3D** project. Install Input System, Unity UI and Test
   Framework through Package Manager. The template supplies URP.
2. `Setup/manifest.dependencies.json` contains the complete reference package
   list. Merge its entries into your existing Packages/manifest.json dependencies
   if needed; preserve the URP patch shipped with your Editor.
3. Set **Edit → Project Settings → Player → Active Input Handling** to
   **Input System Package (New)** and restart if requested.
4. Copy `Assets/RiversInTheSky` into the project. For an existing installation,
   follow the migration instructions below before copying updated files.
5. Choose **Tools → Rivers in the Sky → Create Desktop Demo Scene**. It creates
   and saves a uniquely named scene with a collidable player, all five artifacts,
   four valves, pool, ISO, subtitles, photography, mouse UI, procedural glowing
   material and grading. Existing authored assets are preserved. Press Play and
   click the Game view to capture the mouse if necessary.
6. Assign your art and AudioClips. The demo wires the audio manager but bundles no
   recordings. Read `Assets/RiversInTheSky/Documentation/Desktop.md` and
   `DesktopDemo.md` for full setup.

The demo uses primitive markers and visual water surfaces, not a finished palace
level. It disables quest/journal persistence so every Play session starts fresh.
Enable QuestManager's Load On Awake/Auto Save and JournalManager's Persistence
Enabled to test saved progress. No external input-action asset is required.

## Controls

| Input | Action |
| --- | --- |
| W / A / S / D | Walk with collision and gravity |
| Mouse | Look around |
| E or left click | Interact with the artifact or valve at the centre of the view |
| Mouse pointer + left click with a choice panel open | Choose a branch or close |
| F | Photograph a framed, visible landmark |
| T | Toggle diagnostics on assigned surfaces |
| Escape | Close the choice panel, or release the mouse |
| Left click with the mouse released | Capture the mouse and resume exploration |

The desktop components own only their own InputActionMaps. Opening a choice panel
releases the cursor and pauses movement/look; closing it restores exploration.
World/photo input is suppressed while a panel is open and on its closing frame.

## Modules

| System | Main files | Behavior |
| --- | --- | --- |
| Player | DesktopPlayerController, DesktopInteractor | First-person movement, mouse look, centre-ray selection, photo/diagnostic shortcuts |
| Artifact UI | ArtifactInteractor, ArtifactChoicePanel | Distance-checked branching world-space UI with GraphicRaycaster and InputSystemUIInputModule |
| Memories | EnvironmentCamera, Photographable, JournalManager | Framing, occlusion, stable IDs, UTC/pose, optional PNG, persistent journal |
| ISO | IsoCompanion, IsoSubtitlePresenter | Damped following, original three-act arc, 24 branch/act lines, voice queue and subtitles |
| Artifacts | ArtifactDefinition, QuestState, QuestManager, ArtifactNode | Authored choices, deterministic consequences, canonical saves and live-event separation |
| Consequences/pool | ArtifactConsequenceView, WaterChannelValve, CentralPoolView | Persistent branch objects, channel prerequisites and timed final unlock |
| Audio | AudioLandscapeManager, WaterAudioDepthDriver | Five DSP-aligned folk stems, wind/underwater crossfade |
| Rendering | PainterlyBioluminescence.shader, CyanobacteriaController, EcologyThermalDriver, PainterlyGradeController | Original glow, proximity/flow response, diagnostics and Volume grading |

## Manual wiring

Use a player root with CharacterController and a child Main Camera around 1.65 m
high. Add DesktopPlayerController and DesktopInteractor to the root; assign the
camera, shared ArtifactChoicePanel, EnvironmentCamera and diagnostic surfaces.
Keep one AudioListener on the camera. Exclude the player from interaction/photo
physics masks.

One scene-owned Services object holds QuestManager, JournalManager and
AudioLandscapeManager. Reference it explicitly from consumers. Services do not
automatically survive scene replacement; keep one owner while loading environments
additively. Leave the definitions array empty for complete default artifact data,
or run **Create Default Artifact Assets** to author editable definitions.

Each artifact needs a collider, ArtifactNode and ArtifactInteractor; assign its ID,
QuestManager, shared panel and camera transform. Photographable needs a unique
memory ID. ArtifactConsequenceView restores branch-specific object groups by
choice ID. Keep listeners outside the objects they hide.

Keep ArtifactChoicePanel outside the world-space Canvas it hides. Use legacy
UnityEngine.UI.Text labels and a Button prefab containing Text. Use a normal
GraphicRaycaster, the Main Camera as Canvas Event Camera, and one EventSystem with
InputSystemUIInputModule. Choice callbacks are generated; Close calls panel.Close().

Each of four collidable valves has WaterChannelValve with Lotus, Lantern, Rice or
Water assigned separately. DesktopInteractor calls Connect() on the aimed-at valve.
CentralPoolView raises a separate visual water surface and reveals the final memory.
Point ISO, photography, proximity rendering and water audio at the Main Camera.
Existing `playerHead` field names are retained to preserve serialization; they now
refer to the desktop view camera. Enable camera post-processing for grading.

## Upgrade an existing installation

Back up your project, including custom scenes, artifact data and art, first.

1. In Unity's Project window move `Runtime/XR` to `Runtime/Player` before copying
   updated code. Moving through Unity preserves the existing script .meta GUIDs.
2. Remove XRPlayerSettings and its components. Copy updated source over matching
   files, preserving your .meta files and authored Data/Scenes assets. Do not
   leave duplicate old scripts under Runtime/XR.
3. Replace the old player rig with the desktop CharacterController/camera setup.
   Remove its old interaction managers, controller input objects, and imported
   interaction-toolkit samples that depend on packages you will remove. Retain
   environment geometry, artifact data, consequences, materials and audio.
4. Remove old controller-interactable components from artifacts and valves.
   Replace the old UI input module/raycaster with InputSystemUIInputModule and
   GraphicRaycaster. Reassign camera references in interactions, ISO, photography,
   rendering and water audio. References to the deleted player camera need updating.
5. Disable XR loaders in Project Settings, then uninstall the unused OpenXR,
   XR Interaction Toolkit, XR Plug-in Management and XR Core Utilities packages.
   Remove unused imported samples before their packages to avoid compile errors.
6. Keep save filenames, Company Name and Product Name to retain the same
   Application.persistentDataPath. Choice IDs, quest/journal JSON and photo
   formats are unchanged. Existing saved memories are not deleted.

## Quest behavior retained

Both choices resolve each of the first four artifacts, in any order, while keeping
their distinct ecological effects. Two resolutions advance ISO to Act II; four
advance it to Act III. The fifth artifact completes after all four channels connect
and the pool fills. The wetland rice route still trades nutrients for flood safety.

| Artifact | Choice IDs | Channel prerequisite |
| --- | --- | --- |
| Pagoda | force_entrance / restore_passage | Water |
| Lotus | remove_rubbish / stop_source | Lotus |
| Lamplight | old_cell / sunlight | Lantern |
| Rice Field | direct_gate / wetland_route | Rice |
| Four Young Maidens | Four valve connections | All four + full pool |

QuestState owns choices and derives ecology/counters. StateChanged reconstructs
scene state; ChoiceCommitted drives new dialogue only. Loading never replays old
decisions or applies consequences twice. Saves retain versioning, backups and
future-version overwrite protection under Application.persistentDataPath.

## Build and verify

Run the included EditMode tests through **Window → General → Test Runner**, then
test walls, mouse look, cursor capture, UI choices, photo occlusion, all four
valves, final fill and save/reload in Play mode.

Open **File → Build Profiles**, choose a desktop target supported by your Editor,
add the generated/authored scene to the Scene List and choose **Build And Run**.
No headset, tracking service or device runtime is required.

Executed checks and remaining Unity validation limits are recorded in
`Assets/RiversInTheSky/Documentation/Validation.md`. Art, audio and the finished
production environment remain authored media.
