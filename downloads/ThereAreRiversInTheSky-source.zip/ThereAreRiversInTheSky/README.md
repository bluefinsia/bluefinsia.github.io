# There Are Rivers in the Sky — Unity source kit

Complete modular implementation of the five systems in the supplied design brief.
Baseline: Unity **6000.0 LTS**, URP **17**, XR Interaction Toolkit **3.0.7**, OpenXR,
Input System, and uGUI. The code is deliberately pinned to XRI 3's APIs; XRI 2's
`ActionBasedContinuousMoveProvider`/`LocomotionSystem` are different APIs.

This is source code and authoring tooling to import into a Unity project, not a
finished game or a configured Unity project. Audio recordings, art, and production
levels are authored/assigned separately. The shader produces procedural glowing
patterns with no texture assignment; the quest catalog has all five artifacts and
all eight binary choices without asset creation. Default dialogue is original text
written for this implementation from the provided brief.

## Import and assemble

1. Create a Unity 6000.0 **Universal 3D** project. Copy the `Assets/RiversInTheSky`
   folder into your project's `Assets` folder.
2. Install the packages listed in `Setup/manifest.dependencies.json` through
   Package Manager. That JSON is a dependency snippet: merge entries into the
   existing `Packages/manifest.json`'s `dependencies`, preserving project entries.
   Keep the URP patch supplied by your Unity 6000.0 Editor if it is newer.
3. Set Active Input Handling to **Input System Package (New)**. Enable OpenXR in
   XR Plug-in Management for Android (Quest) and/or Standalone (PCVR), enable the
   relevant controller interaction profile, and resolve OpenXR Project Validation.
   Use single-pass instanced / multiview rendering supported by the target.
4. Import **XRI Starter Assets** and use its **XR Origin (XR Rig)** prefab. It
   supplies controller bindings, camera tracking, the locomotion mediator and XR
   body transformer. Follow `Assets/RiversInTheSky/Documentation/XR.md` to disable
   the sample Controller Input Action Managers before Play, let one Input Action
   Manager keep both turn actions enabled, and wire left-stick movement/right-stick
   turning. Replace the sample Dynamic Move Provider with one plain Continuous
   Move Provider. `XRPlayerSettings` then selects snap or continuous turning by
   enabling only the requested turn provider.
5. Create one scene-owned Services object with `QuestManager`, `JournalManager`,
   and `AudioLandscapeManager`. Reference these explicitly in consumers. Keep
   services alive while loading additive environment scenes; do not instantiate
   a duplicate service per environment scene. This kit does not use singletons.
6. Create a world-space choice canvas, button prefab, and one shared
   `ArtifactChoicePanel` controller. Configure XR UI raycasting as documented.
   Keep the panel controller outside the canvas root that it hides.
7. For each artifact, add a collider, `XRSimpleInteractable`, `ArtifactNode`,
   `ArtifactInteractor`, and optionally `Photographable` and
   `ArtifactConsequenceView`. Set a different ArtifactId on each node. Keep
   consequence listeners outside the scene objects they hide. QuestManager's
   empty definitions array uses complete runtime defaults. To author assets,
   run **Tools → Rivers in the Sky → Create Default Artifact Assets** and assign
   the five assets to the manager. Keep choice IDs stable across saves.
8. At the final pool, create four `WaterChannelValve` components with channel
   Lotus, Lantern, Rice, or Water. Wire each XRSimpleInteractable's Select Entered
   event to its valve's parameterless `Connect()` method. Assign `CentralPoolView`
   to animate a separate visual water plane and show the final memory root.
9. Assign a headset transform to ISO and the shader controller. Add the supplied
   material to water-edge colonies, lotus surfaces, and architecture. Use emission
   0 for ordinary painted ruins. Add a dedicated global Volume and
   `PainterlyGradeController`; enable post-processing on the XR camera. See the
   rendering guide for graph-equivalent nodes and Quest quality settings.
10. Assign wind, underwater, and five aligned folk-song stems to the audio manager.
    All stems must share one sample count, sample rate, and loop boundaries. They
    start silently on one DSP clock and reveal with quest progress. Route to
    AudioMixer groups if desired. See `Assets/RiversInTheSky/Documentation/Audio.md`.

## Modules

| System | Main files | Runtime behavior |
| --- | --- | --- |
| XR player / interaction | XRPlayerSettings, ArtifactInteractor, ArtifactChoicePanel | Smooth XRI movement; snap/continuous turn; distance-checked branching world-space UI |
| Environment camera / journal | EnvironmentCamera, Photographable, JournalManager | Cone, distance, occlusion, stable memory IDs, UTC + viewfinder pose, optional PNG |
| ISO | IsoCompanion, IsoSubtitlePresenter | Per-axis damped follow, bob, optional collision avoidance, authoritative three-act state, branch dialogue and voice queue |
| Five artifacts | ArtifactDefinition, QuestState, QuestManager, ArtifactNode | Authored choices, deterministic consequences, canonical saves, state/event separation |
| Scene consequences / final pool | ArtifactConsequenceView, WaterChannelValve, CentralPoolView | Branch-specific object groups, prerequisite-checked channels, timed pool fill and final-memory unlock |
| Audio landscape | AudioLandscapeManager, WaterAudioDepthDriver | DSP-aligned folk stems, normalized gain, wind/water equal-power crossfade |
| Painterly / diagnostics | PainterlyBioluminescence.shader, CyanobacteriaController, PainterlyGradeController, EcologyThermalDriver | Iridescence, proximity and flow, banded paint lighting, impact palette, cloned Volume grading |

Detailed setup and assumptions are in `Assets/RiversInTheSky/Documentation`.

## State and consequence architecture

```mermaid
flowchart LR
  XRI[XR selection] --> Panel[ArtifactChoicePanel]
  Panel --> QM[QuestManager]
  Valves[Four channel valves] --> QM
  Data[ArtifactDefinition assets / defaults] --> Domain[QuestState]
  QM --> Domain
  Domain --> Snapshot[Immutable QuestSnapshot]
  QM --> Disk[Versioned JSON + backup]
  Snapshot --> View[Scene consequence / pool views]
  Snapshot --> Act[ISO act]
  Snapshot --> Mix[Audio layer targets]
  Snapshot --> Flow[Shader flow / color grade]
  QM --> Live[ChoiceCommitted: live choices only]
  Live --> Dialogue[ISO dialogue / optional voice]
  Photo[EnvironmentCamera] --> Journal[JournalManager + optional PNG]
```

`QuestState` owns the truth. Progress, act, and ecology derive from the selected
choice IDs; other systems cannot mutate the snapshot. `StateChanged` is also used
for reconstruction, so it must not drive one-shot voice, rewards, or haptics.
`ChoiceCommitted` and `FinalMemoryUnlocked` are live events and are not replayed by
loading a save. Listeners read `Snapshot` when binding, then subscribe for changes.

The first four artifacts can be resolved in any order. Act I lasts until two are
resolved, Act II until four are resolved, and Act III follows. The fifth artifact
completes when all four channels are connected and the pool reaches full. Both
branches at each artifact remain playable; ecological consequences affect the
world and ISO's words rather than locking players out of the ending.

| Artifact | Choice IDs | Channel prerequisite |
| --- | --- | --- |
| The Pagoda | force_entrance / restore_passage | Water |
| The Lotus | remove_rubbish / stop_source | Lotus |
| The Lamplight | old_cell / sunlight | Lantern |
| The Rice Field | direct_gate / wetland_route | Rice |
| The Four Young Maidens | Four separate valve interactions | All four + full pool |

Habitat, pollution, toxicity, flood risk, and nutrients are **relative game units**
derived from choice data, not a physical ecology simulation. The wetland irrigation
branch explicitly trades reduced flood risk for reduced delivered nutrients.
`CleansedCount` means restorative choices plus the final pool, while `ResolvedCount`
includes every selected branch; this distinction keeps music/progression responsive
to every choice. Scene consequences are reconstructed by stable choice ID.

## Save files and ownership

Quest JSON and journal JSON live under `Application.persistentDataPath` and keep
previous-revision backups. Photo PNGs live in its `rivers-photos` subfolder. Invalid
or duplicate records are rejected/canonicalized; future quest-save versions are
preserved by disabling writes. The kit expects **one owner of each save file**.
Saves across the quest and journal are separate transactions. Scene consumers
restore their state from the saved quest rather than serializing world objects.

Input actions belong to XRI's InputActionManager / controller managers; components
observe configured actions without disabling shared maps. Materials use property
blocks, and the grading controller deep-clones its Volume overrides so shared
assets are never edited at runtime.

## Validation and practical limits

The deterministic core was executed with a portable .NET compiler using minimal
Unity attribute/ScriptableObject stubs: **13,842 assertions passed across 384 full
runs** (16 branch combinations × 24 artifact orders), plus invalid-save,
duplicate-interaction, prerequisite, and exactly-once-unlock checks. This validates
the actual domain source, not Unity serialization or headset behavior.

The repository also includes **28 Unity EditMode cases**: 24 quest-state cases and
four journal invariant cases. Run them in **Window → General → Test Runner →
EditMode**. They have not been executed in Unity in this environment.

XRI provider namespaces/properties and URP17 render-request support were checked
against official package source. Unity is not installed here, so full Unity import,
shader compilation, XR interaction, mobile capture, and audio/headset playback
still need Editor and device validation. The material supports Forward/Forward+
and main-light/shadow/SH lighting; it does not implement baked lightmaps, SSAO
DepthNormals, motion vectors, or additional pixel lights. Thermal view is a
colored environmental diagnostic, not measured temperature. PNG capture uses
synchronous GPU readback and can hitch on Quest; metadata-only photography avoids
that cost. Start with bloom off on Quest and measure frame time on hardware.
